#include<bits/stdc++.h>
using namespace std;
//#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
struct matrix{
    vii mat{2 , vi(2)};
};

vii identity{ {1 , 0}  , {0 , 1} };

vii multiply(vii &m1 , vii &m2 , int mod){
    vii m3(2 , vi(2));
    for(int i = 0; i < 2; i++){
        for(int j = 0; j < 2; j++){
            for(int k = 0; k < 2; k++){
                m3[i][j] += m1[i][k]*m2[k][j];
            }
            m3[i][j] %= mod;
        }
    }

    return m3;
}
void buildTree(matrix tree[] , matrix a[] , int s , int e , int index , int mod){
    // Base Case
    if(s == e){
        tree[index].mat = a[s].mat;
        return;
    }

    // Recursive Case
    int mid = (s+e)/2;

    buildTree(tree , a , s , mid , 2*index , mod);
    buildTree(tree , a , mid+1 , e , 2*index+1 , mod);


    tree[index].mat  = multiply(tree[2*index].mat , tree[2*index+1].mat , mod);

    return;

}
vii query(matrix tree[] , int ss , int se , int l , int r , int index , int mod){




    // NO Overlap
    if(se < l or ss > r){
        return identity;
    }

    // Full Overlap
    if(ss >= l and se <= r){
        return tree[index].mat;
    }

    // Partial Overlap

    int mid = (ss+se)/2;
    vii temp1 = query(tree , ss , mid , l , r , 2*index , mod);
    vii temp2 = query(tree , mid+1 , se , l , r , 2*index+1 , mod);
    return multiply(temp1 , temp2  , mod);
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int mod , n , q;
    cin>>mod>>n>>q;

    matrix a[n];
    loop(n){
        for(int j = 0; j < 2; j++){
            for(int k = 0; k < 2; k++){
                cin>>a[i].mat[j][k];
            }
        }
    }

    matrix tree[4*n+1];

    buildTree(tree ,  a , 0 , n-1 , 1 , mod);

    while(q--){
        int l , r;
        cin>>l>>r;
        vii temp = query(tree , 0 , n-1 , l-1 , r-1 , 1 , mod);
        cout<<temp[0][0]<<" "<<temp[0][1]<<endl;
        cout<<temp[1][0]<<" "<<temp[1][1]<<endl;

        cout<<endl;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
