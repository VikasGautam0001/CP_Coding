#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);


struct treeNode{
    int prefix;
    int suffix;
    int totalSum;
    int maxSum;
};
treeNode waste = (treeNode){INT_MIN , INT_MIN , INT_MIN , INT_MIN};
void buildTree(treeNode tree[] , int a[] , int s , int e , int index){
    // Base Case
    if(s == e){
        tree[index] = (treeNode){a[s] , a[s] , a[s] , a[s]};
        return;
    }

    // Recursive Case
    int mid = (s+e)/2;
    buildTree(tree , a , s , mid , 2*index);
    buildTree(tree , a , mid+1 , e , 2*index+1);

    treeNode left = tree[2*index];
    treeNode right = tree[2*index+1];

    tree[index].prefix = max(left.totalSum+right.prefix , left.prefix);
    tree[index].suffix = max(right.totalSum+left.suffix , right.suffix);
    tree[index].totalSum = left.totalSum+right.totalSum;
    tree[index].maxSum = max(max(left.maxSum , right.maxSum ) , left.suffix+right.prefix);

    return;

}

treeNode query(treeNode tree[] , int ss , int se , int l , int r , int index){

    // No Overlap
    if(se < l or ss > r){
        return waste;
    }

    // Full Overlap
    if(ss >= l and se <= r){
        return tree[index];
    }

    // Partial Overlap
    int mid = (ss+se)/2;

    treeNode left = query(tree , ss , mid , l , r , 2*index);
    treeNode right = query(tree , mid+1 , se , l , r , 2*index+1);

    treeNode temp;

    temp.prefix = max(left.totalSum+right.prefix , left.prefix);
    temp.suffix = max(right.totalSum+left.suffix , right.suffix);
    temp.totalSum = left.totalSum+right.totalSum;
    temp.maxSum = max(max(left.maxSum , right.maxSum ) , left.suffix+right.prefix);

    if(right.maxSum == waste.maxSum)
        return left;
    if(left.maxSum == waste.maxSum)
        return right;

    return temp;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n;
    cin>>n;

    int a[n];
    loop(n) cin>>a[i];

    treeNode tree[4*n+1];
    buildTree(tree , a , 0 , n-1 , 1);
    int q;
    cin>>q;
    while(q--){
        int l , r;
        cin>>l>>r;
        cout<<query(tree , 0 , n-1 , l-1 , r-1 , 1).maxSum<<endl;

    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
