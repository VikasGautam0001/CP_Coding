#include<bits/stdc++.h>
using namespace std;
void buildTree(int a[] , int s , int e , int tree[] , int index){
    // Base Case
    if(s == e){
        tree[index] = a[s];
        return ;
    }

    // Recursive Case
    int mid = (s+e)/2;

    buildTree(a , s , mid , tree , 2*index);
    buildTree(a , mid+1 , e , tree , 2*index+1);
    tree[index] = min(tree[2*index] , tree[2*index+1]);

    return ;
}

int query(int tree[] , int ss , int se , int l , int r , int index){
    // Full Overlap
    if(ss >= l and se <= r){
        return tree[index];
    }
    // No Overlap
    if(se < l or ss > r){
        return INT_MAX;
    }
    // Partial Overlap

    int mid = (ss+se)/2;
    return min(query(tree , ss , mid , l , r , 2*index) , query(tree , mid+1 , se , l , r , 2*index+1));

}

void rangeUpdation(int tree[] , int ss , int se , int l , int r , int increement , int index){
    // No Overlap
    if(se < l or ss > r){
        return;
    }
    if(ss == se){
        tree[index] += increement;
        return ;
    }

    // Partial Overlap
    int mid =  (ss+se)/2;

    rangeUpdation(tree , ss , mid , l , r , increement , 2*index);
    rangeUpdation(tree , mid+1 , se , l , r , increement , 2*index+1);
    tree[index] = min(tree[2*index] , tree[2*index+1]);

    return;


}
int main(){

    int a[] = {1 , 3 , 2  , -5 , 6 , 4 , 0};

    int n = sizeof(a)/sizeof(int);

    int tree[4*n+1];

    buildTree(a ,0 ,  n-1 , tree , 1);

    //for(int i = 1; i <= 13; i++) cout<<tree[i]<<" ";

    int l1 , r1;
    cin>>l1>>r1;
    int increement;
    cin>>increement;

    rangeUpdation(tree , 0 , n-1 , l1 , r1 , increement , 1);

    for(int i = 1; i <= 13; i++) cout<<tree[i]<<" ";

    int l , r ;
    cin>>l>>r;

    cout<<query(tree , 0 , n-1 , l , r , 1);



    return 0;
}
