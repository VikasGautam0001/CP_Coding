#include<bits/stdc++.h>
using namespace std;

struct treeNode{
    int prefix;
    int suffix;
    int total;
    int maximum;
};
treeNode nullNode = (treeNode){INT_MIN , INT_MIN , INT_MIN , INT_MIN};

void buildTree(treeNode tree[] , int a[] , int s , int e , int index){
    // Base Case
    if(s == e){
        tree[index].prefix = a[s];
        tree[index].suffix = a[s];
        tree[index].total = a[s];
        tree[index].maximum = a[s];
        return;
    }

    // Recursive Case
    int mid = (s+e)/2;

    buildTree(tree , a , s , mid , 2*index);
    buildTree(tree , a , mid+1 , e , 2*index+1);

    treeNode left = tree[2*index];
    treeNode right = tree[2*index+1];

    tree[index].prefix = max(left.total+right.prefix , left.prefix);
    tree[index].suffix = max(right.total+left.suffix , right.suffix);
    tree[index].total = right.total + left.total;
    tree[index].maximum = max(max(left.maximum , right.maximum) , left.suffix+right.prefix);

    return;
}

treeNode query(treeNode tree[] , int ss , int se , int l , int r , int index){

    // No Overlap
    if(r < ss or l > se){
        return nullNode;
    }

    // Full Overlap
    if(ss >= l and se <= r){
        return tree[index];
    }

    // Partial Overlap
    int mid = (ss+se)/2;

    treeNode left = query(tree , ss , mid , l , r , 2*index);
    treeNode right = query(tree , mid+1 , se , l , r , 2*index+1);

    treeNode temp;

    temp.prefix = max(left.total+right.prefix , left.prefix);
    temp.suffix = max(right.total+left.suffix , right.suffix);
    temp.total = right.total + left.total;
    temp.maximum = max(max(left.maximum , right.maximum) , left.suffix+right.prefix);

    if(left.maximum == INT_MIN){
        return right;
    }
    else if(right.maximum == INT_MIN){
        return left;
    }

    return temp;
}
int main(){

    int n;
    cin>>n;

    int a[n];
    for(int i = 0; i < n; i++) cin>>a[i];

    treeNode tree[4*n+1];

    buildTree(tree , a , 0 , n-1 , 1);

    int q;
    cin>>q;

    while(q--){
        int l  , r ;
        cin>>l>>r;

        cout<<query(tree , 0 , n-1 , l-1 , r-1 , 1).maximum<<endl;
    }
    return 0;
}
