#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);

void buildTree(int tree[] , int a[] , int s , int e , int index){
    // Base Case
    if(s == e){
        tree[index] = a[s];
        return ;
    }

    // Recursive Case
    int mid = (s+e)/2;
    buildTree(tree , a , s , mid , 2*index);
    buildTree(tree , a , mid+1 , e , 2*index+1);

    tree[index] = min(tree[2*index] , tree[2*index+1]);

    return;
}

int query(int tree[] , int ss , int se , int l , int r , int index){
    // No Overlap
    if(l > se or r < ss){
        return INT_MAX;
    }
    // Full Overlap
    if(ss >= l and se <= r){
        return tree[index];
    }

    // Partial Overlap
    int mid = (ss+se)/2;
    int left = query(tree , ss , mid , l , r , 2*index);
    int right = query(tree , mid+1 , se , l , r , 2*index+1);

    return min(left , right);

}

void update(int tree[] , int ss , int se , int i , int y , int index){
    // No Overlap
    if(i > se or i < ss){
        return;
    }

    // Full Overlap
    if(ss == se){
        if(ss == i)
            tree[index] = y;
        return;
    }

    // Partial Overlap
    int mid = (ss+se)/2;
    update(tree , ss , mid , i , y , 2*index);
    update(tree , mid+1 , se , i , y , 2*index+1);

    tree[index] = min(tree[2*index] , tree[2*index+1]);

    return;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n , q;
    cin>>n>>q;

    int a[n];
    loop(n) cin>>a[i];

    int tree[4*n+1];
    buildTree(tree , a , 0 , n-1 , 1);

    while(q--){
        int x;
        cin>>x;
        if(x == 1){
            int l , r;
            cin>>l>>r;

            cout<<query(tree , 0 , n-1 , l-1 , r-1 , 1)<<endl;
        }
        else{
            int i , y;
            cin>>i>>y;

            update(tree , 0 , n-1 , i-1 , y , 1);
        }
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
