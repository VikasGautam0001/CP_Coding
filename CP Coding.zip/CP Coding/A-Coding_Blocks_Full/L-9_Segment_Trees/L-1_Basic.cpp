#include<bits/stdc++.h>
using namespace std;

void update(int *tree , int ss , int se , int i , int value , int index){
    // leaf update Node
    // Out of bounds - No Overlap
    if(i > se || i < ss){
        return;
    }

    // Leaf Node
    if(ss == se){
        tree[index] = value;
        return ;
    }

    // Partial Overlap
    // Left and right call

    int  mid = (ss+se)/2;

    update(tree , ss , mid , i , value , 2*index);
    update(tree , mid+1 , se , i , value , 2*index+1);
    tree[index] = min(tree[2*index] , tree[2*index+1]);

    return;

}

int query(int *tree , int ss , int se , int l , int r , int index){

    // Complete Overlap
    if(ss >= l and se <= r){
        return tree[index];
    }
    // No Overlap
    if((ss < l and se < l) or (ss > r and se > r)){
        return INT_MAX;
    }

    // Partial Overlap
    int mid = (ss + se)/2;

    return min(query(tree , ss , mid , l , r , index*2) , query(tree , mid+1 , se , l , r , index*2+1));

}


void buildTree(int a[] , int s , int e , int tree[] , int index){

    // Base Case
    if(s == e){
        tree[index] = a[s];
        return ;
    }

    // Rec Case
    int mid = (s+e)/2;
    buildTree(a , s , mid , tree , 2*index);
    buildTree(a , mid+1 , e , tree , 2*index+1);
    tree[index] = min(tree[2*index] , tree[2*index+1]);

    return ;
}

int main(){

    int a[] = {1 , 3 , 2  , -5 , 6 , 4};
    int n = sizeof(a)/sizeof(a[0]);

    int *tree = new int[4*n+1];
    // or we can simply do
    // int tree[4*n+1];
    // 4*n+1 is the maximum length of tree that can be possible.


    buildTree(a , 0 , n-1 , tree , 1);

    // Print the tree;

    for(int i = 1; i <= 13; i++)    cout<<tree[i]<<" ";

    // We have built a segment tree.

    // Next is to solve the query.

    // Find minimum in range
    cout<<"Enter the Range in which you have to find the minimum"<<endl;
    int l , r;
    cin>>l>>r;

    cout<<query(tree , 0 , n-1 , l , r , 1);


    // Now will do updates

    int i , value;
    cout<<"Enter index and value for updation."<<endl;
    cin>>i>>value;

    update(tree , 0 , n-1 , i , value , 1);



    // Another query.
    cout<<"Enter the Range in which you have to find the minimum"<<endl;

    cin>>l>>r;

    cout<<query(tree , 0 , n-1 , l , r , 1);


    return 0;
}
