#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);

struct treeNode{
    vi temp;
};

void buildTree(treeNode tree[] , int a[] , int s , int e ,int index){
    if(s == e){
        (tree[index].temp).pb(a[s]);
        return ;
    }

    // Recursive case
    int mid = (s+e)/2;
    buildTree(tree , a , s , mid , 2*index);
    buildTree(tree , a , mid+1 , e , 2*index+1);

    int i = 0 , j = 0;
    int n1 = (tree[2*index].temp).size();
    int n2 = (tree[2*index+1].temp).size();


    while(i < n1 and j < n2){
        if((tree[2*index].temp).at(i) <= (tree[2*index+1].temp).at(j)){
            (tree[index].temp).pb((tree[2*index].temp).at(i));
            i++;
        }
        else{
            (tree[index].temp).pb((tree[2*index+1].temp).at(j));
            j++;
        }
    }

    while(i < n1){
        (tree[index].temp).pb((tree[2*index].temp).at(i));
            i++;
    }
    while(j < n2){
        (tree[index].temp).pb((tree[2*index+1].temp).at(j));
            j++;
    }

}

int query(treeNode tree[] , int ss , int se , int l , int r , int k , int index){
    // No Overlap
    if(l > se or r < ss){
        return 0;
    }
    // Full Overlap
    if(ss >= l and se <= r){

        int lower = lower_bound(all(tree[index].temp) , k) - (tree[index].temp).begin();
        return (tree[index].temp).size()-lower;
    }
    // Partial Overlap
    int mid = (ss+se)/2;


    return (query(tree , ss , mid , l  , r , k , 2*index)+
    query(tree , mid+1 , se , l , r , k , 2*index+1) );
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n;
    cin>>n;

    int a[n];
    loop(n) cin>>a[i];

    treeNode tree[4*n+1];
    buildTree(tree , a , 0 , n-1 , 1);

    int q;
    cin>>q;

    while(q--){
        int l , r , k;
        cin>>l>>r>>k;
        cout<<query(tree , 0 , n-1 , l-1 , r-1 , k , 1)<<endl;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
