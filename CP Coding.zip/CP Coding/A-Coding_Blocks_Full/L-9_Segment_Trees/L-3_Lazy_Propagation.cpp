#include<bits/stdc++.h>
using namespace std;

// In Case of lazy updation query function

void buildTree(int a[] , int tree[] , int s , int e , int index){
    // Base Case
    if(s == e){
        tree[index] = a[s];
        return ;
    }

    // Recursive Case
    int mid = (s+e)/2;

    buildTree(a , tree , s , mid , 2*index);
    buildTree(a , tree , mid+1 , e , 2*index+1);

    tree[index] = min(tree[2*index] , tree[2*index+1]);

    return ;
}

void updateRangeLazy(int tree[] , int lazy[] , int ss , int se , int l , int r , int inc , int index){

    // If we already have lazy value at node , first resolve it.
    if(lazy[index] != 0){
        tree[index] += lazy[index];

        // if not a leaf node
        if(ss != se){
            lazy[2*index] += lazy[index];
            lazy[2*index+1] += lazy[index];
        }
        lazy[index] = 0;
    }

    // Out of Bounds
    if(r < ss or l > se){
        return;
    }

    // Complete Overlap
    if(ss >= l and se <= r){
        tree[index] += inc;

        // Pass the lazy value to children;
        if(ss != se){
            lazy[2*index] += inc;
            lazy[2*index+1] += inc;
        }

        return;
    }

    // Call on left and right ;
    int mid = (ss+se)/2;

    updateRangeLazy(tree , lazy , ss , mid , l , r , inc , 2*index);
    updateRangeLazy(tree , lazy , mid+1 , se , l , r , inc , 2*index+1);
    tree[index] = min(tree[2*index] , tree[2*index+1]);

    return;
}

int query(int tree[] , int lazy[] , int ss , int se , int l , int r , int index){

    if(lazy[index] != 0){
        tree[index] += lazy[index];
        if(ss != se){
            lazy[2*index] += lazy[index];
            lazy[2*index+1] += lazy[index];
        }

        lazy[index] = 0;
    }

    // Out of range
    if(r < ss or l > se){
        return INT_MAX;
    }

    // Complete Overlap
    if(ss >= l and se <= r){
        return tree[index];
    }

    // Partial Overlap

    int mid = (ss+se)/2;

    return min(query(tree , lazy , ss , mid , l , r , 2*index),
    query(tree , lazy , mid+1 , se , l , r , 2*index+1));

}


int main(){

    int a[] = {1 , 3 , 2  , -5 , 6 , 4 , 0};
    int n = sizeof(a)/sizeof(a[0]);

    int tree[4*n+1] , lazy[4*n+1] = {0};

    buildTree(a , tree , 0 , n-1 , 1);

    cout<<"Enter range and increement in each element"<<endl;
    int l , r , inc;
    cin>>l>>r>>inc;

    updateRangeLazy(tree , lazy , 0 , n-1 , l , r , inc , 1);

    cout<<"Enter l and r for minimum query:"<<endl;
    int l1 , r1;
    cin>>l1>>r1;
    cout<<query(tree , lazy , 0 , n-1 , l1 , r1 , 1);

    return 0;
}
