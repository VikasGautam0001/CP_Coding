#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);

void updateLazy(int tree[] , int lazy[] , int ss , int se , int l , int r , int num , int index){

    if(lazy[index] != -1){
        if(ss != se){
            lazy[2*index] = lazy[index];
            lazy[2*index+1] = lazy[index];
        }
        lazy[index] = -1;
    }

    // No Overlap
    if(se < l or ss > r){
        return;
    }

    // Full Overlap
    if(ss >= l and se <= r){
        tree[index] = num;
        lazy[index] = num;
        return;
    }

    // Partial Overlap
    int mid = (ss+se)/2;
    updateLazy(tree , lazy , ss , mid , l , r , num , 2*index);
    updateLazy(tree , lazy , mid+1 , se , l , r , num , 2*index+1);


    return;

}

void query(int tree[] , int lazy[] , int ss , int se , int l , int r , int index){

}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n , q;
    cin>>n>>q;

    int a[n] = {0};

    int tree[4*n-1] = {0} , lazy[4*n-1];
    memset(lazy , -1 , 4*n-1);


    while(q--){
        int x , l , r;
        cin>>x>>l>>r;

        if(x == 0){
            updateLazy(tree , lazy , 0 , n-1 , l , r , 0 , 1);
        }
        else if(x == 1){
            updateLazy(tree , lazy , 0 , n-1 , l , r , 1 , 1);
        }
        else{
            cout<<query(tree , lazy , 0 , n-1 , l , r , 1);
        }
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
