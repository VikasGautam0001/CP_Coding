#include<iostream>
using namespace std;
int* fun(int a[2][2])
{
    a[0][0] = 2;
    return &a[0];
}
int main()
{

    int a[2][2]={{1,2},{3,4}};
    int (*ptr)[2]= fun(a);
    for(int i = 0; i < 2; i++){
        for(int j = 0; j < 2; j++)
            cout<<*(*(ptr+i) + j);
    }
    return 0;
}
