#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
vii mul(vii a , vii b , int n){
    vii mult(n , vi(n));
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            for(int k = 0; k  < n; k++)
                mult[i][j] = (mult[i][j] + (a[i][k]*b[k][j])%MOD)%MOD;
        }
    }
    return mult;
}

vii binpow(vii T , int b , vii identity ,int n){
    if(b == 0)
        return identity;
    vii ans(n , vi(n));
    ans = binpow(T , b/2 , identity , n);
    ans = mul(ans , ans , n);
    if(b & 1)
        return mul(ans , T , n);
    else
        return ans;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    test{
        int k;
        cin>>k;
        vii f1(k,vi(1));
        vii T(k , vi(k));
        for(int i = 0; i < k; i++){
            for(int j = 0; j < 1; j++)
                cin>>f1[i][j];
        }
        vi temp(k);
        loop(k) cin>>temp[i];
        reverse(temp.begin() , temp.end());
        int n;
        cin>>n;
        if(n <= k){
            cout<<f1[n-1][0]<<endl;
            continue;
        }
        for(int i = 0; i < k-1; i++){
            for(int j = 0; j < k; j++){
                if(j == i+1)
                    T[i][j] = 1;
                else
                    T[i][j] = 0;
            }
        }
        for(int j = 0; j < k; j++){
            T[k-1][j] = temp[j];
        }
        vii identity(k,vi(k));
        for(int i = 0; i < k; i++){
            for(int j = 0; j < k; j++)
                if(i == j)
                    identity[i][j] = 1;
        }
        vii final(k , vi(k));
        final = binpow(T , n-k , identity , k);
        int sum = 0;
        for(int i = 0; i < k; i++){
            sum += (final[k-1][i] * f1[i][0]);
        }
            cout<<sum%MOD<<endl;
    }
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
