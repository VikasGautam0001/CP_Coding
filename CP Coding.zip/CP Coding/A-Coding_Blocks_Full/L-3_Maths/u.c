#include<iostream>
using namespace std;
void fun(int *ptr)
{

    cout<<ptr[0];
}
int main()
{

    int a[2]=[1,2];
    fun(a);
}
