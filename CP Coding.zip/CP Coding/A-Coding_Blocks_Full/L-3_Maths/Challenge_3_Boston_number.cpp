#include<bits/stdc++.h>
using namespace std;
#define int long long int
int SumOfDigits(int num){
    string s = to_string(num);
    int sum = 0;
    for(int i = 0; i < s.length(); i++){
        sum += (s[i]-'0');
    }
    return sum;
}
int32_t main(){

    int n;
    cin>>n;
    int temp =  n;
    int sum = 0;
    bool isprime = true;
    for(int i = 2; i*i <= temp; i++){
        while(temp%i == 0){
            if(i >= 10)
                sum += SumOfDigits(i);
            else
                sum += i;
            temp /= i;
            isprime = false;
        }
    }
    if(isprime){
        cout<<0<<endl;
        return 0;
    }
    if(temp > 2){
        sum += SumOfDigits(temp);
    }
    if(sum == SumOfDigits(n))
        cout<<1<<endl;
    else
        cout<<0<<endl;


    return 0;
}
