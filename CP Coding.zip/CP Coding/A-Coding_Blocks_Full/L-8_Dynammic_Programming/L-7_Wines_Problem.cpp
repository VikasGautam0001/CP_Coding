#include<bits/stdc++.h>
using namespace std;

int dp[100][100] = {0};

int Wines_Problem(int i , int j , int y , vector<int> &wines){

    // Base Case
    if(i > j){
        return 0;
    }

    if(dp[i][j] != 0){
        return dp[i][j];
    }

    // Recursive Case
    int ans1 =  wines[i]*y+(Wines_Problem(i+1 , j , y+1 , wines));
    int ans2 =  wines[j]*y+(Wines_Problem(i , j-1 , y+1 , wines));

    dp[i][j] =  max(ans1 , ans2);
    return dp[i][j];
}

int32_t main(){

    int n;
    cin>>n;
    vector<int> wines(n);
    for(int i = 0;  i < n; i++) cin>>wines[i];

    cout<<Wines_Problem(0 , n-1 , 1 , wines);

    return 0;
}
