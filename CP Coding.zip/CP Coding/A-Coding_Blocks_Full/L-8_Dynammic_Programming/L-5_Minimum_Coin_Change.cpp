#include<bits/stdc++.h>
using namespace std;


vector<int> dp(500);
vector<int> coins{1 , 2 , 5 , 10 , 20 , 50 , 100 , 200 , 500 , 2000};
int Min_Coin_Change(int n){
    // Base Case
    if(n == 0)  return 0;

    // Checking if already stored
    if(dp[n] != 0)  return dp[n];

    // Recursive Case
    int mini = INT_MAX;

    for(int i = 0; i < coins.size(); i++){
        if(coins[i] > n)
            break;
        int temp = Min_Coin_Change(n-coins[i]);
        mini = min(mini , temp);
    }
    dp[n] = mini+1;
    return dp[n];
}
int32_t main(){

    int n;
    cin>>n;

    cout<<Min_Coin_Change(n);

    return 0;
}
