#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n , k;
    cin>>n>>k;

    int ones = 0;
    vi arr(n);
    loop(n){    cin>>arr[i]; if(arr[i]) ones++; }

    if(ones == 0){
        cout<<0<<endl;
        loop(n) cout<<arr[i]<<" ";
        return 0;
    }

    int left , right , zero_count , max_length;
    left = right = zero_count = max_length = 0;

    int r = 0 , l = 0;

    loop(n){
        if(arr[i] == 0) zero_count++;

        while(zero_count > k){
            if(arr[left] == 0)  zero_count--;
            left++;
        }

        if(right-left+1 > max_length){
            r = right;
            l = left;
            max_length = right-left+1;
        }
        right++;
    }

    cout<<max_length<<endl;
    for(int i = 0; i < n; i++){
        if(i >= l and i <= r){
            cout<<1<<" ";
        }
        else
            cout<<arr[i]<<" ";
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
