#include<bits/stdc++.h>
using namespace std;
#define int long long int


// Basic Recursion
int fib(int n){
    // Base Case
    if(n == 1 or n == 0){
        return n;
    }

    // Recursive Case
    int ans;
    ans = fib(n-1)+fib(n-2);
    return ans;
}


// Dynammic Programming

// This is Top-down approach
vector<int> dp(101);

int fib_dp(int n){

    // Base Case
    if(n == 1 or n == 0){
        return n;
    }

    if(dp[n] != 0){
        return dp[n];
    }

    dp[n] = fib_dp(n-1)+fib_dp(n-2);

}

int32_t main(){


    dp[0] = 0;
    dp[1] = 1;

    int n;
    cin>>n;
    //cout<<fib(n);

    cout<<fib_dp(n);

    return 0;
}
