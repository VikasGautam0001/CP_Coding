#include<bits/stdc++.h>
using namespace std;
//#define int long long int

vector<int> coins{1 , 2 , 5 , 10 , 20 , 50 , 100 , 200 , 500 , 2000};

int Min_Coin(int n){
    vector<int> dp(500);

    for(int i = 1; i <= n; i++){
        int mini = INT_MAX;
        for(int j = 0; j < coins.size(); j++){
            if(coins[j] > i)
                break;
            if(i-coins[j] >= 0){
                mini = min(mini , dp[i-coins[j]]);
            }
        }
        dp[i] = mini+1;
    }
    return dp[n];
}
int32_t main(){

    int n ;
    cin>>n;

    cout<<Min_Coin(n);

    return 0;
}
