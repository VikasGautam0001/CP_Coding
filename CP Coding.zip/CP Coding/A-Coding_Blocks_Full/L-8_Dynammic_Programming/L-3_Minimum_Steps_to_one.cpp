#include<bits/stdc++.h>
using namespace std;

// Dynamic Programming

vector<int> dp(100);

int Recursive(int n){

    //  Base Case
    if(n == 1){
        return 0;
    }

    // Check if already stored.
    if(dp[n] != 0){
        return dp[n];
    }

    //
    int a , b , c;
    a = b =  INT_MAX;

    c = Recursive(n-1);

    if(n%2 == 0) a = Recursive(n/2);
    if(n%3 == 0) b = Recursive(n/3);

    dp[n] = min(min(a , b) , c) + 1;

    return  dp[n];
}

int32_t main(){

    int n ;
    cin>>n;

    cout<<Recursive(n);



    return 0;
}
