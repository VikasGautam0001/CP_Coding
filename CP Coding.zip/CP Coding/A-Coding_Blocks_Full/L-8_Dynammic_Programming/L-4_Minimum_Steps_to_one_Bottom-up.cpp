#include<bits/stdc++.h>
using namespace std;
//#define int long long int
bool comp(int a , int b){
    return (a<b);
}
int Minimum_Steps(int n){
    vector<int> dp(101 , 0);

    for(int i = 2; i <= n; i++){
        int a , b ;
        a = b = INT_MAX;

        if(i%2 == 0)    a = dp[i/2];
        if(i%3 == 0)    b = dp[i/3];

        dp[i] = min({a , b , dp[i-1]} , comp) + 1;
    }
    return dp[n];
}

int32_t main(){

    int n;
    cin>>n;

    cout<<Minimum_Steps(n);

    return 0;
}
