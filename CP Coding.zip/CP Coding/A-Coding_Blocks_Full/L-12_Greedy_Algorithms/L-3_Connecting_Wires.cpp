/*

In this question there are n white dots and n black dots . We have to connect each one white dot with black dot such that length of
connecting wire becomes minimum.
This is greedy problem.
*/
#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int t;
    cin>>t;

    int n = t/2;

    vi a(n) ,  b(n);
    loop(n) cin>>a[i];
    loop(n) cin>>b[i];

    sort(all(a));
    sort(all(b));

    int x = 0 , y = 0;
    int ans = 0;

    loop(n){
        ans += (abs(a[x]-b[y]));
        x++;
        y++;
    }

    cout<<ans<<endl;

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
