#include<bits/stdc++.h>
using namespace std;

int main(){
    int t;
    cin>>t;

    while(t--){

        int n , m , tower;
        cin>>n>>m>>tower;

        vector<int> xaxis , yaxis;

        xaxis.push_back(0);
        yaxis.push_back(0);

        xaxis.push_back(n+1);
        yaxis.push_back(m+1);

        while(tower--){
            int x , y;
            cin>>x>>y;
            xaxis.push_back(x);
            yaxis.push_back(y);
        }

        sort(xaxis.begin() , xaxis.end());
        sort(yaxis.begin() , yaxis.end());

        int max1 = 0 , max2 = 0;
        for(int i = 1; i < xaxis.size(); i++){

            max1 = max(max1, xaxis[i]-xaxis[i-1]-1);
            max2 = max(max2, yaxis[i]-yaxis[i-1]-1);
        }

        cout<<max1*max2<<endl;
    }
    return 0;
}
