#include<bits/stdc++.h>
using namespace std;

int make_change(int coins[] , int value , int n){

    auto it = upper_bound(coins , coins+n , value);
    it--;

    return *it;

}

int main(){

    int coins[] = {1 , 2 , 5 , 10 , 20 , 50 , 100 , 200 , 500 , 2000};
    int n = sizeof(coins)/sizeof(int);

    int value;
    cin>>value;

    while(value != 0){
        int ans = make_change(coins , value , n);
        value = value-ans;

        cout<<ans<<" ";

    }

    return 0;
}
