#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    while(1){
        int n;
        cin>>n;
        if(n == -1) break;

        vi a(n+1) , acc(n+1);

        int sum = 0;

        for(int i = 1; i <= n; i++){
            cin>>a[i];
            sum += a[i];
            acc[i] = sum;
        }

        if(sum%n != 0){
            cout<<-1<<endl;
            continue;
        }

        int fact = sum/n;
        int ans = 0;

        for(int i = 1; i <= n; i++){
            int temp = fact*i;
            ans = max(ans , abs(temp-acc[i]));
        }

        cout<<ans<<endl;

    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
