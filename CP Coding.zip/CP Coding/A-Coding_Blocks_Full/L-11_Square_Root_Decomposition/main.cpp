#include <bits/stdc++.h>

using namespace std;

int query(int a[] , int blocks[] , int l , int r ,int rn){
    int ans = 0;
    // First Part
    while(l < r and l%rn != 0){
        ans += a[l];
        l++;
    }


    // Middle part
    while(l+rn <= r){
        ans += blocks[l/rn];
        l += rn;
    }


    // Last Part
    while(l <= r){
        ans += a[l];
        l++;
    }

    return ans;

}

void update(int a[] , int blocks[] , int i , int val , int rn){
    int block_ide = i/rn;
    blocks[block_ide] += (val-a[i]);
    a[i] = val;
}

int main()
{
    int a[] = {1 , 3 , 5 , 2 , 7 , 6 , 3 , 1 , 4 , 8};
    int n = sizeof(a)/sizeof(int);

    int rn = sqrt(n);
    int blocks[rn+1] = {0};
    // Build a Blocks Array
    int block_id = -1;

    for(int i = 0; i < n; i++){
        if(i%rn == 0){
            block_id++;
        }

        blocks[block_id] += a[i];
    }

    // for(int no: blocks) cout<<no<<" ";

    // Updates and Queries
    update(a , blocks , 2 , 15 , rn);

    cout<<query(a , blocks , 2 , 8 , rn);
    return 0;
}
