#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);


void Bigfact(int num, vector<int> &arr){
    int res ;
    int carry = 0;
    for(int i = 0; i < arr.size(); i++){
        res = num*arr[i]+carry;
        carry = res/10;
        res = res%10;
        arr[i] = res;

    }
    while(carry){
        int rem = carry%10;
        carry /= 10;
        arr.pb(rem);
    }
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    vector<int> arr;
    arr.pb(1);
    int n;
    cin>>n;
    for(int i = 2; i <= n; i++){
        Bigfact(i,arr);
    }
    //cout<<arr.size()<<endl;
    for(int i = arr.size()-1; i >= 0; i--)
        cout<<arr[i];
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
