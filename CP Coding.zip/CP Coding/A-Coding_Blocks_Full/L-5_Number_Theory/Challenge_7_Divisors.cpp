#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
vi primeSeive(vi p , int n){
    p[0] = 0; p[1] = 0;
    for(int i = 2; i*i <= n; i++){
        if(p[i]){
            for(int j = i*i; j <= n; j += i)
                p[j] = 0;
        }
    }
    vi prime;
    for(int i = 2; i <= n; i++){
        if(p[i])
            prime.pb(i);
    }
    return prime;
}
vi factorize(int num ,vi &prime){
    int p = prime[0];
    vi temp;
    int i = 0;
    while(p*p <= num){
        if(num % p == 0){
            while(num % p == 0){
                temp.pb(p);
                num /= p;
            }
        }
        i++;
        p = prime[i];
    }
    if(num > 1)
        temp.pb(num);
    return temp;
}
int binpow(int a , int b){
    if(b == 1)
        return a;
    int res = binpow(a,b/2);
    if(b & 1)
        return res*res*a;
    else
        return res*res;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    vi p(1000000,1);
    vi prime = primeSeive(p,1000);
    test{
        int n;
        cin>>n;
        vi a(n),temp,final;
        loop(n){
            cin>>a[i];
            temp = factorize(a[i] , prime);
            for(auto zz: temp)
                final.pb(zz);
        }
        sort(final.begin(),final.end());
        /*for(auto no: final)
            cout<<no<<" ";
        cout<<endl;*/
        map<int,int> mp;
        for(int i = 0; i < final.size(); i++){
            mp[final[i]]++;
        }
        int prod = 1;
        for(int i = 0; i < final.size(); i++){
            if(mp[final[i]]){
                mp[final[i]]++;
                prod = (prod*mp[final[i]])%MOD;
                mp[final[i]] = 0;
            }
        }
        cout<<prod<<endl;
    }

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
