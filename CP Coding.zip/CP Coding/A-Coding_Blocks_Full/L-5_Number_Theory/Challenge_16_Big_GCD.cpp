#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int gcd(int a , int b){
    return b?gcd(b,a%b):a;
}
int FastModExp(int a , int b , int m){
    int res = 1;
    while(b){
        if(b&1)
            res = (res*a)%m;
        a = (a*a)%m;
        b >>= 1;
    }
    return res;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n;
    string m;
    cin>>n;
    cin>>m;
    if(n == 0 ){
        cout<<m<<endl;
        return 0;
    }
    if(m[0] == '0'){
        cout<<n<<endl;
        return 0;
    }
    reverse(m.begin(),m.end());
    int ans = 0;
    for(int i = 0; i < m.length(); i++){
        int x = m[i]-'0';
        x %= n;
        int mod = FastModExp(10,i,n);
        ans += ((x*mod)%n);
    }
    if(ans == 0){
        cout<<n<<endl;
    }
    else{
        cout<<gcd(n,ans)<<endl;
    }
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
