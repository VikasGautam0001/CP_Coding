#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define unn unsigned long long
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
unn FastModExp(unn a , unn b , unn m){
    unn res = 1;
    while(b){
        if(b & 1)
            res = (res*a)%m;
        a = (a*a)%m;
        b >>= 1;
    }
    return res;
}
bool millerTest(unn d , unn n){
    unn a = 2+rand()%(n-4);
    unn x = FastModExp(a,d,n);
    if(x == 1 || x == n-1)
        return true;
    while(d != n-1){
        x = (x*x)%n;
        d *= 2;
        if(x == 1) return false;
        if(x == n-1) return true;
    }
    return false;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);


    vector<bool> isprime(100000001,true);
    isprime[1] = false;
    for(int i = 2; i*i <= 100000000; i++){
        if(isprime[i]){
             for(int j = i*i; j <= 100000000; j += i){
                isprime[j] = false;
            }
        }
    }
    test{
        unn n;
        cin>>n;
        if(n == 2){
            cout<<"YES"<<endl;
            continue;
        }
        if(n % 2 == 0){
            cout<<"NO"<<endl;
            continue;
        }
        if(n <= 100000000){
            if(isprime[n])
                cout<<"YES"<<endl;
            else
                cout<<"NO"<<endl;
            continue;
        }
        unn d = n-1;
        while(d % 2 == 0)
            d /= 2;
        int flag = 1;
        for(int i = 0; i < 4; i++){
            if(!millerTest(d,n)){
                cout<<"NO"<<endl;
                flag = 0;
                break;
            }
        }
        if(flag)
            cout<<"YES"<<endl;
    }
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
