#include<iostream>
#include<cstring>
using namespace std;

int main() {
	int t;
	cin>>t;
	while(t--){
		string a , b , final;
		cin>>a>>b;
		int n = a.length();
		for(int i = 0; i < n; i++){
			if(a[i] != b[i]){
				final += '1';
			}
			else
				final += '0';
		}
		cout<<final<<endl;
	}
	return 0;
}
