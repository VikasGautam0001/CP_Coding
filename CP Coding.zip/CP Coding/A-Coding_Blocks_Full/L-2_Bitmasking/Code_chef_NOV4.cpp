#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    test{
        int l;
        cin>>l;
        vector<string> s(l);
        loop(l){
            cin>>s[i];
        }
        vector<string> a , b;
        int countA , countB , f1 = 0 , f2 = 0;
        loop(l){
            countA = 0;
            countB = 0;
            for(int j = 0; j < s[i].length(); j++){
                if(s[i].at(j) == 'a' || s[i].at(j) == 'e' || s[i].at(j) == 'i' || s[i].at(j) == 'o' || s[i].at(j) == 'u')
                    countA++;
                else
                    countB++;
            }
            if(countA >= countB){
                a.pb(s[i]);
                f1++;
            }
            else{
                b.pb(s[i]);
                f2++;
            }
        }
        map<char,int> m1 , m2;
        map<char,int> mch1 , mch2;
        loop(a.size()){
            map<char,bool> t2;
                for(int j = 0; j < a[i].length(); j++){
                    m1[a[i].at(j)] += 1;
                    if(t2[a[i].at(j)] == false){
                        t2[a[i].at(j)] = true;
                        mch1[a[i].at(j)] += 1;
                    }
                }
                t2.clear();
        }

        long double prod1 = 1;
        for(char ch = 'a'; ch <= 'z'; ch++){
            if(m1[ch] >= 1){
                prod1 *= (mch1[ch]*1.0)/(pow(m1[ch],f1));
            }
        }
        loop(b.size()){
            map<char,bool> t1;
                for(int j = 0; j < b[i].length(); j++){
                    m2[b[i].at(j)] += 1;
                    if(t1[b[i].at(j)] == false){
                        t1[b[i].at(j)] = true;
                        mch2[b[i].at(j)] += 1;
                    }
                }
                t1.clear();
        }
        long double prod2 = 1;
        for(char ch = 'a'; ch <= 'z'; ch++){
            if(m2[ch] >= 1){
                prod2 *= ((mch2[ch]*1.0)/(pow(m2[ch],f2)));
            }
        }
        if(prod1 == 0 && prod2 == 0)
            cout<<"Infinity"<<endl;
        else if(prod1 == 0)
            cout<<0<<endl;
        else if(prod2 == 0)
            cout<<"Infinity"<<endl;
        else if(prod1/prod2 > 10000000)
            cout<<"Infinity"<<endl;
        else{
            floatdigit(7);
            cout<<prod1/prod2<<endl;
        }

    }
  /*  test{
        int n,m;
        cin>>n>>m;
        vi a(n);
        loop(n) cin>>a[i];
        vii color(m);
        int z , flag = 0;
        for(int i = 0; i < n; i += m){
            flag++;
            for(int j = i , z = 0; j < (m*flag) && j < n; j++,z++){
                color[z].pb(a[j]);
            }
        }

    }*/
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
