#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int n;
    cin>>n;
    int a[n];
    int ans = 0;
    loop(n){
        cin>>a[i];
        ans = ans ^ a[i];
    }
    int temp = ans;
    int flag = 0;
    while(temp){
        if(temp & 1)
            break;
        flag++;
        temp >>= 1;
    }
    int first = 0;
    loop(n){
        int z = a[i]>>flag;
        if(z & 1)
            first = first ^ a[i];
    }
    cout<<first<<" "<<(first^ans)<<endl;
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
