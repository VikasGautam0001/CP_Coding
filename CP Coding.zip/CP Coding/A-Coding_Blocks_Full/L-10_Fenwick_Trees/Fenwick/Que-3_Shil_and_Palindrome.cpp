#include<bits/stdc++.h>
using namespace std;

struct node{
    int fenwick[26] = {0};
};
node BIT[100010];
void update(int i , char ch , int n){
    while(i <= n){
        BIT[i].fenwick[ch-'a']++;
        i += (i & (-i));
    }
}

void del(int i , char ch , int n){
    while(i <= n){
        BIT[i].fenwick[ch-'a']--;
        i += (i & (-i));
    }
}

vector<int> query(int i){
    vector<int> temp(26);

    while(i > 0){
        for(char ch = 'a'; ch <= 'z'; ch++){
            temp[ch-'a'] += BIT[i].fenwick[ch-'a'];
        }

        i -= (i & (-i));

    }

    return temp;
}

int main(){

    int n , q;
    cin>>n>>q;

    string s;
    cin>>s;

    for(int i = 0; i < n; i++){
        update(i+1 , s[i] , n);
    }



    while(q--){
        int a;
        cin>>a;

        if(a == 1){
            int pos;
            char ch;
            cin>>pos>>ch;


            del(pos , s[pos-1] , n);
            update(pos , ch , n);

            s[pos-1] = ch;
        }
        else{
            int l , r;
            cin>>l>>r;

            vector<int> lower(26) , upper(26);

            lower = query(l-1);
            upper = query(r);
            int odd = 0;

            for(int i = 0; i < 26; i++){
                if((upper[i]-lower[i]) & 1){
                    odd++;
                }
            }

            if(odd <= 1){
                cout<<"yes"<<endl;
            }
            else{
                cout<<"no"<<endl;
            }

        }
    }

    return 0;
}
