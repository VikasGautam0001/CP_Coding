#include<bits/stdc++.h>
using namespace std;



int query(int i , int BIT[]){

    int maxi = 0;
    while(i > 0){
        maxi = max(maxi , BIT[i]);
        i -= (i & (-i));
    }

    return maxi;
}

void update(int i , int n , int temp , int BIT[]){
    while(i <= n){
        BIT[i] = max(BIT[i] , temp);
        i += (i & (-i));
    }
}
int main(){

    int t;
    cin>>t;
    while(t--){

    int BIT[200010] = {0};
    int n;
    cin>>n;
    int a[n] , w[n];

    for(int i = 0; i < n; i++) cin>>a[i];
    for(int i = 0; i < n; i++) cin>>w[i];

    // Coordinate Compression

    set<int> s;
    for(int i = 0; i < n; i++){
        s.insert(a[i]);
    }

    unordered_map<int , int> store;

    int x = 0;
    for(auto it : s){
        x++;
        store[it] = x;
    }

    for(int i = 0; i < n; i++){
        a[i] = store[a[i]];

    }

    for(int i = 0; i < n; i++){
        int maxi = query(a[i]-1 , BIT);
        BIT[a[i]] = max(BIT[a[i]] , w[i]+maxi);
        update(a[i]+1 , n , BIT[a[i]] , BIT);
    }

    cout<<query(n , BIT)<<endl;

    }

    return 0;
}
