#include<bits/stdc++.h>
using namespace std;

int main(){

    int n;
    cin>>n;

    unordered_map<string , int> mp;

    for(int i = 0; i < n; i++){
        string s;
        int a;
        cin>>s>>a;
        mp[s] = a;
    }


    int q;
    cin>>q;

    while(q--){
        char ch;
        cin>>ch;

        if(ch == '+'){

        }
        else if(ch == '-'){

        }
        else{

        }
    }

    return 0;
}
