#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);

void update(int tree[] , int ss , int se , int l , int r , int val , int index){

    // No Overlap
    if(ss > r or se < l){
        return;
    }

    // Full Overlap
    if(ss >= l and se <= r){
        tree[index] += val;
        return;
    }

    // Partial Overlap
    int mid = (ss+se)/2;

    update(tree , ss , mid , l , r , val , 2*index);
    update(tree , mid+1 , se , l , r , val , 2*index+1);


    return;
}

int query(int tree[] , int ss , int se , int idx , int index){
    if(tree[index] != 0){
        if(ss != se){
            tree[2*index] += tree[index];
            tree[2*index+1] += tree[index];

            tree[index] = 0;
        }
    }

    // Full Overlap
    if(ss == idx and se == idx){
        return tree[index];
    }

    // No Overlap
    if(ss > idx  or se < idx){
        return 0;
    }

    // Partial Overlap
    int mid = (ss+se)/2;

    return (query(tree , ss , mid , idx , 2*index) + query(tree , mid+1 , se , idx , 2*index+1));

}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n , u;
        cin>>n>>u;

        int tree[4*n+1] = {0};

        while(u--){
            int l , r , val;
            cin>>l>>r>>val;

            update(tree , 0 , n-1 , l , r , val , 1);
        }

        int q;
        cin>>q;

        while(q--){
            int idx;
            cin>>idx;
            cout<<query(tree , 0 , n-1 , idx , 1)<<endl;
        }


    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
