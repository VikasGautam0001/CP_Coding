#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int BIT[2000005] = {0};

void update(int i , int val , int n){
    while(i <= n){
        BIT[i] += val;
        i += (i & (-i));
    }
}

int query(int i){
    int ans = 0;

    while(i > 0){
        ans += BIT[i];
        i -= (i & (-i));
    }

    return ans;
}

int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n;
        cin>>n;

        int a[n+1] , ori[n+1];
        set<int> s;

        for(int i = 1; i <= n; i++){
            cin>>a[i];
            s.insert(a[i]);
        }


        // Coordinate Compression
        int ct = 1;
        unordered_map<int , int> hashh;
        for(auto it : s){
            hashh[it] = ct;
            ct++;
        }
        for(int i = 1; i <= n; i++){
            ori[i] = hashh[a[i]];
        }

        int res = 0;
        for(int i = n; i >= 1; i--){
            res += query(ori[i]-1);
            update(ori[i] , 1 , n);
        }

        cout<<res<<endl;



    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
