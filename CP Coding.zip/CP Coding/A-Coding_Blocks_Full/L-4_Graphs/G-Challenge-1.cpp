/*Consider an undirected graph consisting of 'n' nodes where each node is labeled from 1 to n and the edge between any two nodes is always of length 6 . We define node 's' to be the starting position for a BFS.

Given 'q' queries in the form of a graph and some starting node, 's' , perform each query by calculating the shortest distance from starting node 's' to all the other nodes in the graph. Then print a single line of n-1 space-separated integers listing node s's shortest distance to each of the n-1 other nodes (ordered sequentially by node number); if 's' is disconnected from a node, print -1 as the distance to that node.

Input Format:
The first line contains an integer,q , denoting the number of queries. The subsequent lines describe each query in the following format:

Each line contains N and M, the number of nodes and edges respectively.

The next m lines contains u and v means that there is edge between u and v .

The last line contains 's', the starting node.*/

// This was the statement of the graph.

#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
class Graph{
    int V;
    list<int> *adjlist;
public:
    Graph(int v){
        V = v;
        adjlist = new list<int>[V+1];
    }
    void addEdge(int u , int v){
        adjlist[u].pb(v);
        adjlist[v].pb(u);
    }
    void bfs(int src){
        queue<int> q;
        map<int , bool> visited;
        map<int , int > dist;
        q.push(src);
        visited[src] = true;
        while(!q.empty()){
            int node = q.front();
            q.pop();
            for(int neighbour : adjlist[node]){
                if(!visited[neighbour]){
                    q.push(neighbour);
                    visited[neighbour] = true;
                    dist[neighbour] = dist[node] + 6;
                }
            }
        }
        for(int i = 1; i < V; i++){
            if(i == src)
                continue;
            else if(dist[i])
                cout<<dist[i]<<" ";
            else
                cout<<-1<<" ";
        }
        cout<<endl;
    }
};
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n , m;
        cin>>n>>m;
        Graph g(n+1);
        while(m--){
            int u , v;
            cin>>u>>v;
            g.addEdge(u , v);
        }
        int s;
        cin>>s;
        g.bfs(s);

    }
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
