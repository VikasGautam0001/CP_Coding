#include<bits/stdc++.h>
using namespace std;

class Graph{
    unordered_map<int , list<int> > adjlist;

public:
    void addEdge(int u , int v){
        adjlist[u].push_back(v);
        adjlist[v].push_back(u);
    }

    void helper(int key , map<int , bool> &visited){
        visited[key] = true;

        for(int neighbour : adjlist[key]){
            if(visited[neighbour]  == false){
                helper(neighbour , visited);
            }
        }
    }

    int dfs(){

        int cc = 0;

        map<int , bool> visited;

        for(auto all : adjlist){
            int key = all.first;

            if(!visited[key]){
                helper(key , visited);
                cc++;
            }
        }

        return cc;

    }
};

int main(){

    Graph g;
    g.addEdge(1 , 2);
    g.addEdge(2 , 3);
    g.addEdge(4 , 5);
    g.addEdge(6 , 7);

    cout<<g.dfs();
    return 0;
}
