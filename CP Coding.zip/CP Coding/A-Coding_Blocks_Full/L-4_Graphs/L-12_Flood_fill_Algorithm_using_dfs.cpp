#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int r , c;
void floodFill(char mat[][50] , int , int ,char , char);
void print(char mat[][50] , int r ,int c){
    loop(r){
        for(int j = 0; j < c; j++){
            cout<<mat[i][j];
        }
        cout<<endl;
    }
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    //cin.tie(NULL);
    //cout.tie(NULL);

    cout<<"Enter the row and column of matrix";
    cin>>r>>c;
    char mat[15][50];
    int k = 0;
    for(int i = 0; i < r; i++){
        if(i>(r/2))
            k--;
		else
            k++;
        for(int j = 0; j < c; j++){
            if(j>=4-k&&j<=2+k)          // This is the pattern.
                mat[i][j] = '#';
			else
                mat[i][j] = '.';
        }
    }
    cout<<endl;

    print(mat , r , c);
    int x ,y;
    char ch , color;
    /*cout<<"Enter the cell row and column you want to replace";
    cin>>x>>y;
    cout<<"Enter the characters you want to replace and replace with";
    cin>>ch>>color;*/
    floodFill(mat , 3 , 2 , '#' , 'R');
    print(mat , r , c);
    return 0;
}
int dx[] = {0,-1,0,1};
int dy[] = {-1,0,1,0};
void floodFill(char mat[][50] , int i , int j , char ch , char color){
    if(i<0||j<0||i>=r||j>=c)
        return ;
    if(mat[i][j] != ch)
        return ;
    mat[i][j] = color;
    print(mat , r ,c);
    cout<<endl;
    for(int k = 0; k < 4; k++){
        floodFill(mat , i+dx[k] , j+dy[k] , ch , color);
    }
}

//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
