#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
class Graph{
    int V;
    list<int> *adjlist;
public:
    Graph(int v){
        V = v;
        adjlist = new list<int>[V];
    }

    void addEdge(int u , int v , bool bidirect = true){
        adjlist[u].pb(v);
        if(bidirect){
            adjlist[v].pb(u);
        }
    }
    void print(){
        for(int i = 0; i < V; i++){
            cout<<i<<" -> ";
            for(int node: adjlist[i]){
                cout<<node<<",";
            }
            cout<<endl;
        }
    }
    void bfs(int src){
        queue<int> q;
        bool *visited = new bool[V]{0};
        int *dist = new int[V];
        dist[src] = 0;
        //int *parent = new int[V];
        q.push(src);
        visited[src] = true;
        while(!q.empty()){
            int node = q.front();
            q.pop();
            for(int neighbour : adjlist[node]){
                if(!visited[neighbour]){
                    q.push(neighbour);
                    visited[neighbour] = true;
                    dist[neighbour] = dist[node] + 1;
                    //parent[neighbour] = node;
                }
            }
            cout<<node<<" ";
        }
        cout<<endl;
        for(int i = 0; i < V; i++)
            if(i == src)
                cout<<i<<" This is the source node "<<endl;
            else
                cout<<i<<" Shortest Distance from "<<src<<" is : "<<dist[i]<<endl;
    }
};
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    Graph g1(6);

    g1.addEdge(0,1);
    g1.addEdge(0,4);
    g1.addEdge(1,2);
    g1.addEdge(2,3);
    g1.addEdge(2,4);
    g1.addEdge(3,4);
    g1.addEdge(3,5);

    g1.print();

    g1.bfs(0);
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
