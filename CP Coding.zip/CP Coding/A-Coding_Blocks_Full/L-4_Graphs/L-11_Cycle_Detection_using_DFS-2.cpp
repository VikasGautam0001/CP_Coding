#include<bits/stdc++.h>
using namespace std;

class Graph{
    map<int , list<int> > adjlist;

public:
    void addEdge(int u , int v){
        adjlist[u].push_back(v);
        adjlist[v].push_back(u);
    }

    bool helper(int key , map<int , bool> &visited , map<int , int > &parent){

        visited[key] = true;

        for(int neighbour : adjlist[key]){
            if(!visited[neighbour]){
                parent[neighbour] = key;
                return helper(neighbour , visited , parent);
            }
            else{
                if(parent[neighbour] != key){
                    return true;
                }
            }
        }

        return false;


    }

    bool dfs(){

        map<int , bool> visited;
        map<int , int> parent;

        parent[1] = 0;

        for(auto all : adjlist){
            int key = all.first;

            if(visited[key] == false){
                bool ans = helper(key , visited , parent);
                if(ans){
                    return ans;
                }
            }
        }

        return false;

    }
};

int main(){

    Graph g;
    g.addEdge(1 , 2);
    g.addEdge(2 , 3);
    g.addEdge(3 , 4);
    g.addEdge(4 , 1);

    bool ans = g.dfs();

    if(ans ) cout<<"Cycle detected"<<endl;
    else cout<<"No cycle detected"<<endl;

    return 0;
}
