/*Vivek takes out his Snakes and Ladders game and stares at the board, and wonders: If he had absolute control on the die (singular), and could get it to generate any number (in the range 1-6 ) he desired, what would be the least number of rolls of the die in which he'd be able to reach the destination square (Square Number 100) after having started at the base square (Square Number 1)?

RULES

Vivek has total control over the die and the face which shows up every time he tosses it.
you need to help him figure out the minimum number of moves in which he can reach the target square (100) after starting at the base (Square 1).

A die roll which would cause the player to land up at a square greater than 100, goes wasted, and the player remains at his original square. Such as a case when the player is at Square Number 99, rolls the die, and ends up with a 5.

If a person reaches a square which is the base of a ladder, (s)he has to climb up that ladder, and he cannot come down on it. If a person reaches a square which has the mouth of the snake, (s)he has to go down the snake and come out through the tail - there is no way to climb down a ladder or to go up through a snake.



Input Format:
The first line contains the number of tests, T. T testcases follow.

For each testcase, the first line contain N(Number of ladders) and after that N line follow. Each of the N line contain 2 integer representing the starting point and the ending point of a ladder respectively.

The next line contain integer M(Number of snakes) and after that M line follow. Each of the M line contain 2 integer representing the starting point and the ending point of a snake respectively.
*/

#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);

class Graph{
    map<int , list<int>  > adjlist;
public:
    void addEdge(int u , int v){
        adjlist[u].pb(v);
    }
    void bfs(){
        map<int , int> moves;
        map<int , bool> visited;
        queue<int> q;
        q.push(0);
        visited[0] = true;
        while(!q.empty()){
            int node = q.front();
            q.pop();

            for(int neighbour : adjlist[node]){
                if(!visited[neighbour]){
                    q.push(neighbour);
                    visited[neighbour] = true;
                    moves[neighbour] = moves[node] + 1;
                    //cout<<neighbour<<"-->"<<moves[neighbour]<<endl;
                }
            }
        }
        cout<<moves[100]<<endl;
    }
};
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
test{
    int n ;
    cin>>n;
    vi a(500,0);
    while(n--){
        int x , y;
        cin>>x>>y;
        a[x] = y-x;
    }
    int m;
    cin>>m;
    while(m--){
        int x , y;
        cin>>x>>y;
        a[x] = y-x;
    }
    Graph g;

    for(int i = 0; i < 100; i++){
        for(int j = 1; j <= 6; j++){
                if(i+j+a[i+j] <= 100)
                g.addEdge(i , i+j+a[i+j]);
        }
    }
    g.bfs();
 }   return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
