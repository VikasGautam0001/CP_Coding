#include <bits/stdc++.h>
using namespace std;
class Graph{

    map<string , list< pair<string , int> > > adjlist;

    public:

    void addEdge(string u , string v , int w){
        adjlist[u].push_back(make_pair(v , w));
        adjlist[v].push_back(make_pair(u , w));
    }

    int shortestPath(string src , string dest){
        map<string , int> dist;

        for(auto all : adjlist){
            dist[all.first] = INT_MAX;
        }

        dist[src] = 0;

        set<pair<int , string> > s;

        s.insert(make_pair(0 , src));

        while(!s.empty()){
            auto p = *(s.begin());

            string node = p.second;
            int nodeDist = p.first;

            s.erase(s.begin());

            for(auto neighbour : adjlist[node]){
                if(nodeDist + neighbour.second < dist[neighbour.first]){

                    string d = neighbour.first;

                    auto f = s.find(make_pair(dist[d] , d));
                    if(f != s.end()){
                        s.erase(f);
                    }

                    dist[d] = nodeDist + neighbour.second;

                    s.insert(make_pair(dist[d] , d ) );

                }

            }
        }

        return dist[dest];

    }

};
int main() {

    Graph g;

    g.addEdge("a" , "b" , 1);
    g.addEdge("b" , "c" , 1);
    g.addEdge("c" , "d" , 2);
    g.addEdge("a" , "c" , 4);
    g.addEdge("a" , "d" , 7);

    cout<<g.shortestPath("a" , "d");
    return 0;
}

