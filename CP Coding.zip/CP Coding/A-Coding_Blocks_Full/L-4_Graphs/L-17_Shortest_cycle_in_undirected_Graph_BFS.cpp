#include<bits/stdc++.h>

using namespace std;

class Graph{
    map<int , list<int > > adjlist;

public:
    void addEdge(int u , int v){
        adjlist[u].push_back(v);
        adjlist[v].push_back(u);
    }

    void bfs(int src , int &ans){

        queue<int> q;
        map<int , int> dist;

        for(int i = 1; i <= 5; i++){
            if(i != src)
                dist[i] = INT_MAX;
        }

        dist[src] = 0;

        q.push(src);

        while(!q.empty()){

            int node = q.front();
            q.pop();

            for(int neighbour : adjlist[node]){
                if(dist[neighbour] == INT_MAX){
                    q.push(neighbour);
                    dist[neighbour] = dist[node]+1;
                }
                else if(dist[neighbour] >= dist[node]){
                    ans = min(ans , dist[neighbour]+dist[node]+1);
                }
            }
        }
    }
};

int main(){


    Graph g;

    g.addEdge(1 , 2);
    g.addEdge(1 , 3);
    g.addEdge(2 , 4);
    g.addEdge(2 , 5);
    g.addEdge(4 , 5);
    g.addEdge(5 , 3);

    int ans = INT_MAX;

    for(int i = 1; i <= 5; i++){
        g.bfs(i , ans);
    }

    cout<<ans;

    return 0;
}
