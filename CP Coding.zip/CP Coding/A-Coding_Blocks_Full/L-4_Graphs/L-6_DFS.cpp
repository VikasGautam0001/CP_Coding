#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
class Graph{
    int V;
    list<int> *adjlist;
public:
    Graph(int v){
        V = v;
        adjlist = new list<int>[V];
    }
    void addEdge(int u , int v , bool bidir = true){
        adjlist[u].pb(v);
        if(bidir)
            adjlist[v].pb(u);
    }
    void dfs(int src){
        stack<int> s;
        bool *visited = new bool[V]{0};
        s.push(src);
        visited[src] = true;
        while(!s.empty()){
            int node = s.top();
            s.pop();
            for(int neighbour : adjlist[node]){
                if(!visited[neighbour]){
                    s.push(neighbour);
                    visited[neighbour] = true;
                }
            }
            cout<<node<<" ";
        }
    }
};
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    Graph g(7);
    g.addEdge(0,1);
    g.addEdge(0,2);
    g.addEdge(1,3);
    g.addEdge(1,4);
    g.addEdge(2,3);
    g.addEdge(3,6);
    g.addEdge(4,5);

    g.dfs(0);
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
