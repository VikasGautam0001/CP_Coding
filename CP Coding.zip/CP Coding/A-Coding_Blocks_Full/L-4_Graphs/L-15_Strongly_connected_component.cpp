#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
class Graph{
    int V;
    list<int> *adjlist;
public:
    Graph(int v){
        V = v;
        adjlist = new list<int>[V];
    }
    void addEdge(int u , int v , bool bidir = false){
        adjlist[u].pb(v);
        if(bidir)
            adjlist[v].pb(u);
    }
    void dfs_helper(map<int , bool> &visited ,int node ,int &count){
        visited[node] = true;
        count++;
        cout<<node<<" ";
        for(int neighbour : adjlist[node]){
            if(!visited[neighbour])
                dfs_helper(visited , neighbour , count);
        }
    }
    int dfs(int src){
        map<int , bool> visited;
        int count = 0;
        if(!visited[src])
            dfs_helper(visited , src , count);
        /*if(count == V){
            for(int i = 0; i < V; i++){
                for(int neighbour : adjlist[i]){
                    visited[neighbour] = false;
                    adjlist[i].remove(neighbour);
                    addEdge(neighbour , i);
                }
            }
            int count = 0;
            dfs_helper(visited , i , count)
        }
        else{
            cout<<"Graph is not strongly connected ";

        }*/
        return count;
    }
};
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    Graph g(5),gr(5);
    g.addEdge(0,1);
    g.addEdge(3,0);
    g.addEdge(0,3);
    g.addEdge(1,2);
    g.addEdge(3,4);
    g.addEdge(2,3);
    g.addEdge(4,3);

    if(g.dfs(0) == 5){


    gr.addEdge(0,3);
    gr.addEdge(1,0);
    gr.addEdge(3,0);
    gr.addEdge(2,1);
    gr.addEdge(4,3);
    gr.addEdge(3,2);
    gr.addEdge(3,4);

    if(gr.dfs(0) == 5)
        cout<<"Strongly connected component";
    else
        cout<<"Weakly connected component";
    }
    else
        cout<<"Weakly connected component";
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
