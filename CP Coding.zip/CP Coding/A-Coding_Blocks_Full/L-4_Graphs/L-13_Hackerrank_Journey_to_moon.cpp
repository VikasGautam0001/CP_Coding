#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
class Graph{
    int V , count;
    list<int> *adjlist;
public:
    Graph(int v){
        V = v;
        adjlist = new list<int>[V];
    }
    void addEdge(int u , int v){
        adjlist[u].pb(v);
        adjlist[v].pb(u);
    }
    void dfs_helper(map<int , bool> &visited , int node){
        visited[node] = true;
        count++;
        for(int neighbour : adjlist[node]){
            if(!visited[neighbour]){
                dfs_helper(visited , neighbour);
            }
        }
    }
    void dfs(){
        int sum = 0;
        map<int , bool> visited;
        for(int i  = 0; i < V; i++){
            count = 0;
            if(!visited[i]){
                dfs_helper(visited , i);
                sum += count*(count-1)/2;
            }
        }
        int final = V*(V-1)/2;
        cout<<final-sum<<endl;
    }
};
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int m , n;
    cin>>m>>n;

    Graph g(m);

    while(n--){
        int x , y;
        cin>>x>>y;
        g.addEdge(x , y);
    }
    g.dfs();
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
