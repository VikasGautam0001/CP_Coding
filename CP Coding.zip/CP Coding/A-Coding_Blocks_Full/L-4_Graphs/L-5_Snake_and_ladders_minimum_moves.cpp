#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
class Graph{
    int V;
    list<int> *adjlist;
public:
    Graph(int v){
        V = v;
        adjlist = new list<int>[V];
    }
    void addEdge(int u , int v , bool bidir = false){
        adjlist[u].pb(v);
        if(bidir)
            adjlist[v].pb(u);
    }
    void print(){
        for(int i = 0; i < V; i++){
            int row = i;
            cout<<row<<"--> ";
            for(int element : adjlist[row]){
                cout<<element<<",";
            }
            cout<<endl;
        }
    }
    void bfs(int src , int dest){
        queue<int> q;
        bool *visited = new bool[V]{0};
        int *parent = new int[V];
        for(int i = 0; i < V; i++)
            parent[i] = -1;
        q.push(src);
        visited[src] = true;
        while(!q.empty()){
            int node = q.front();
            q.pop();
            for(int neighbour : adjlist[node]){
                if(!visited[neighbour]){
                    q.push(neighbour);
                    visited[neighbour] = true;
                    parent[neighbour] = node;
                }
            }
        }
        int temp = dest;
        int moves = -1;
        while(temp != -1){
            cout<<temp<<"<--";
            temp = parent[temp];
            moves++;
        }
        cout<<endl<<" No. of moves = "<<moves;
    }
};
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    Graph g(50);
    vi board(50);
    board[2] = 13;
    board[5] = 2;
    board[17] = -13;
    board[18] = 11;
    board[20] = -14;
    board[24] = -8;
    board[25] = 10;
    board[32] = -2;
    board[34] = -22;

    for(int u = 0; u < 36; u++){
        for(int dice = 1; dice <= 6; dice++){
            int v = u+dice+board[u+dice];
            g.addEdge(u , v);
        }
    }
    g.bfs(0,36);
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
