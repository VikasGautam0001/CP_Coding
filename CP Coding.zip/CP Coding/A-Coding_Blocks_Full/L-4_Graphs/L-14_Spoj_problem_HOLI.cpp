#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
class Graph{
    int V;
    list<ii> *adjlist;
public:
     Graph(int v){
        V = v;
        adjlist = new list<ii>[V];
     }
     void addEdge(int u , int v , int cost , bool bidir = true){
        adjlist[u].pb(mp(v , cost));
        if(bidir)
            adjlist[v].pb(mp(u , cost));
     }
     int dfs_helper(int node , bool *visited , int *count ,int &ans){
        visited[node] = true;
        count[node] = 1;
        for(auto neighbour : adjlist[node]){
            int v = neighbour.first;
            if(!visited[v]){
                count[node] += dfs_helper(v , visited , count , ans);
                ans += 2*min(count[v] , V-count[v])*neighbour.second;
            }
        }
        return count[node];
     }

     int dfs(){
        bool *visited = new bool[V]{0};
        int *count = new int[V]{0};

        int ans = 0;
        dfs_helper(0 , visited , count , ans);

        for(int i = 0; i < V; i++){
            if(!visited[i])
                dfs_helper(i,visited,count,ans);
        }/*
        for(int i = 0; i < V; i++){
            cout<<count[i]<<" ";
        }*/
        return ans;
     }
};
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    Graph g(4);

    g.addEdge(0 , 1 , 3);
    g.addEdge(1 , 2 , 2);
    g.addEdge(3 , 2 , 2);
    //g.addEdge(2 , 4 , 2);
    cout<<g.dfs();
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
