#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
template<typename T>
//WE can make graph weighted by making list of pair of string and int.
//int denotes the distance between them.
class Graph{
    int V;
    map<T,list<T>> adjlist;
public:

    void addEdge(T u, T v , bool bidir = true){
        adjlist[u].pb(v);
        if(bidir){
            adjlist[v].pb(u);
        }
    }
    void print(){
        for(pair<T,list<T>> row:adjlist){
            T key = row.first;
            cout<<key<<"->";
            for(T element : row.second){
                cout<<element<<",";
            }
            cout<<endl;
        }
    }
};
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    Graph<string> g;
    g.addEdge("Amritsar" , "Delhi");
    g.addEdge("Amritsar" , "Jaipur");
    g.addEdge("Delhi" , "Siachen");
    g.addEdge("Amritsar" , "Bangalore");
    g.addEdge("Delhi" , "Agra");
    g.addEdge("Amritsar" , "Saichen");

    g.print();
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
