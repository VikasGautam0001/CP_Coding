#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
template<typename T>
class Graph{
    int V;
    map<T,list<T>> adjlist;
public:
    void addEdge(T u , T v , bool bidir = true){
        adjlist[u].pb(v);
        if(bidir)
            adjlist[v].pb(u);
    }
    void check(T src , map<T, bool> &visited){
        visited[src] = true;
        cout<<src<<",";

        for(T neighbour : adjlist[src]){
            if(!visited[neighbour]){
                check(neighbour , visited);
            }
        }
    }
    void dfs(T src){
        map<T , bool> visited;
        int component = 0;
        cout<<"Connected components are "<<endl;
        for(auto arr : adjlist){
            T key = arr.first;
            if(!visited[key]){
               check(key , visited);
               component++;
               cout<<endl;
            }
        }
        cout<<"Total connected components are "<<component;
    }
};
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    Graph<string> g;
    /*g.addEdge(0,1);
    g.addEdge(0,2);
    g.addEdge(1,3);
    g.addEdge(1,4);
    g.addEdge(2,4);
    g.addEdge(2,3);

    g.addEdge(5,6);
    g.addEdge(6,7);*/

    g.addEdge("Amritsar", "Jaipur");
    g.addEdge("Amritsar" , "Delhi");
    g.addEdge("Delhi" , "Jaipur");
    g.addEdge("Delhi" , "Bhopal");
    g.addEdge("Mumbai" , "Jaipur");
    g.addEdge("Mumbai" , "Bhopal");
    g.addEdge("Mumbai" , "Delhi");

    g.addEdge("Andaman" , "Nicobar");
    g.dfs("Amritsar");
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//

