#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
class Car{
public:
    int x,y,id;
    Car(int id,int x , int y){
        this->id = id;
        this->x = x;
        this->y = y;
    }
    int dist(){
        return (x*x + y*y);
    }
    void print(){
        cout<<"Id : "<<id<<" "<<"at "<<x<<" "<<y;
        cout<<"\n";
    }
};
class MyCar{//Functor Class.
public:
    bool operator()(Car a,Car b){
        return a.dist() > b.dist();//Making MIN heap.
    }
};
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    priority_queue<Car,vector<Car>,MyCar> pq;
    int k;
    cin>>k;//How many nearest cars from origin you want to print.
    int x[] = {5,6,4,7,3,1};
    int y[] = {3,7,8,1,4,2};
    loop(6){
        Car cc(i,x[i],y[i]);
        pq.push(cc);
    }
    int j = 1;
    while(!pq.empty()&&j<=k){
        Car c = pq.top();
        c.print();
        pq.pop();
        j++;
    }
    //Car c = pq.top();
    //c.print();
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
