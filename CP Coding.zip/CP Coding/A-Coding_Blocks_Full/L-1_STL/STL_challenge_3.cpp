#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int z = 10;
    while(z--){

    string str1 , str2;
    getline(cin,str1);
    getline(cin,str2);
    int n1 = str1.length();
    int n2 = str2.length();
    if(n2 == 1){
        for(int i = 0; i < n1; i++){
            if(str1[i] == str2[0]){
                cout<<str2[0]<<endl;
                return 0;
            }
        }
        cout<<"No string"<<endl;
        return 0;
    }
    vector<pair<int,int>> a;
    int m , temp1 = -1 , temp2;
    for(int i = 0; i < n1; i++){
        temp2 = 0;
        for(int j = temp1+1,m = 0; j < n1; j++){
            if(m == 0){
                if(str2[m] == str1[j]){
                    temp1 = j;
                    m++;
                }
            }
            else{
                if(str2[m] == str1[j]){
                    if(m == n2-1){
                        temp2 = j;
                        break;
                    }
                    m++;
                }
            }
        }
        if(temp2){
            a.pb(make_pair(temp1,temp2));
        }
        else{
            if(a.size() == 0){
                cout<<"No string"<<endl;
                return 0;
            }
            break;
        }
    }
    int diff = INT_MAX;
    int x,y;
    cout<<a.size()<<endl;
    for(int i = 0; i < a.size(); i++){
        if(diff > (a[i].second-a[i].first)){
            diff = (a[i].second-a[i].first);
            y = a[i].second;
            x = a[i].first;
        }
    }
    string s;
    for(int i = x; i <= y; i++){
        s += str1[i];
    }
    cout<<s<<endl;}
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
