#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int main(){
    vector<char> v;
    for(int i = 0; i < 10; i++) v.push_back(65+i);
    vector<char> v2(10);
    reverse_copy(v.begin() , v.end() , v2.begin());
    for(auto it = v2.begin(); it != v2.end(); it++) cout<<*it<<" ";
    return 0;
}
