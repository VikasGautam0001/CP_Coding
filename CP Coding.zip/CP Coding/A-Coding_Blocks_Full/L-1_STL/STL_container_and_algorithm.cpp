#include<iostream>
#include<algorithm>
using namespace std;
bool isminimum(int n){
    if(n <= 10) return true;
    return false;
}
int main(){
    int n;
    cin>>n;
    int arr[n];
    for(int i = 0; i < n; i++) cin>>arr[i];
    remove_if(arr , arr+n , isminimum);
    for(int i = 0; i < 3; i++)//3 denotes the no. of elments left after removing from the array.
        cout<<arr[i]<<" ";
    return 0;
}
