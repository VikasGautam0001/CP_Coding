#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
vi a{1 , 2  , 5 , 10 , 20 , 50 , 100 , 200  , 500 , 2000};
bool compare(int a , int b){
    return a<=b;
}
void Recur(int money){
    // Base Case
    if(money == 0){
        return;
    }
    // Recursive Case
    // Find lower_bound of n
    // lower bound will take the iterator to the point
    // which is not less than n;

    int it = lower_bound(a.begin() , a.end() , money , compare)-a.begin()-1;
    int aa = money/a[it];
    cout<<aa<<" notes of "<<a[it]<<endl;
    Recur(money-(aa*a[it]));
    return;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);


    int n;
    cin>>n;



    Recur(n);

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
