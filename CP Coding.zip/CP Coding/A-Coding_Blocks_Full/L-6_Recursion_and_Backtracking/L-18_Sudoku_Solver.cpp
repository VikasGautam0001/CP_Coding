#include<bits/stdc++.h>
using namespace std;
#define int long long int
int32_t main(){

    int n , m;
    cin>>n>>m;

    return 0;
}
