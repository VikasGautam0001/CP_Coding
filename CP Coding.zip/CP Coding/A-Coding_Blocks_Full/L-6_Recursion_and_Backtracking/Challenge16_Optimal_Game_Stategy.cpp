#include<bits/stdc++.h>
using namespace std;
int n;
int Go(int arr[] , int i , int j){
    if(i > j)
        return 0;

    return max(arr[i]+min(Go(arr , i+2 , j) , Go(arr , i+1 , j-1))
                , arr[j]+ min(Go(arr , i+1 , j-1)  , Go(arr , i , j-2) )  );

}
int32_t main(){


    cin>>n;
    int arr[n];
    for(int i = 0; i < n; i++) cin>>arr[i];

    cout<<Go(arr , 0 , n-1);
    return 0;
}
