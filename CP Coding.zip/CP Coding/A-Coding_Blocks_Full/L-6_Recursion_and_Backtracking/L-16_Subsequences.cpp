#include<bits/stdc++.h>
using namespace std;
#define int long long int
void Subsequences(char *in , char *out , int i , int j ){
    // Base Case
    if(in[i] == '\0'){
        out[j] = '\0';
        cout<<out<<endl;
        return;
    }
    // Recursive Case
    // 1. Include the current character

    out[j] = in[i];
    Subsequences(in , out , i+1 , j+1);

    // 2. To exclude the current character

    Subsequences(in , out , i+1 , j);
}
// Alternative method.
void Subsequences2(string s , string out ,int  n ,int i){
    if(i == n){
        cout<<out<<endl;
        return;
    }
    Subsequences2(s , out+s[i] , n , i+1);
    Subsequences2(s , out , n , i+1);
}


int32_t main(){

    char in[100] , out[100];
    cin>>in;
    Subsequences(in , out , 0 , 0);

    /*string s , out;
    cin>>s;
    int n = s.length();
    Subsequences2(s , out , n , 0);*/


    return 0;
}
