#include<bits/stdc++.h>
using namespace std;
//#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int n , ans;
void Recur(string s , int pos){
    if(pos == n){
        ans++;
        return;
    }



    Recur(s , pos+1);

    if(pos+1 < n){
        int first = s[
        pos]-'0';
        int second = s[pos]-'0';
        int a = first*10 + second;
        if(a <= 26)
            Recur(s , pos+2);
    }


}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    while(1){
        string s;
        cin>>s;
        if(s[0] == '0' && s.length() == 1)
            break;
        ans = 0;
        n = s.length();
        Recur(s , 0);
        cout<<ans<<endl;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
