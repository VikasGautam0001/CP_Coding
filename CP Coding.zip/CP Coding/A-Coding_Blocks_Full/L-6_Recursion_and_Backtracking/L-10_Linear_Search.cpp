#include<bits/stdc++.h>
using namespace std;
#define int long long int
int Search(int arr[] , int key,int n, int index){
    if(n == 0)
        return -1;
    if(arr[0] == key)
        return index;
    return Search(arr+1,key,n-1,index+1);
}
int32_t main(){

    int arr[10];
    int n;
    cin>>n;
    for(int i = 0; i < n; i++) cin>>arr[i];
    int key;
    cin>>key;
    int ans = Search(arr , key , n , 0);
    if(ans == -1)
        cout<<"key "<<key<<" not found"<<endl;
    else
        cout<<"Key found at index "<<ans<<endl;
    return 0;
}
