#include<bits/stdc++.h>
using namespace std;
#define int long long int
vector<vector<int>> store;
bool check(vector<int> temp){
    for(int i = 0; i < store.size(); i++){
        if(store[i] == temp)
            return false;
    }
    return true;
}
void Permute(vector<int> a , int pos , int n , int sum , vector<int> temp){
    // Base Case
    if(pos == n){
        int ss = 0;
        for(int no: temp) ss += no;
        if(ss == sum){
            if(check(temp))
                store.push_back(temp);
        }
        return;
    }

    // Recursive Case
    Permute(a , pos+1 , n , sum , temp);
    temp.push_back(a[pos]);
    Permute(a , pos+1 , n , sum , temp);
}
int32_t main(){

    int n;
    cin>>n;
    vector<int> a(n) , b;
    for(int i = 0; i < n; i++) cin>>a[i];
    int sum;
    cin >> sum;
    sort(a.begin() , a.end());
    Permute(a , 0 , n , sum , b);
    sort(store.begin() , store.end());
    for(int i = 0; i < store.size(); i++){
        for(int j = 0; j < store[i].size(); j++)
            cout<<store[i][j]<<" ";
        cout<<endl;
    }
    return 0;
}
