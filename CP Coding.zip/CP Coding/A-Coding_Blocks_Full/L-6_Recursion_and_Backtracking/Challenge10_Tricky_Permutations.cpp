#include<bits/stdc++.h>
using namespace std;
#define int long long int
vector<string> v;
/*bool check(string s){
    for(int i = 0; i < v.size(); i++)
        if(s == v[i])
            return false;
    return true;
}*/
bool IsSafe(char ch[] , int i , int j){
    for(int x = i; x < j; x++){
        if(ch[x] == ch[j])
            return false;
    }
    return true;
}
void Permute(char ch[] , int i){
    if(ch[i] == '\0'){
        v.push_back(ch);
        return;
    }
    for(int j = i; ch[j] != '\0'; j++){
        if(IsSafe(ch , i , j)){
            swap(ch[i] , ch[j]);
            Permute(ch , i+1);
            swap(ch[i] , ch[j]);
        }
    }
}
int32_t main(){

    char ch[10];
    cin>>ch;
    int n = -1;
    for(int i = 0; ch[i] != '\0'; i++) n++;
    sort(ch , ch+n);
    Permute(ch , 0);
    sort(v.begin() , v.end());
    for(auto s : v) cout<<s<<endl;
    //cout<<v.size();
    return 0;
}
