#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);

// Using Bitmasking
vi SubsetSum(vi arr ){
    vi temp;
    int sz = arr.size();

    for(int i = 0; i < (1<<sz); i++){
        int j = 0;
        int sum = 0;
        for(int no = i; no > 0; no >>= 1){
            if(no & 1){
                sum += arr[j];
            }
            j++;
        }
        temp.pb(sum);
    }
    return temp;
}

int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int  n , a , b;
    cin>>n>>a>>b;

    int n1 = n/2;
    int n2 = n-n1;
    vi a1 , a2;

    loop(n1){
        int x;
        cin>>x;
        a1.pb(x);
    }

    loop(n2){
        int x;
        cin>>x;
        a2.pb(x);
    }

    vi sum1 , sum2;

    sum1 = SubsetSum(a1);
    sum2 = SubsetSum(a2);

    sort(all(sum2));

    int ans = 0;
    for(int no: sum1){
        int lower = lower_bound(all(sum2) , a-no)-sum2.begin();
        int upper = upper_bound(all(sum2) , b-no)-sum2.begin();
        ans += upper-lower;
    }
    cout<<ans<<endl;

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //

