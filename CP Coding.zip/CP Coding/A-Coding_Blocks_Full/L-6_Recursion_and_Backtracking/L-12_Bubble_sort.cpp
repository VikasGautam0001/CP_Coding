#include<bits/stdc++.h>
using namespace std;
#define int long long int

// Recursion with loop
void BubbleSort(int arr[] , int n){
    if(n == 1)
        return ;
    for(int j = 0; j <= n-2; j++){
        if(arr[j] > arr[j+1])
            swap(arr[j] , arr[j+1]);
    }
    BubbleSort(arr , n-1);
}
// Full recursion
void BubbleSort2(int a[] , int j , int n){
    if(n == 1)
        return;
    if(j == n-1)
        return BubbleSort2(a , 0 , n-1);
    if(a[j] > a[j+1])
        swap(a[j] , a[j+1]);
    BubbleSort2(a , j+1 , n);
    return;
}
int32_t main(){

    int arr[] = {5,4,3,1,2};
    int n = 5;
    BubbleSort2(arr , 0 , 5);
    for(int i = 0; i < 5; i++)
        cout<<arr[i]<<" ";
    return 0;
}
