#include<bits/stdc++.h>
using namespace std;
#define int long long int
int Binary_Search(int arr[] , int key,int start , int end , int mid){
    mid = (start+end)/2;
    if(start > end)    return -1;
    if(key < arr[mid]){
        end = mid-1;
        return Binary_Search(arr,key,start,end,mid);
    }
    if(key == arr[mid])
        return mid;
    start = mid+1;
    return Binary_Search(arr,key,start,end,mid);

}
int32_t main(){

    int arr[10];
    int n;
    cin>>n;
    for(int i = 0; i < n; i++) cin>>arr[i];
    int key ;
    cin>>key;
    int start = 0;
    int end = n-1;
    int ans = Binary_Search(arr,key,start,end,0);
    if(ans == -1)
        cout<<"Key not found";
    else
        cout<<"Key found at "<<ans<<endl;
    return 0;
}
