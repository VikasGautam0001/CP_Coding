#include<bits/stdc++.h>
using namespace std;
#define int long long int
int dp[91][2];
void Go(int n){
    if(n == 1)
        return ;
    Go(n-1);
    dp[n][1] = dp[n-1][0];
    dp[n][0] = dp[n-1][0] + dp[n-1][1];
}
int32_t main(){
    dp[1][0] = 1;
    dp[1][1] = 1;

    Go(90);
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        cout<<(dp[n][0]+dp[n][1])<<endl;
    }
    return 0;
}
