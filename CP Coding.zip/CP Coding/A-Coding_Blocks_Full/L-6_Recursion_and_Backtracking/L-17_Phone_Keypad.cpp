#include<bits/stdc++.h>
using namespace std;
#define int long long int
vector<string> a{" " , ".+@$" , "abc" , "def" , "ghi" , "jkl" , "mno" , "pqrs" , "tuv" , "wxyz"};
void Go(string s , int pos , string final, int n){
    if(pos == n){
        cout<<final<<endl;
        return;
    }
    for(int i = 0; i < a[s[pos]-'0'].length(); i++){
        Go(s , pos+1 , final+a[s[pos]-'0'].at(i) , n);
    }
}
int32_t main(){
    string s;
    cin>>s;
    int n = s.length();
    string final = "";
    Go(s , 0 , final , n);
    return 0;
}
