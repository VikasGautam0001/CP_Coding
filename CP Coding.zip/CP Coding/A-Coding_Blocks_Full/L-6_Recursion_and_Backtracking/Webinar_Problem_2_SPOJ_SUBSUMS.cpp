#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
vi arr;
int n , a , b;
int ans = 0;

// This solution will take more than 1 sec of time as
// n <= 34 and it is recursion.
// will optimize the solution by breaking array into two parts.
void Recur( int pos , int sum){
    // Base Case
    if(pos == n){
        if(sum >= a and sum <= b)
            ans++;
        return;
    }
    // Recursive Cases

    Recur(pos+1 , sum);
    Recur(pos+1 , sum+arr[pos]);

}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);


    cin>>n>>a>>b;
    loop(n){
        int x;
        cin>>x;
        arr.pb(x);
    }

    Recur(0 , 0);
    cout<<ans<<endl;
    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
