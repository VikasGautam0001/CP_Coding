#include<bits/stdc++.h>
using namespace std;
#define int long long int
int ans = 0;
void Permute(vector<int> a  ,int pos  ,  int n ,int sum){
    // Base Case
    if(pos == n){
        if(sum == 0)
            ans++;
        cout<<sum<<" ";
        return ;
    }
    // Recursive Case
    Permute(a  , pos+1 , n , sum);
    sum += a[pos];
    Permute(a , pos+1 , n , sum);
}
int32_t main(){

    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        vector<int> a(n);
        for(int i = 0; i < n; i++) cin>>a[i];
        Permute(a , 0  , n , 0);
        cout<<endl;
        if(ans >= 2)
            cout<<"Yes"<<endl;
        else
            cout<<"No"<<endl;
    }
    return 0;
}
