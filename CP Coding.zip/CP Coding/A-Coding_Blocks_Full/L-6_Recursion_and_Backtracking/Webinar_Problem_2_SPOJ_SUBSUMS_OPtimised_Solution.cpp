#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int n ;
vi arr1 , arr2;

// Using Simple Recursion.
void SubsetSum(vi &arr ,int pos , int sum , int refer){

    // Base Case

    if(refer == 1)
    if(pos == n/2){
        arr1.pb(sum);
        return;
    }

    if(refer == 2)
    if(pos == n){
        arr2.pb(sum);
        return;
    }
    // Recursive Case

    SubsetSum(arr ,pos+1 , sum , refer);
    SubsetSum(arr ,pos+1 , sum+arr[pos] , refer);

}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int  a , b;
    cin>>n>>a>>b;

    vi arr(n);
    loop(n) cin>>arr[i];


    SubsetSum(arr , 0 , 0 , 1);
    SubsetSum(arr , n/2 , 0 , 2);

    sort(all(arr2));

    int ans = 0;
    for(int no: arr1){
        int lower = lower_bound(all(arr2) , a-no)-arr2.begin();
        int upper = upper_bound(all(arr2) , b-no)-arr2.begin();
        ans += upper-lower;
    }
    cout<<ans<<endl;

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
