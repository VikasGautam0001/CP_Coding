#include<bits/stdc++.h>
using namespace std;
vector<string> a{"Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine"};
void problem(int n ){
    if(n == 0)
        return ;
    problem(n/10);
    cout<<a[n%10]<<" ";
}
int main(){
    int n;
    cin>>n;
    problem(n);

    return 0;
}
