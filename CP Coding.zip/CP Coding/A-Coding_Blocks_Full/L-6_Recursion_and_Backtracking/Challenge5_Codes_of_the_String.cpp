#include<bits/stdc++.h>
using namespace std;
#define int long long int
vector<string> ans;
map<char,char> m;
void Go(string s ,string emp , vector<string> &temp , int pos , int n){
    if(pos == n){
        temp.push_back(emp);
        return ;
    }
    Go(s , emp+m[s[pos]-'0'] , temp , pos+1 , n);
    if(pos+2 <= n){
        int a = s[pos]-'0';
        a = a*10;
        int b = s[pos+1]-'0';
        if(a+b <= 26){
            Go(s , emp+m[a+b] , temp , pos+2 , n);
        }
    }

}
int32_t main(){
    for(int i = 1; i <= 26 ; i++) m[i] = char(96+i);
    string s;
    cin>>s;
    string emp = "";
    Go(s ,emp , ans , 0 , s.length());
    cout<<"[";
    for(int i = 0; i < ans.size(); i++){ cout<<ans[i];
    if(i < ans.size()-1)
    cout<<", ";
    }
    cout<<"]";
    return 0;
}
