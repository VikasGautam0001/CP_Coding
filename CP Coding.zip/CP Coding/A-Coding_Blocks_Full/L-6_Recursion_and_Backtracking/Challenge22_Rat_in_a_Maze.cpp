#include<bits/stdc++.h>
using namespace std;
#define int long long int
int x = 1;
bool Go(vector<vector<char>> mat , int i  , int j , int n , int m , vector<vector<int>> vi){
    // Base Case
    if(i == n-1 && j == m-1){
        x = 0;
        for(int i = 0; i < n; i++){
            for(int j = 0; j < m; j++)
                cout<<vi[i][j]<<" ";
            cout<<endl;
        }
        return true;
    }
    if(i >= n || j >= m)
        return false;

    if(mat[i][j+1] != 'X'){
        vi[i][j+1] = 1;
        bool flag = Go(mat , i , j+1 , n , m , vi);
        if(!flag)
            vi[i][j+1] = 0;
        else
            return true;
    }
    if(mat[i+1][j] != 'X'){
        vi[i+1][j] = 1;
        bool flag = Go(mat , i+1 , j , n , m , vi);
        if(!flag)
            vi[i+1][j] = 0;
        else
            return true;
    }
    return false;
}
int32_t main(){

    int n , m;
    cin>>n>>m;
    vector<vector<char>> mat(n , vector<char>(m));
    for(int i = 0; i < n; i++){
        for(int j = 0; j < m; j++)
            cin>>mat[i][j];
    }
    vector<vector<int>> vi(n , vector<int>(m));
    vi[0][0] = 1;
    Go(mat , 0 , 0 , n , m , vi);
    if(x)
        cout<<-1<<endl;
    return 0;
}
