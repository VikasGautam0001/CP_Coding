#include<bits/stdc++.h>
using namespace std;
#define int long long int
void Go(string s , int open , int close , int pos , int n){
    if(pos == 2*n){
        if(open == close)
            cout<<s<<endl;
        return;
    }
    if(open > close){
        Go(s+')' , open , close+1 , pos+1 , n);
    }
    if(open < n){
        Go(s+'(' , open+1 , close , pos+1 , n);
    }
}
int32_t main(){
    string s = "(";
    int n;
    cin>>n;
    Go(s ,1 , 0 , 1 , n);

    return 0;
}
