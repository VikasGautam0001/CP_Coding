#include<bits/stdc++.h>
using namespace std;
#define int long long int
void Permute(char ch[] , int i){
    // Base Case
    if(ch[i] == '\0'){
        cout<<ch<<endl;
        return;
    }
    // Recursive Case
    for(int k = i; ch[k] != '\0' ; k++){
        swap(ch[i] , ch[k]);
        // As this swap remains forever
        // Thats why we do swapping again after the function to restore the change we have done.
        // Coz arrays are bydefault call by reference.
        Permute(ch , i+1);
        // Restoring the original character array.
        // Backtracking...
        swap(ch[i] , ch[k]);
    }

}
int32_t main(){

    char ch[10];
    cin>>ch;
    Permute(ch , 0);
    return 0;
}
