#include<bits/stdc++.h>
using namespace std;
#define int long long int
vector<string> match{"prateek" , "sneha" , "deepak" , "arnav" , "shikha" , "palak" , "utkarsh" , "divyam", "vidhi" , "sparsh" , "akku"};
vector<string> keypad{"" , "" , "abc" , "def" , "ghi"  , "jkl" , "mno" , "pqrs" , "tuv" , "wxyz"};
void check(string ans){
    for(int i = 0; i < match.size(); i++){
    size_t found = match[i].find(ans);
    if (found != string::npos)
        cout<<match[i]<<endl;}
}
void Go(string s , string ans ,  int pos , int n){
    if(pos == n){
        check(ans);
        return;
    }
    if(s[pos] == '0' || s[pos] == '1' )
        Go(s , ans , pos+1 , n);
    for(int i = 0; i < keypad[s[pos]-'0'].size(); i++){
        Go(s , ans+keypad[s[pos]-'0'][i] , pos+1 , n);
    }
}
int32_t main(){

    string s;
    cin>>s;
    int n = s.length();
    string a = "";
    Go(s , a  ,0  , n);
    return 0;
}
