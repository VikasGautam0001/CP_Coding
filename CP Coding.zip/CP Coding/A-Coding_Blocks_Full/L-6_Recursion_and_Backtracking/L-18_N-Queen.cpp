#include<bits/stdc++.h>
using namespace std;
#define int long long int
bool isSafe(int board[][10] , int i , int j , int n){
    // You can check col
    for(int row = 0; row < i; row++){
        if(board[row][j] == 1)
            return false;
    }
    // You can check Left Diagonal
    int x = i;
    int y = j;
    while(x >= 0 && y >= 0){
        if(board[x][y] == 1)
            return false;
        x--;
        y--;
    }
    // You can check Right Diagonal.
    x = i;
    y = j;
    while(x >= 0 && y <= n-1){
        if(board[x][y] == 1)
            return false;
        x--;
        y++;
    }
    // The position is safe.
    return true;
}
bool SolveNQueen(int board[][10] , int i , int n ){
    // Base Case
    if(i == n){
        // Succecessfully place n  queens in n rows.
        for(int x = 0; x < n; x++){
            for(int y = 0; y < n; y++){
                if(board[x][y] == 1)
                    cout<<"Q ";
                else
                    cout<<"_ ";
            }
            cout<<endl;
        }
        cout<<endl;
        return false;
    }
    // Recursive case
    // Try to place queen in current row
    // and call on the remaining part
    for(int j = 0; j < n; j++){
        // Check if i , j position is safe to place the
        // queen.
        if(isSafe(board , i , j , n)){
            // Place the queen
            board[i][j] = 1;
            bool nextQueen = SolveNQueen(board, i+1 , n);
            if(nextQueen)
                return true;
            board[i][j] = 0;// Backtrack.
        }
    }
    // You have tried for all the positions in current row but could't
    // find any right place .
    return false;
}
int32_t main(){

    int n;
    int board[10][10] = {0};
    cin >>n;
    SolveNQueen(board , 0 , n);
    return 0;
}
