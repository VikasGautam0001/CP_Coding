#include<bits/stdc++.h>
#include<ctime>// for time
#include<cstdlib>// for srand();
using namespace std;
#define int long long int
// We use shuffle function to shuffle the array elements
// If array is already sorted then time complexity of
// quick sort will become n^2;
// Thats why we use Shuffle function.


// Inbuild sort function also uses Shuffle function.
// So that its time complexity always become n*log(n);
int Partition(int a[] , int start , int end){
    int pivot = a[end];
    int i = start-1;
    for(int j = start; j < end; j++){
        if(a[j] <= pivot){
            i++;
            swap(a[i] , a[j]);
        }
    }
    swap(a[i+1] , a[end]);
    return i+1;
}
void QuickSort(int a[] , int start , int end){
    if(start >= end)    return;
    int pindex = Partition(a , start , end);

    QuickSort(a , start , pindex-1);
    QuickSort(a , pindex+1 , end);
}
void Shuffle(int a[] , int s , int e){
    // This is seed value.
    // It means number comes out from rand function
    // be different always as its seed value
    // depends on time.
    srand(time(NULL));
    for(int j = e; j > 0; j--){
        int i = (rand()%(j+1));
        swap(a[i] , a[j]);
    }
}

int32_t main(){

    int a[100];
    int n;
    cin>>n;
    for(int i = 0; i < n; i++) cin>>a[i];
    //For randomly shuffling the array.
    Shuffle(a , 0 , n-1);
    QuickSort(a ,0 , n-1);
    for(int i = 0; i < n; i++) cout<<a[i]<<" ";
    return 0;
}
