#include<bits/stdc++.h>
using namespace std;


int Go(int n , int m  , int dp[][100]){
    if(n == 0 and m == 0){
        return 1;
    }
    if(n <= 0 or m <= 0){
        return 0;
    }
    if(dp[n][m] != 0)
        return dp[n][m];

    // Recursive Case
    dp[n][m] = Go(n , m-1 , dp) + Go(n-1 , m , dp);
    return dp[n][m];
}
int32_t main(){

    int n , m;
    cin>>n>>m;
    int dp[100][100];
    cout<<Go(n , m , dp);
    return 0;
}
