#include<bits/stdc++.h>
using namespace std;
#define int long long int
vector<vector<int>> store;
bool IsSafe(vector<int> a , int pos , int j , int n){
    for(int i = 0; i < j; i++){
        if(a[i] == a[pos])
            return false;
    }
    return true;
}
void Permute(vector<int> a ,int pos , int n){
    if(pos == n){
        store.push_back(a);
        return;
    }
    for(int j = 0; j < n; j++){
        if(IsSafe(a , pos , j , n)){
            swap(a[pos] , a[j]);
            Permute(a , pos+1 , n);
            swap(a[pos] , a[j]);
        }
    }
}
int32_t main(){

    int n;
    cin>>n;
    vector<int> a(n);

    for(int i = 0; i < n; i++) cin>>a[i];
    Permute(a , 0  , n);
    sort(store.begin() , store.end());
    for(int i = 0; i < store.size(); i++){
        for(int j = 0; j < n; j++)
            cout<<store[i][j]<<" ";
        cout<<endl;
    }
    return 0;
}
