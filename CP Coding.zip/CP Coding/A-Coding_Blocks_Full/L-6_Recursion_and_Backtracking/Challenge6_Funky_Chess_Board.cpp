#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int maxx = 0;
void SolveKnight(int board[][10] , int x, int y , int coun , int n){
    if(x<0 || y<0 || x >= n || y >= n || !board[x][y]){
        maxx = max(coun , maxx);
        return;
    }
    // Recursive Case
    board[x][y] = 0;
    SolveKnight(board , x+1 , y+2 , coun+1 , n);
    SolveKnight(board , x+2 , y+1 , coun+1 , n);
    SolveKnight(board , x-1 , y-2 , coun+1 , n);
    SolveKnight(board , x-2 , y-1 , coun+1 , n);
    SolveKnight(board , x-1 , y+2 , coun+1 , n);
    SolveKnight(board , x-2 , y+1 , coun+1 , n);
    SolveKnight(board , x+1 , y-2 , coun+1 , n);
    SolveKnight(board , x+2 , y-1 , coun+1 , n);

}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int board[10][10];
    int n;
    cin>>n;
    int count1 = 0;
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            cin>>board[i][j];
            if(board[i][j])
                count1++;
        }
    }
    SolveKnight(board , 0 , 0  , 0 , n);
    cout<<count1-maxx<<endl;
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
