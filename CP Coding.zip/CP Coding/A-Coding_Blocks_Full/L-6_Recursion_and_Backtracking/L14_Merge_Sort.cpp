#include<bits/stdc++.h>
using namespace std;

void Merge(int a[] , int start , int end){
    int mid = (start+end)/2;
    int i = start , j = mid+1 , k = start;
    int temp[100];
    while(i <= mid && j <= end){
        if(a[i] <= a[j]){
            temp[k] = a[i];
            i++;
        }
        else{
            temp[k] = a[j];
            j++;
        }
        k++;
    }
    while(i <= mid){
        temp[k] = a[i];
        i++;
        k++;
    }
    while(j <= end){
        temp[k] = a[j];
        j++;
        k++;
    }
    for(int i = 0; i <= end; i++) a[i] = temp[i];
}
void MergeSort(int a[] , int start , int end){
    if(start >= end) return;
    int mid = (start+end)/2;
    MergeSort(a , start , mid);
    MergeSort(a , mid+1 , end);
    Merge(a , start , end);

}


int main(){

    int a[] = {6,2,3,1,9,10,15,13,12,17};
    int i , n;
    n = sizeof(a)/sizeof(a[0]);
    MergeSort(a , 0 , n-1);
    for(int no : a) cout<<no<<" ";
    return 0;
}
