#include<bits/stdc++.h>
using namespace std;
#define int long long int
void TowerOfHanoi(int n , char src , char dest , char helper){
    // Base Case
    if(n == 0)
        return ;
    // Recursive Case
    // First Step N-1 disks move from source to helper.
    TowerOfHanoi(n-1 , src , helper , dest);

    cout<<"Move "<<n<<" disk from "<<src<<" to "<<dest<<endl;

    TowerOfHanoi(n-1 , helper , dest , src);
}
int32_t main(){

    int n;
    cin>>n;
    TowerOfHanoi(n , 'A' , 'C' , 'B');
    return 0;
}
