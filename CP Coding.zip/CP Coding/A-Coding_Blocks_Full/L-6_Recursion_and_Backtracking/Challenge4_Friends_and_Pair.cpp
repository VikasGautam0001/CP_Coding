#include<bits/stdc++.h>
using namespace std;
#define int long long int
int dp[31];
int Go(int n){
    if(n == 1 || n == 2)
        return n;
    dp[n] = Go(n-1) + (n-1)*Go(n-2);
}
int32_t main(){
    dp[1] = 1;
    dp[2] = 2;
    int a = Go(30);
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        cout<<dp[n]<<endl;
    }
    return 0;
}
