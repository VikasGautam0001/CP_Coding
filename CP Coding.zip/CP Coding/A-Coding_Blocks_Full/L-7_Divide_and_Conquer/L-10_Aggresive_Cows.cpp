#include<bits/stdc++.h>
using namespace std;
#define int long long int
int ans;
bool isValid(vector<int> &arr , int n , int c , int mid){
    int cows = 1;
    int last = arr[0];
    for(int i = 1; i < n; i++){
        if(arr[i]-last >= mid){
            cows++;
            if(cows >= c)
                return true;
            last = arr[i];
        }
    }
    return false;
}
int binarySearch(vector<int> &arr , int n , int c){
    int s = 0 , e  = arr[n-1];
    while(s <= e){
        int mid = (s+e)/2;

        if(isValid(arr , n , c , mid)){
            ans = mid;
            s = mid+1;
        }
        else
            e = mid-1;

    }
    return ans;
}
int32_t main(){

    int n  , c;
    cin>>n>>c;
    vector<int> arr(n);
    for(int i = 0; i < n; i++) cin>>arr[i];
    sort(arr.begin() , arr.end());

    cout<<binarySearch(arr , n , c)<<endl;


    return 0;
}
