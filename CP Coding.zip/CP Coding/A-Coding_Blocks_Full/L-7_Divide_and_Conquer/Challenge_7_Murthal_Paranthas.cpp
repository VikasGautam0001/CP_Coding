#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
bool check_Paranthas(vi &ranks , int cooks , int p , int time){
    int res = 0;
    for(int i = 0; i < cooks; i++){

        int n = 0;
        while(ranks[i]*n*(n+1) <= 2*time) n++;
        n--;

        res += n;
    }
    return res>=p;
}
int BinarySearchTime(vi &ranks , int cooks , int p){
    int s = 0 ;
    int x = 3;
    int e  = pow(10 , x);

    int ans = -1;

    int t = 1;
    while(s <= e){
        int mid = (s+e)/2;

        if(check_Paranthas(ranks , cooks , p , mid)){
            ans = mid;
            e = mid-1;
            t = 0;
        }
        else{
            s = mid+1;
            if(t){
                x++;
                e = pow(10 , x);
            }
        }

    }

    return ans;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int p , l;
    cin>>p>>l;

    vi ranks(l);
    loop(l) cin>>ranks[i];

    sort(ranks.begin() , ranks.end());

    cout<<BinarySearchTime(ranks , l , p);

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
