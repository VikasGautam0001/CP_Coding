#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
bool Reccur(string a , string b , int n){
    //Base Case
    if(a == b)
        return true;
    if(a.length() & 1)
        return false;

    //Recursive Case
    string a1 , a2 , b1 , b2;
    a1 = a.substr(0 , n/2);
    a2 = a.substr(n/2 , n-1);

    b1 = b.substr(0 , n/2);
    b2 = b.substr(n/2 , n-1);

    return (Reccur(a1 , b1 , n/2) and Reccur(a2 , b2 , n/2)) or (Reccur(a1 , b2 , n/2) and Reccur(a2 , b1 , n/2));

}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        string s1 , s2;
        cin>>s1;
        cin>>s2;
        int n = s1.length();
        if(s1 == s2)
            cout<<"YES"<<endl;
        else if(n&1){
            cout<<"NO"<<endl;
        }
        else{
           if(Reccur(s1 , s2 , n))
                cout<<"YES"<<endl;
           else
                cout<<"NO"<<endl;
        }
    }

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
