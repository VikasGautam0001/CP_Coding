#include<bits/stdc++.h>
using namespace std;
//#define int long long int
void BinSearch(int a[] , int n , int key){
    int beg = 0 , end = n-1;
    int mid = (beg+end)/2;
    while(beg <= end){
        if(key == a[mid]){
            cout<<"Element found at "<<mid+1;
            return ;
        }
        else if(key < a[mid])
            end = mid-1;
        else
            beg = mid+1;
        mid = (beg+end)/2;
    }
    cout<<"Element not found"<<endl;
}
int32_t main(){

    int a[] = {1 , 3 , 5 , 10 , 12 , 15 , 17};
    int n = sizeof(a)/sizeof(a[0]);
    cout<<"Enter element to Search";
    int x;  cin>>x;
    BinSearch(a , n , x);
    return 0;
}
