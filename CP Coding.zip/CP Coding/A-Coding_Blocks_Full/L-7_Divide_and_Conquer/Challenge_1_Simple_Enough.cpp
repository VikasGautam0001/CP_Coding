/*For a given number n, form a list and insert the following pattern into the list at the same position sequentially.
{floor(n/2) , n%2 , floor(n/2) }
Until every element in the list is either 1 or 0. Now, calculate number of 1s in from l to r (1-indexed).

EXPLAINATION: Start from n. Then make a list with the following elements.i.e. {floor(n/2) , n%2 , floor(n/2) }. Now this list has three elements. Now further break down each of those 3 elements considering the new n to be floor(n/2) , n%2 and floor(n/2) respectively for those three elements respectively INPLACE. And this process will go on until the n reduces down to 1 or 0. So it will basically form a tree with 3 branches coming out of every node at every level starting from 1 node (n) at the root.
*/
#include<bits/stdc++.h>
using namespace std;
#define int long long int
vector<int> accum;
int i = 0;
void Divide(int n){
    if(n == 1 || n == 0){
        i++;
        accum.push_back(accum[i-1]+n);
        return;
    }
    Divide(n/2);
    i++;
    accum.push_back(accum[i-1]+(n%2));
    Divide(n/2);
}
int32_t main(){

    int n , l , r;
    cin>>n>>l>>r;
    accum[0] = 0;
    Divide(n);

    cout<<accum[r]-accum[l-1];

    return 0;
}
