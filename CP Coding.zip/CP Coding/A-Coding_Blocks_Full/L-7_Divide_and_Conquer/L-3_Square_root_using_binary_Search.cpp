#include<bits/stdc++.h>
using namespace std;
#define int long long int
float SquareRoot(int n , int p){
    int beg = 0 , end = n;
    float ans;

    while(beg <= end){
        int mid = (beg+end)/2;
        if(mid*mid == n){
            ans = mid;
            break;
        }
        else if(mid*mid > n)
            end = mid-1;
        else{
            beg = mid+1;
            ans = mid;
        }
    }
    float inc = 0.1;
    for(int i = 0; i < p; i++){
        while(ans*ans <= n){
            ans += inc;
        }
        ans -= inc;
        inc /= 10;
    }
    return ans;

}
int32_t main(){

    int n;
    cin>>n;
    cout<<SquareRoot(n  ,5);

    return 0;
}
