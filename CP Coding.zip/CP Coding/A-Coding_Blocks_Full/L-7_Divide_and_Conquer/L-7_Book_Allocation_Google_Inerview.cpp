#include<bits/stdc++.h>
using namespace std;
#define int long long int
bool isValidConfig(vector<int> &books , int n , int k , int ans){
    int students = 1;
    int curr_pages = 0;
    for(int i = 0; i < n; i++){
        if(curr_pages+books[i] > ans){
            curr_pages = books[i];
            students++;
            if(students > k)
                return false;
        }
        else{
            curr_pages += books[i];
        }

    }
    return true;
}
int binarySearch(vector<int> &books , int n , int k){
    int total_pages = 0;
    int beg = 0 , end = 0;
    for(int i = 0; i < n; i++){
        total_pages += books[i];
        beg = max(beg , books[i]);
    }
    end = total_pages;
    int finalAns = beg;
    while(beg <= end){
        int mid = (beg+end)/2;
        if(isValidConfig(books , n , k  , mid)){
            // true;
            finalAns = mid;
            end = mid-1;
        }
        else{
            // false
            beg = mid+1;
        }
    }
    return finalAns;
}
int32_t main(){

    int n , k;
    cin>>n>>k;
    vector<int> books(n);
    for(int i = 0; i < n; i++) cin>>books[i];
    cout<<binarySearch(books , n , k);

    return 0;
}
