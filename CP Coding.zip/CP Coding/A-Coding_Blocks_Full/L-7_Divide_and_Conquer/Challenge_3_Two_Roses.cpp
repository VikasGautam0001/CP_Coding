#include<bits/stdc++.h>
using namespace std;
#define int long long int
void Search_Roses(vector<int> &arr , int n , int k){
    int l = 0 , r = n-1;
    int a = 0 , b = 0;
    int diff = 10000000;
    while(l < r){
        if(arr[l]+arr[r] == k){
            int d = abs(arr[l]-arr[r]);
            if(diff > d){
                a = arr[l];
                b = arr[r];
                diff = d;
            }
            r--;
            l++;
        }
        else if(arr[l]+arr[r] > k)
            r--;
        else
            l++;
    }
    cout<<"Deepak should buy roses whose prices are "<<a<<" and "<<b<<".";
    cout<<endl;
}
int32_t main(){

    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        vector<int> arr(n);
        for(int i = 0; i < n; i++) cin>>arr[i];
        sort(arr.begin() , arr.end());
        int k;
        cin>>k;
        Search_Roses(arr , n , k);


    }
    return 0;
}
