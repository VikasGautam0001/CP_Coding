#include<bits/stdc++.h>
using namespace std;
#define int long long
bool IsPossible(vector<int> &arr , int n , int k , int mid){
    int students = 1;
    int pages = 0;
    for(int i = 0; i < n; i++){
        if(arr[i]+pages > mid){
            students++;

            pages = arr[i];
            if(students > k)
                return false;
        }
        else{
            pages += arr[i];
        }

    }
    return true;
}
int BinarySearch(vector<int> &arr , int n , int k){
    int sum = 0 , s = 0 ;
    for(int i = 0; i < n; i++){
        sum += arr[i];
        s = max(s , arr[i]);
    }

    int e = sum;

    int ans = 0;
    while(s <= e){
        int mid = (s+e)/2;

        if(IsPossible(arr , n , k , mid)){
            e = mid-1;
            ans = mid;
        }
        else
            s = mid+1;
    }
    return ans;
}
int32_t main(){

    int n , k;
    cin>>n>>k;
    vector<int> arr(n);
    for(int i = 0; i < n; i++) cin>>arr[i];
    sort(arr.begin() , arr.end());
    cout<<BinarySearch(arr , n , k)<<endl;
    return 0;
}
