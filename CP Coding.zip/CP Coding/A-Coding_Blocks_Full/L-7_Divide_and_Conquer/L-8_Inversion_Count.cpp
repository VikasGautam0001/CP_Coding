#include<bits/stdc++.h>
using namespace std;
#define int long long int
int ans = 0;
void Merge(int arr[] , int s , int e){
    int mid = (s+e)/2;
    int i = s , j = mid+1 , k = s;
    int temp[e+1];
    while(i <= mid && j <= e){
        if(arr[i] <= arr[j]){
            temp[k] = arr[i];
            i++;
        }
        else{
            ans += mid-i+1;
            temp[k] = arr[j];
            j++;
        }
        k++;
    }
    while(i <= mid){
        temp[k] = arr[i];
        i++; k++;
    }
    while(j <= e){
        temp[k] = arr[j];
        j++; k++;
    }
    for(int x = s; x <= e; x++){ arr[x] = temp[x];}
    for(int x = s; x <= e; x++) cout<<arr[x]<<" ";
    cout<<endl;

}
void MergeSort(int arr[] , int s , int e){
    if(s >= e)
        return ;
    int mid = (s+e)/2;
    MergeSort(arr , s , mid);
    MergeSort(arr , mid+1 , e);
    Merge(arr , s , e);

}
int32_t main(){

    int n;
    cin>>n;
    int arr[n];
    for(int i = 0; i < n; i++) cin>>arr[i];
    MergeSort(arr , 0 , n-1);
    cout<<ans;
    return 0;
}
