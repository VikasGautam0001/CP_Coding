#include<bits/stdc++.h>
using namespace std;
int Find_Pivot(int arr[] , int n){
    int beg = 0 , end = n-1;
    int index = -1;
    while(beg <= end){
        int mid = (beg+end)/2;
        if(mid+1 <= n-1 && arr[mid] > arr[mid+1])
                return mid;
        else if(mid-1 >= 0 && arr[mid] < arr[mid-1])
                return mid-1;
        else{
            if(arr[mid]  >= arr[end])
                beg = mid+1;
            else
                end = mid-1;
        }
    }
}
int32_t main(){

    int arr[] = {4 , 5 , 6 , 7 , 9 , 1};
    int n = sizeof(arr)/sizeof(arr[0]);
    cout<<arr[Find_Pivot(arr , n)];
    return 0;
}
