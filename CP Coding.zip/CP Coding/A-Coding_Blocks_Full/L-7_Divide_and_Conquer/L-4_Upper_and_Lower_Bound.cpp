#include<bits/stdc++.h>
using namespace std;
// First Occurence;
int First_Occurence(int arr[] , int n  , int key){
    int beg = 0 , end = n-1;
    int index  =  -1;
    while(beg <= end){
        int mid = (beg+end)/2;
        if(arr[mid] == key){
            index = mid;
            end = mid-1;
        }
        else if(arr[mid] < key)
            beg = mid+1;
        else
            end = mid-1;
    }
    return index;
}
int Last_Occurence(int arr[] , int n  , int key){
    int beg = 0 , end = n-1;
    int index  =  -1;
    while(beg <= end){
        int mid = (beg+end)/2;
        if(arr[mid] == key){
            index = mid;
            beg = mid+1;
        }
        else if(arr[mid] < key)
            beg = mid+1;
        else
            end = mid-1;
    }
    return index;
}
int32_t main(){

    int arr[] = {1 , 1 , 2 , 2 , 2   , 2  , 3 , 3 , 10 , 10};
    int n = sizeof(arr)/sizeof(arr[0]);
    int key;
    cin>>key;
    int index = First_Occurence(arr , n , key);
    int index2 = Last_Occurence(arr , n , key);
    if(index == -1)
        cout<<"Element not found";
    else{
        cout<<"First occurence of "<<key<<" at "<<index<<" index"<<endl;
        cout<<"Last occurence of "<<key<<" at "<<index2<<" index"<<endl;
    }
    return 0;
}
