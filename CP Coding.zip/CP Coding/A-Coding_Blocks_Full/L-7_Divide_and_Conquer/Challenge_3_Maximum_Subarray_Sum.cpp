#include<bits/stdc++.h>
using namespace std;
#define int long long int
int ans;
void Merge(vector<int> &arr , int s , int e){
    int mid = (s+e)/2;

    if(s+1 == e){
        int max1 = arr[s];
        int max2 = arr[e];
        ans = max(ans ,max(max1 , max2));
    }

    int max3 = arr[mid];
    int max4 = arr[mid+1];

    vector<int> a,b;
    a.push_back(max3);
    for(int i = mid-1; i >= s; i--){
        max3 += arr[i];
        a.push_back(max3);
    }

    b.push_back(max4);
    for(int i = mid+2; i <= e; i++){
        max4 += arr[i];
        b.push_back(max4);
    }

    sort(a.rbegin() , a.rend());
    sort(b.rbegin() , b.rend());

    int sum = a[0]+b[0];

    ans = max(ans , sum);
}
void MergeSort(vector<int> &arr , int s , int e){
    int mid = (s+e)/2;
    if(s >= e){
        return;
    }
    MergeSort(arr , s , mid);
    MergeSort(arr , mid+1 , e);
    Merge(arr , s , e);
}
int32_t main(){

    int t;
    cin>>t;
    while(t--){
        ans = -1000000000;
        int n;
        cin>>n;
        vector<int> arr(n);
        for(int i = 0; i < n; i++) cin>>arr[i];
        MergeSort(arr , 0  , n-1);
        cout<<ans<<endl;
    }
    return 0;
}
