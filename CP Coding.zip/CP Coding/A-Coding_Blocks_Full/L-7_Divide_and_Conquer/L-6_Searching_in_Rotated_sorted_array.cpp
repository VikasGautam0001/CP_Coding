#include<bits/stdc++.h>
using namespace std;
#define int long long int
int Rotated_Search(int arr[] , int n , int key){
    int  beg = 0 , end = n-1;
    while(beg <= end){
        int mid = (beg+end)/2;
        if(arr[mid] == key)
            return mid;
        else if(arr[mid] < key && key <= arr[end])
            beg = mid+1;
        else if(arr[mid] > key && key >= arr[beg])
            end = mid-1;
        else if(arr[mid] < key)
            end = mid-1;
        else
            beg = mid+1;
    }
    return -1;
}
int32_t main(){

    int arr[] = {5 , 6 , 7  ,  8 , 1 , 2 , 3 , 4 };
    int n = sizeof(arr)/sizeof(arr[0]);
    int key;
    cin>>key;
    int index = Rotated_Search(arr , n , key);
    if(index == -1)
        cout<<"NOt found";
    else
        cout<<"found at "<<index;
    return 0;
}
