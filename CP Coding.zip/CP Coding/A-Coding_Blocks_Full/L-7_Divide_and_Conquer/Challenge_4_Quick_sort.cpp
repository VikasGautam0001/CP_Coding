#include<bits/stdc++.h>
using namespace std;
#define int long long int

int Partition(int arr[] , int s , int e){
    int pivot = arr[e];
    int i = s-1 , j = s;
    while(j < e){
        if(arr[j] <= pivot){
            i++;
            swap(arr[i] ,arr[j]);
        }
        j++;
    }
    swap(arr[i+1] , arr[e]);
    return i+1;

}

void QuickSort(int arr[]  ,int s ,int e){
    if(s >= e) return ;


    int pindex = Partition(arr , s , e);
    QuickSort(arr , s , pindex-1);
    QuickSort(arr , pindex+1 , e);
}
void Shuffle(int arr[] , int n){
    srand(time(NULL));

    for(int i = 0; i < n; i++){
        int j = rand()%n;
        swap(arr[i] , arr[j]);
    }
}
int32_t main(){

    int n;
    cin>>n;
    int arr[n];
    for(int i = 0; i < n; i++) cin>>arr[i];
    Shuffle(arr , n);
    QuickSort(arr , 0 , n-1);
    for(int i = 0; i < n; i++) cout<<arr[i]<<" ";
    return 0;
}
