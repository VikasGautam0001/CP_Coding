#include<bits/stdc++.h>
using namespace std;
#define int long long
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);

bool IsPossible(vi &board , int n , int k , int time){
    int painters = 1;
    int paintUnits = 0;
    for(int i = 0; i < n; i++){
        if(paintUnits+board[i] > time){
            paintUnits = board[i];
            painters++;
            if(painters > k)
                return false;
        }
        else{
            paintUnits += board[i];
        }

    }
    return true;
}

int BinarySearchTime(vi &board , int n , int k){
    int s = 0 , e  = 0;
    for(int i = 0; i < n; i++) e += board[i] , s = max(s , board[i]);

    int ans = -1;

    while(s <= e){
        int mid = (s+e)/2;

        if(IsPossible(board , n , k , mid)){
            ans = mid;
            e = mid-1;
        }
        else{
            s = mid+1;
        }
    }
    return ans;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int k , n;
    cin>>k>>n;

    vi board(n);
    loop(n) cin>>board[i];


    cout<<BinarySearchTime(board , n , k);



    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
