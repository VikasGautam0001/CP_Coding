#include<bits/stdc++.h>
using namespace std;
#define int long long int
int dp[100005];
int maxCuts(int n , int a  , int b , int c){
    if(n == 0) return 0;
    if(n < 0) return -1;

    if(dp[n] != -2) return dp[n];

    int res = max({maxCuts(n-a , a , b , c) , maxCuts(n-b , a , b , c) , maxCuts(n-c , a , b , c)});

    if(res == -1) return dp[n] = res;

    return dp[n] = res+1;
}
int32_t main(){

    int n , a , b , c;
    cin>> n>>a>>b>>c;

    for(int i = 0; i < 100005; i++) dp[i] = -2;
    //for(int i = 0; i < 10; i++) cout<<dp[i]<<" ";
    cout<<maxCuts(n , a , b , c);
    return 0;
}
