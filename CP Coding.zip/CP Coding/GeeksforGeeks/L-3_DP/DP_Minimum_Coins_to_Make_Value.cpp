#include<bits/stdc++.h>
using namespace std;
#define int long long int
// Recursive Solution
int recur(int coins[] , int n , int value){

    if(value == 0) return 0;
    if(n == 0) return INT_MAX;

    int res = recur(coins , n-1 , value);

    if(coins[n-1] <= value){
        res = min(res , 1+recur(coins , n , value-coins[n-1]));
    }

    return res;
}
int32_t main(){

    int n;
    cin>>n;
    int coins[n];
    for(int i = 0; i < n; i++) cin>>coins[i];

    int value;
    cin>>value;

    sort(coins , coins+n);
    //cout<<recur(coins , n , value);

    // DP solution

    vector<int> dp(1005 , INT_MAX);
    dp[0] = 0;

    for(int i = 1; i <= value; i++){
        int res = INT_MAX;
        for(int j = 0; j < n; j++){
            if(coins[j] > i) break;

            res = min(res , 1+dp[i-coins[j]]);
        }
        dp[i] = res;
    }

    cout<<dp[value]<<endl;
    return 0;
}
