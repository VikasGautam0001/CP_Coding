#include<bits/stdc++.h>
using namespace std;
#define int long long int
int dp[1005][1005];
int editDist(string s1 , string s2 , int n , int m){
    if(n == 0) return m;
    if(m == 0) return n;

    if(dp[n][m] != -1){
        return dp[n][m];
    }

    if(s1[n-1] == s2[m-1]){
        return dp[n][m] = editDist(s1 , s2 , n-1 , m-1);
    }

    return dp[n][m] = 1+min({editDist(s1 , s2 , n , m-1) , editDist(s1 , s2 , n-1 , m) , editDist(s1 , s2 , n-1 , m-1)});


}
int32_t main(){

    int t;
    cin>>t;

    while(t--){

        string s1 , s2;
        cin>>s1>>s2;

        int n = s1.length() , m = s2.length();

        memset(dp , -1 , sizeof(dp));

        cout<<editDist(s1 , s2 , n , m)<<endl;
    }
    return 0;
}
