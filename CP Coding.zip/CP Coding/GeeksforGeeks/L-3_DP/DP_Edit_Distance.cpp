#include<bits/stdc++.h>
using namespace std;
#define int long long int

int editDist(string s1 , string s2 , int n , int m){
    if(n == 0){
        return m;
    }
    if(m == 0) return n;

    if(s1[n-1] == s2[m-1]){
        return editDist(s1 , s2 , n-1 , m-1);
    }

    return 1+min({editDist(s1 , s2 , n , m-1) , editDist(s1 , s2 , n-1 , m) , editDist(s1 , s2 , n-1 , m-1)});
}
int32_t main(){

    string s1 , s2;
    cin>>s1>>s2;

    int n = s1.length() , m = s2.length();


    cout<<editDist(s1 , s2 , n , m);
    return 0;
}
