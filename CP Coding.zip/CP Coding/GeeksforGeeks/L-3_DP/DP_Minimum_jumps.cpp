#include<bits/stdc++.h>
using namespace std;
#define int long long int

// Recursive Solution
int recur(int a[] , int n){
    if(n == 1) return 0;


    int res = INT_MAX;
    for(int i = 0; i <= n-2; i++){
        if(i+a[i] >= n-1){
            int sub_res = recur(a , i+1);
            if(sub_res != INT_MAX){
                res = min(res , sub_res+1);
            }
        }
    }

    return res;
}
int32_t main(){

    int n;
    cin>>n;
    int a[n];
    for(int i = 0; i < n; i++) cin>>a[i];

    //cout<<recur(a , n);


    //DP Solution

    vector<int> dp(n , INT_MAX);

    dp[0] = 0;

    for(int i = 1; i < n; i++){

        int res = INT_MAX;
        for(int j = 0; j < i; j++){
            if(j+a[j] >= i){
                if(dp[j] != INT_MAX)
                res = min(res , dp[j]+1);
            }
        }

        dp[i] = res;
        cout<<dp[i]<<" ";
    }

    cout<<dp[n-1]<<endl;

    return 0;
}
