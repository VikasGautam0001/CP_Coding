#include<bits/stdc++.h>
using namespace std;

int main(){

    unordered_map<int , string> store;
    store[2] = ""
    return 0;
}
