#include<bits/stdc++.h>
using namespace std;

void toh(int N, int from, int to, int aux, long long &moves) {
    // Your code here
    if(N == 1){
        cout<<"move disk "<<from<<" from rod 1 to rod 3"<<endl;
        return ;
    }

    swap(to , aux);
    toh(N-1 , from , to , aux , moves + 1);
    swap(to , aux);

    cout<<"move disk "<<from<<" from rod 1 to rod 3"<<endl;
    swap(from , aux);
    toh(N-1 , from , to , aux , moves + 1);
    swap(from , aux);
}

int main(){

    int n;
    cin>>n;
    long long moves = 0;
    toh(n , 1 , 2 , 3 , moves);
    cout<<moves;
    return 0;
}
