#include<bits/stdc++.h>
using namespace std;

int ans = 0;

int SubsetSum(int a[] , int n , int sum){
    if(n == 0){
        return (sum == 0) ? 1 : 0;
    }

    return (SubsetSum(a , n-1 , sum)+
    SubsetSum(a , n-1 , sum-a[n-1]) );



}
int main(){

    ans = 0;

    int n;
    cin>>n;
    int a[n];
    for(int i = 0; i < n; i++) cin>>a[i];

    int sm;
    cin>>sm;

    cout<<SubsetSum(a , n , sm);


    return 0;
}
