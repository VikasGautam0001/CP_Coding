#include<bits/stdc++.h>
using namespace std;
#define int long long int
bool IsSafe(string s , int pos ,int j ,  int n){
    if(pos != 0 && s[pos-1] == 'A' && s[j] == 'B')
        return false;
    return true;
}
void Permute(string s , int pos , int n){
    // Base Case
    if(pos == n){
        cout<<s<<endl;
        return;
    }
    for(int j = pos; j < n; j++){
        if(IsSafe(s , pos , j , n)){
            swap(s[j] , s[pos]);
            Permute(s , pos+1 , n);
            swap(s[j] , s[pos]);
        }
    }
}
int32_t main(){

    string s;
    cin>>s;
    int n = s.length();
    Permute(s , 0 , n);
    return 0;
}
