#include<bits/stdc++.h>
using namespace std;
struct Node
{
	int data;
	Node* left;
	Node* right;
	Node(int n){
		data = n;
		left = NULL;
		right = NULL;
	}
};

void preorder(Node* root){

	if(root == NULL) return;
	cout<<root->data<<" ";
	preorder(root->left);
	preorder(root->right);
}

void inorder(Node* root){
	if(root == NULL) return;
	inorder(root->left);
	cout<<root->data<<" ";
	inorder(root->right);
}
int main(){

	Node* root = new Node(2);
	root->left = new Node(3);
	root->right = new Node(4);

	preorder(root);
	cout<<endl;
	inorder(root);
	//postorder(root);

	return 0;
}