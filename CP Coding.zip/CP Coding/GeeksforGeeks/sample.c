#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define vi vector<ll>
#define pb push_back
#define mp make_pair
#define ii pair<ll,ll>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
int main(){
    int s,t,a,b,m,n;
    cin>>s>>t>>a>>b>>m>>n;
    vi apple(m),orange(n);
    loop(m){
        cin>>apple[i];
        apple[i] += a;
    }
    loop(n){
        cin>>orange[i];
        orange[i] += b;
    }
    int countA = 0 , countB = 0;
    loop(m){
        if(apple[i] >= s && apple[i] <= t)
            countA++;
    }
    loop(n){
        if(orange[i] >=s && orange[i] <= t)
            countB++;
    }
    cout<<countA<<endl<<countB;
    return 0;
}
//***  CODE HARD  ***//
//***  PRACTICE   ***//
//** TRY AND LEARN **//
//***   THE END   ***//
