#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
int main(){
    test{
        int n;
        cin>>n;
        vi dollar(n),temp(5);
        loop(n){
            cin>>dollar[i];
        }
        int count = 1 , min = dollar[0];
        for(int i = 1; i < n; i++){
            if(i <= 4){
                if(dollar[i] < min){
                    min = dollar[i];
                    count++;
                }
            }
            else{
                copy_n(dollar.begin()+i-5,5,temp.begin());
                sort(temp.begin(),temp.end());
                if(dollar[i] < temp[0] ){
                    count++;
                }
            }
        }
        cout<<count<<endl;

    }
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//

