#include<bits/stdc++.h>
using namespace std;

vector<long long> reverseInGroups(vector<long long> mv, int n, int k){

    // your code here
    for(int i = 0; i < n;){
        int a = min(i+k , n);
        reverse(mv.begin()+i , mv.begin()+a);
        i += k;
    }
    return mv;
}

int main(){

    int n;
    cin>>n;

    vector<long long> a(n);
    for(int i = 0; i < n-1; i++) cin>>a[i];


    return 0;
}
