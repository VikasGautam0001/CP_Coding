#include<bits/stdc++.h>
using namespace std;

int main(){

    int n;
    cin>>n;

    int a[n] ;
    for(int i = 0; i < n; i++) cin>>a[i];

    int ans = a[1]-a[0];
    int mini = a[0];

    for(int j = 1; j < n; j++){
        ans = max(a[j]-mini , ans);
        mini = min(mini , a[j]);
    }

    cout<<ans<<endl;
    return 0;
}
