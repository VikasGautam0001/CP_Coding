#include<bits/stdc++.h>
using namespace std;

int main(){

    int n;
    cin>>n;
    int a[n] , great[n];
    for(int i = 0; i < n; i++) cin>>a[i];

    int curr_lead = -1;

    for(int i = n-1; i >= 0; i--){
        if(curr_lead < a[i]){
            cout<<a[i]<<" ";
            curr_lead = a[i];
        }
    }


    return 0;
}
