#include<bits/stdc++.h>
using namespace std;

int main(){

    int n , d;
    cin>>n>>d;

    int a[n];
    for(int i = 0; i < n; i++) cin>>a[i];


    d %= n;

    reverse(a , a+d);
    //for(int i = 0; i < n; i++) cout<<a[i]<<" ";
    //cout<<endl;
    reverse(a+d , a+n);
    //for(int i = 0; i < n; i++) cout<<a[i]<<" ";
    //cout<<endl;
    reverse(a , a+n);

    for(int i = 0; i < n; i++) cout<<a[i]<<" ";
    return 0;
}
