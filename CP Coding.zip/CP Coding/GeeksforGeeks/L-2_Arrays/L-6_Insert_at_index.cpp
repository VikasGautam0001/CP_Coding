#include<bits/stdc++.h>
using namespace std;

void insertAtIndex(int arr[], int sizeOfArray, int index, int element)
{
    //Your code here
    int n = sizeOfArray;



    for(int i = n-2; i >= index; i--){
        arr[i+1] = arr[i];
    }

    arr[index] = element;
}

int main(){

    int n;
    cin>>n;

    int a[n];
    for(int i = 0; i < n-1; i++) cin>>a[i];

    insertAtIndex(a , n , 2 , 90);

    for(int i = 0; i < n; i++) cout<<a[i]<<" ";

    return 0;
}
