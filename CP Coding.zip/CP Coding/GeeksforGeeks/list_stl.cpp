#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
void showlist(list<int> l1){
    for(auto it = l1.begin() ; it != l1.end() ; it++){
        cout<<*it<<" ";
    }
    cout<<endl;
}

int32_t main(){
    std::ios_base::sync_with_stdio(false);
    list<int> list1 , list2;
    for(int i = 0; i < 6 ; i++){
        list1.pb(i*2);
        list2.push_front(i*3);
    }
    list1.emplace_back(100);
    showlist(list1);
    showlist(list2);
    list1.reverse();
    showlist(list1);
    list1.pop_front();
    list2.pop_back();
    list1.sort();
    showlist(list1);
    showlist(list2);
    list1.reverse();
    showlist(list1);
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
