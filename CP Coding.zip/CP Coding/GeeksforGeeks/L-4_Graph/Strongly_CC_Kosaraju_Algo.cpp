#include<bits/stdc++.h>
using namespace std;
#define int long long int
int32_t main(){


    return 0;
}
