#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define vi vector<ll>
#define pb push_back
#define mp make_pair
#define ii pair<ll,ll>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
int main(){
    string str,final,temp="00";
    cin>>str;
    if(str[str.length()-1] == 'P'){
            cout<<"fdf";
        str.erase(str.end()-2,str.end());
        if(str[0] == '1' && str[1] == '2')
            cout<<str;
        else{
            int a = str[0] - '0';
            int b = str[1] - '0';
            int c = a*10 + b ;
            str.erase(0,2);

            if(c == 12){

                final = final + temp + str;
            }
            else{
                c = c + 12;
                final = final + to_string(c) + str;
            }
            cout<<final;
        }
    }
    else{
        str.erase(str.end()-2,str.end());
        if(str[0] == '1' && str[1] == '2'){
            str.erase(0,2);
            final = final + temp + str;
        }
        else
            final = str;
        cout<<final;
    }
    return 0;
}
//***  CODE HARD  ***//
//***  PRACTICE   ***//
//** TRY AND LEARN **//
//***   THE END   ***//
