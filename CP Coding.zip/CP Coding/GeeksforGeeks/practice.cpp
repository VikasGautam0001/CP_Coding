#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    test{
        vii v(1000001);
        int n;
        cin>>n;
        vi a(n);
        loop(n){
            cin>>a[i];
            for(int j = 1; j*j <= a[i]; j++){
                if(a[i] % j)
                    continue;
                v[j].pb(i);
                if(j != a[i]/j)
                    v[a[i]/j].pb(i);
            }
        }
        int l = 1 , star = 0;
        for(int i = 1; i < n; i++){
            int left = lower_bound(v[a[i]].begin(),v[a[i]].end(),l-1) - v[a[i]].begin();
            int right = upper_bound(v[a[i]].begin(),v[a[i]].end(),i-1) - v[a[i]].begin();
            if((right - left) > star)
                star = (right - left);
        }
        cout<<star<<endl;
    }
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
