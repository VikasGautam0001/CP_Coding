#include<bits/stdc++.h>
using namespace std;
#define int long long int

// Naive Solution
void Permute(string s , int pos , int n){
    // Base case
    if(pos == n){
        if(s.find("AB") == string::npos)
            cout<<s<<endl;
        return;
    }
    for(int j = pos; j < n; j++){
        swap(s[j] , s[pos]);
        Permute(s , pos+1 , n);
        swap(s[j] , s[pos]);
    }

}
int32_t main(){

    string s;
    cin>>s;
    int n = s.length();
    Permute(s , 0  , n);
    return 0;
}
