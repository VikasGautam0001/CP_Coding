#include<bits/stdc++.h>
using namespace std;

int main(){
    int t;
    cin>>t;

    while(t--){
        int n;
        cin>>n;

        if(n > 30){
            int diff = n-30;


            if(diff == 6 or diff == 10 or diff == 14){
                diff = n-31;
                if(diff == 6 or diff == 10 or diff == 15){
                    cout<<"NO"<<endl;
                }
                else{
                    cout<<"YES"<<endl;
                    cout<<6<<" "<<10<<" "<<15<<" "<<n-31<<endl;
                }
            }
            else{
                cout<<"YES"<<endl;
                    cout<<6<<" "<<10<<" "<<14<<" "<<n-30<<endl;
            }
        }
        else{
            cout<<"NO"<<endl;
        }
    }

    return 0;
}
