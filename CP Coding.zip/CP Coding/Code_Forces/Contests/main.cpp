#include<bits/stdc++.h>

using namespace std;

int main(){

    int t;
    cin>>t;

    while(t--){
        int n , k , z;
        cin >> n >> k >> z;

        vector<int> a(n);
        for(int i = 0; i < n; i++) cin>>a[i];

        int ans = a[0];
        if(z == 0){


            for(int i = 1; i <= k; i++){
                ans += a[i];
            }

            cout<<ans<<endl;
        }
        else{
            int maxele = 0;
            int a1 = -1;
            for(int i = 0; i < k; i++){
                maxele = max(maxele , a[i]);
            }

            int temp = a[0];
            for(int i = 1; i <= k; i++){
                temp += a[i];
            }

            int i = 0;

            bool flag = true;

            while(k > 0){
                if(!flag and maxele == a[i-1] and z){
                    k--;
                    ans += a[i-1];
                    z--;
                    flag = true;
                    i--;
                }
                else{
                    i++;
                    ans += a[i];
                    k--;
                    flag = false;
                }
            }

            cout<<max(ans , temp)<<endl;
        }



    }
    return 0;
}
