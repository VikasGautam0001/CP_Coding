/*You want to perform the combo on your opponent in one popular fighting game. The combo is the string s consisting of n lowercase Latin letters. To perform the combo, you have to press all buttons in the order they appear in s. I.e. if s="abca" then you have to press 'a', then 'b', 'c' and 'a' again.

You know that you will spend m wrong tries to perform the combo and during the i-th try you will make a mistake right after pi-th button (1≤pi<n) (i.e. you will press first pi buttons right and start performing the combo from the beginning). It is guaranteed that during the m+1-th try you press all buttons right and finally perform the combo.

I.e. if s="abca", m=2 and p=[1,3] then the sequence of pressed buttons will be 'a' (here you're making a mistake and start performing the combo from the beginning), 'a', 'b', 'c', (here you're making a mistake and start performing the combo from the beginning), 'a' (note that at this point you will not perform the combo because of the mistake), 'b', 'c', 'a'.

Your task is to calculate for each button (letter) the number of times you'll press it.

You have to answer t independent test cases.
*/
#include<bits/stdc++.h>
using namespace std;
#define int long long int
int32_t main(){

    int t;
    cin>>t;
    while(t--){

        int n , m;
        string s;
        cin>>n>>m>>s;

        vector<int> precom(n);
        for(int i = 0; i < m; i++){
            int p;
            cin>>p;
            precom[p-1]++;
        }

        for(int i = n-1; i > 0; i--){
            precom[i-1] += precom[i];
        }

        vector<int> ans(26);
        for(int i = 0; i < n; i++){
            ans[s[i] - 'a'] += precom[i];
            ans[s[i] - 'a']++;
        }

        for(int i = 0; i < 26; i++) cout<<ans[i]<<" ";
        cout<<endl;

    }
    return 0;
}
