#include<bits/stdc++.h>
using namespace std;
#define int long long int
int32_t main(){

    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int a[n];

        int odd = 0 , even = 0;
        for(int i = 0; i < n; i++){ cin>>a[i];
        if(a[i] & 1) odd++;
        else even++;
        }
        if(odd == 0 or even == 0){
            cout<<"YES"<<endl;
        }
        else cout<<"NO"<<endl;

    }
    return 0;
}
