#include<bits/stdc++.h>
using namespace std;

int32_t main(){


    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;

        int a[n];

        for(int i = 0; i < n; i++) cin>>a[i];

        bool f = true;

        for(int i = 0; i < n; i++){
            for(int j = i+2; j < n; j++){
                if(a[i] == a[j]){
                    f = false;
                    cout<<"YES"<<endl;
                    break;
                }
            }
            if(!f) break;
        }




        if(f) cout<<"NO"<<endl;
    }
    return 0;
}
