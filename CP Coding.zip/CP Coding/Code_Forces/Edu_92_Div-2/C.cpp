#include<bits/stdc++.h>

using namespace std;

int main(){

    int t;
    cin>>t;

    while(t--){
        string s;
        cin>>s;

        int n = s.length();

        unordered_map<char , int> hsh;

        int ans = n-2;

        for(int i = 0; i < n; i++){
            hsh[s[i]]++;
        }
        for(char ch = '0'; ch <= '9'; ch++){
            ans = min(n-hsh[ch] , ans);
        }

        for(char ch = '0'; ch <= '9'; ch++){
            for(char ch2 = ch+1; ch2 <= '9'; ch2++){
                int ct = 0;
                if(hsh[ch] == 0 or hsh[ch2] == 0){
                    continue;
                }

                bool flag ;
                bool flag2 = true;
                for(int i = 0; i < n; i++){
                    if(s[i] == ch and flag2){
                        ct++;
                        flag2 = false;
                        flag = false;
                    }
                    else if(s[i] == ch2 and flag2){
                        ct++;
                        flag2 = false;
                        flag = true;
                    }
                    else if(s[i] == ch and flag){
                        ct++;
                        flag = false;
                    }
                    else if(s[i] == ch2 and !flag){
                        ct++;
                        flag = true;
                    }
                }
                if(ct & 1)
                    ct--;

                ans = min(n-ct , ans);
            }
        }

        cout<<ans<<endl;



    }
    return 0;
}
