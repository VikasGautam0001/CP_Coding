#include<bits/stdc++.h>
using namespace std;

int main(){

    int t;
    cin>>t;
    while(t--){

        int n , k , z;
        cin >> n >> k >> z;

        vector<int> a(n) , prefix(n+1);

        for(int i = 0; i < n ; i++){
            cin>>a[i];
            prefix[i+1] = a[i]+prefix[i];
        }



           int ans = 0;

           for(int i = 1; i <= k; i++){
               int temp = k;
               int tempSum = 0;
               int sm = a[i]+a[i-1];
               tempSum += prefix[i+1];
               temp -= i;

               int half = min(temp/2 , z);


               tempSum += half*sm;
               if(temp/2 < z and temp & 1){
                   temp--;
                   tempSum += a[i-1];
               }
               temp -= (2*half);



               tempSum += (prefix[i+1+temp] - prefix[i+1]);

               ans = max(ans , tempSum);

           }

           cout<<ans<<endl;


    }

    return 0;
}
