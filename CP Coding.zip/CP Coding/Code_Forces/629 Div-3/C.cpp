#include<bits/stdc++.h>
using namespace std;
//#define int long long int
int32_t main(){

    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        string s;
        cin>>s;

        string s1, s2;
        s1 += '1';
        s2 += '1';

        int index = -1;
        for(int i = 0; i < n; i++){
            if(s[i] == '1'){
                index = i;
                break;
            }
        }

        for(int i = 1; i < n; i++){
            if(s[i] == '0'){
                s1 += '0';
                s2 += '0';
            }
            else if(index == -1){
                s1 += '1';
                s2 += '1';
            }
            else if(i < index and s[i] == '2'){
                s1 += '1';
                s2 += '1';
            }
            else if(i > index and s[i] == '2'){
                s1 += '0';
                s2 += '2';
            }
            else if(i == index){
                s1 += '1';
                s2 += '0';
            }
            else{
                s1 += '0';
                s2 += '1';
            }

        }
        cout<<s1<<endl<<s2<<endl;

    }
    return 0;
}
