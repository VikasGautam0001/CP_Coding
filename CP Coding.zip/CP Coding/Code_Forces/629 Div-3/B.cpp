#include<bits/stdc++.h>
using namespace std;
#define int long long int


int32_t main(){

    int i = 1;
    vector<int> store(100005);
    int sum = 0;
    for(int i = 1; i <= 100000; i++){
        sum += i;
        store[i] = sum;
    }


    int t;
    cin>>t;
    while(t--){
        int n , k;
        cin>>n>>k;


        int it = lower_bound(store.begin() , store.end() , k) - store.begin();

        int it1 = n-it;

        int gap = store[it]-k;


        for(int i = 1; i <= n; i++){
            if(i == it1 or i == it1+gap+1){
                cout<<'b';
            }
            else{
                cout<<'a';
            }
        }
        cout<<endl;
    }
    return 0;
}
