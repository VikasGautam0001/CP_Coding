#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
set<int> s;
int n , a , b , c;
void Permute(int ans , int pos){
    if(pos == n-1){
        s.insert(ans);
        return;
    }
    // Recursive Case
    Permute(ans+a , pos+1);
    Permute(ans+b , pos+1);

}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        cin >> n >> a >> b;
        s.erase(s.begin() , s.end());
        Permute(0 ,0);
        for(auto it = s.begin(); it != s.end(); it++)   cout<<*it<<" ";
        cout<<endl;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
