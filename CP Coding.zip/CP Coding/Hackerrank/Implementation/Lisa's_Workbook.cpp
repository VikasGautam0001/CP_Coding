#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n , k;
    cin>>n>>k;

    vi a(n) , store;
    loop(n) cin>>a[i];

    int page = 0 , ans = 0 , ch = 0;

    loop(n){
        int sum = 0;
        ch++;
        int numbering = 0;
        while(a[i]/k > 0){
            page++;
            numbering += k;

            if(page <= numbering and page > sum){
                ans++; }

            sum += k;
            a[i] -= k;
        }
        if(a[i]%k != 0){
            page++;

            numbering += (a[i]%k);

            if(page <= numbering and page > sum){
                ans++; }
        }
    }
    cout<<ans<<endl;



    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
