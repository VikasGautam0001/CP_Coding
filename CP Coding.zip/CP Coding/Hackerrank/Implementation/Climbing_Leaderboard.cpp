#include<bits/stdc++.h>
using namespace std;
#define int long long int
int32_t main(){

    int n , m;
    cin>>n;
    vector<int> scores(n);
    set<int> s;
    for(int i = 0; i < n; i++){
        cin>>scores[i];
        s.insert(scores[i]);
    }
    cin>>m;
    vector<int> alice(m);
    for(int i = 0; i < m; i++){
        cin>>alice[i];
    }

    vector<int> init;
    for(auto it = s.begin(); it != s.end(); it++) init.push_back(*it);

    vector<int> ans;
    int j = 0;
    int flag = true;
    for(int i = 0; i < init.size();){
        if(alice[j] < init[i]){
            ans.push_back(init.size()-i+1);
            j++;
        }
        else if(alice[j] == init[i]){
            ans.push_back(init.size()-i);
            j++;
        }
        else{
            i++;
        }
        if(j >= m){
            flag = false;
            break;
        }
    }
    if(flag){
        while(j != m){
            ans.push_back(1);
            j++;
        }
    }
    for(int no: ans) cout<<no<<endl;

    return 0;
}
