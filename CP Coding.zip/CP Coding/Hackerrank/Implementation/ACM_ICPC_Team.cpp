#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int xorCount(string a , string b , int no){
    int ans = 0;
    for(int i = 0; i < no; i++){
        if(a[i] == '1' || b[i] == '1')
            ans++;
    }
    return ans;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n , m;
    cin>>n>>m;

    vector<string> attend(n);

    loop(n) cin>>attend[i];

    map<int, int> hash;
    int maxi = 0;
    for(int i = 0; i < n; i++){
        for(int j = i+1; j < n; j++){
            int x = xorCount(attend[i] , attend[j] , m);
            maxi = max(maxi , x);
            hash[x]++;
        }
    }
    cout<<maxi<<endl<<hash[maxi];
    return 0;
}
