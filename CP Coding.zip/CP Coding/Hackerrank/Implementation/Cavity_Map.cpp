#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
bool check(vector<string> &arr , int i , int j){

    int a , b , c , d;
    int x  = arr[i][j]-'0';


    if(arr[i-1][j] == 'X')
        a = 100;
    else
        a  = arr[i-1][j]-'0';

    if(arr[i][j-1] == 'X')
        b = 100;
    else
        b  = arr[i][j-1]-'0';

    if(arr[i+1][j] == 'X')
        c = 100;
    else
        c  = arr[i+1][j]-'0';
    if(arr[i][j+1] == 'X')
        d = 100;
    else
        d  = arr[i][j+1]-'0';


    if(x > a and x > b and x > c and x > d)
        return true;
    return false;

}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n;
    cin>>n;
    vector<string> a(n);
    loop(n) cin>>a[i];

    for(int i = 1; i < n-1; i++){
        for(int j = 1; j < n-1; j++){
            if(check(a , i , j)){
                a[i][j] = 'X';
            }
        }
    }

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            cout<<a[i][j];
        }
        cout<<endl;
    }

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
