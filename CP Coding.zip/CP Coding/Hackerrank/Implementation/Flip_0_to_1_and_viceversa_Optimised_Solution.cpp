#include<bits/stdc++.h>
using namespace std;

int main(){
	int test;
	cin>>test;
	while(test--){
		int size;
		cin>>size;
		vector<int>myvector(size);
		for(int i=0;i<size;i++){
			cin>>myvector[i];
		}
		vector<int>cons(size+1,0);

		for(int i=1;i<=size;i++){
		    cons[i]=cons[i-1]+myvector[i-1];
		}

		vector<int>dp(size+1,0);

		int maxi=0;
		for(int i=1;i<=size;i++){
		    int j=i-cons[i];
		    dp[i]=max(cons[i],j+maxi);
		    maxi=max(maxi,-i+dp[i]+cons[i]);
		}
		maxi=0;
		int t=cons[size];

		for(int i=0;i<=size;i++){
		    maxi=max(maxi,dp[i]+t-cons[i]);
		}
		cout<<maxi<<endl;

	}
}
