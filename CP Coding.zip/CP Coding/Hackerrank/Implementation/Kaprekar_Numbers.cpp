#include<bits/stdc++.h>
using namespace std;
#define int long long int
int32_t main(){

    int p , q;
    cin>>p>>q;
    int count = 0;
    for(int x = p; x <= q; x++){
        string s = to_string(x);
        int d = s.length();
        int sqr = x*x;
        vector<int> arr;
        while(sqr){
            int rem = sqr%10;
            arr.push_back(rem);
            sqr /= 10;
        }
        int right = 0 , left = 0;
        int temp = 0;
        for(int i = 0; i < arr.size(); i++){
            if(i < d){
                right += arr[i]*pow(10,i);
            }
            else{
                left += arr[i]*pow(10,temp);
                temp++;
            }
        }
        if(right+left == x){
            cout<<x<<" ";
            count++;
        }


    }
    if(count == 0)
        cout<<"INVALID RANGE"<<endl;
    return 0;
}
