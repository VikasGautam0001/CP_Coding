#include<bits/stdc++.h>
using namespace std;
#define int long long int
int32_t main(){

    string s;
    cin>>s;

    int ones = 0;
    int zeros = 0;
    for(int i = 0; i < s.length(); i++){
        if(s[i] == '1')
            ones++;

    }
    int maxi = 0;
    if(s[0] == '0')
        zeros++;
    for(int i = 0; i < s.length(); i++){
        if(s[i] == '0' && s[i-1] == '0'){
            zeros++;
        }
        else if(s[i] == '0'){
            zeros++;
        }
        else{
            maxi = max(maxi , zeros);
            zeros = 0;
        }
    }
    cout << ones+maxi  ;



    return 0;
}
