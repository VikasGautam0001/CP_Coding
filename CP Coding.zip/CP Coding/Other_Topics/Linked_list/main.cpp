#include <bits/stdc++.h>
#define int long long int
using namespace std;
struct node{
    int data;
    node* next;
};

node *head = NULL;

void insertAtBegin(int n){
    node* temp = new node();
    temp->data = n;
    temp->next = NULL;

    temp->next = head;
    head = temp;
}

void insertAtEnd(int n){
    node* temp = new node;
    temp->data = n;
    temp->next = NULL;

    if(head == NULL){
        head = temp;
        return ;
    }

    node* curr = head;
    while(curr->next != NULL){
        curr = curr->next;
    }
    curr->next = temp;
}

void deleteFromBegin(){
    if(head != NULL){
        head = head->next;
    }
}
void deleteFromEnd(){
    if(head == NULL) return ;
    node* curr = head;
    if(curr->next == NULL){
        head = NULL;
        return ;
    }
    while( (curr->next)->next != NULL ){
        curr = curr->next;
    }
    curr->next = NULL;
}


int displayBack(){
    node* curr = head;

    if(curr == NULL){
        return -1;
    }
    if(curr->next == NULL){
        return curr->data;
    }

    while(curr->next != NULL){
        curr = curr->next;
    }

    return curr->data;
}

void removeMiddle(int &n){
    if(n == 0){
        return;
    }

    if(n == 1){
        deleteFromBegin();
        n--;
        return ;
    }

    if(n == 2){
        deleteFromEnd();
        n--;
        return;
    }

    //cout<<"yes"<<endl;

    node* curr = head;
    node* prev = NULL;
    int i = 1;
    int mid = n/2+1;
    while(i < mid){
        prev = curr;
        curr = curr->next;

        i++;
    }

    curr->next = (curr->next)->next;

    n--;
}

int displayMiddle(int n){
    if(n == 0) return -1;
    else if(n == 1) return head->data;
    else if(n == 2) return displayBack();

    int mid = n/2+1;

    int i = 1;
    node* curr = head;
    while(i < mid){
        curr = curr->next;
    }

    return curr->data;
}

int32_t main() {

    int q;
    cin>>q;
    int n = 0;
    while(q--){

    int choice;
    cin>>choice;


    if(choice == 1){
        n++;
        int x;
        cin>>x;
        insertAtBegin(x);
    }
    else if(choice == 2){
        n++;
        int x;
        cin>>x;
        insertAtEnd(x);
    }
    else if(choice == 3){
        if(head != NULL)
            cout<<head->data<<endl;
        else cout<<-1<<endl;
    }
    else if(choice == 4){
        cout<<displayBack()<<endl;
    }
    else if(choice == 5){
        if(head != NULL) n--;
        deleteFromBegin();
    }
    else if(choice == 6){
        if(head != NULL) n--;
        deleteFromEnd();
    }
    else if(choice == 7){
        removeMiddle(n);
    }
    else if(choice == 8){
        cout<<displayMiddle(n)<<endl;
    }
    }
    return 0;
}
