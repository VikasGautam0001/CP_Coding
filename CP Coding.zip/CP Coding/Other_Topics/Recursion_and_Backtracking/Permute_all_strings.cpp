#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
void permute(string s , int l , int r , int &count){
    if(l == r){
        count++;
        cout<<s<<endl;
    }
    else{
        for(int i = l; i <= r; i++){
            swap(s[i] , s[l]);
            permute(s , l+1 , r , count);
            swap(s[i] , s[l]);
        }
    }
}

int32_t main(){
    std::ios_base::sync_with_stdio(false);
    string s;
    cout<<"Enter a unique string";
    getline(cin , s);
    int len = s.length();
    int count = 0;
    permute(s , 0 , len-1 , count);
    cout<<endl<<"Total number of permutations are "<<count;
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
