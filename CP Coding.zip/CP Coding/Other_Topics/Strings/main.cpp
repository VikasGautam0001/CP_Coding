#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
int main(){
    int n;
    cin>>n;
    vector<bool> v(n+1,false);
    int k;
    cin>>k;
    loop(k){
        int num;
       string str;
       cin>>str;
       if(str != "CLOSEALL")
            cin>>num;
       int a,b,x = 10;
       int count = 0;
       if(str == "CLOSEALL")
            v.assign(n+1,false);
       else{
          /*  for(int i = 6 ; i < str.length(); i++){
                a = str[i] - '0';
                if(i >6){
                    a = b*x + a;
                    x *= 10;
                }
                b = a;
            }*/
            if(v[num])
                v[num] = false;
            else
                v[num] = true;
        }
        for(int i = 1; i <= n; i++){
            if(v[i] == true)
                count++;
        }
        cout<<count<<endl;
    }
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
