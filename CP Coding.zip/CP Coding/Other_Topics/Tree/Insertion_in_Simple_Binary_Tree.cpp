#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
struct node{
    int data;
    node* left;
    node* right;
};
node* createnewnode(int value){
    node* temp = new node();
    temp -> data = value;
    temp -> right = NULL;
    temp -> left = NULL;
    return temp;
}
node* insert(node* root ,  int value){
    if(root == NULL){
        root = createnewnode(value);
        return root;
    }
    queue<node*> q;
    q.push(root);
    while(!q.empty()){
        node* temp = q.front();
        q.pop();
        if(temp -> left == NULL){
            temp -> left = createnewnode(value);
            return root;
         }
         else{
            q.push(temp -> left);
         }
         if(temp -> right == NULL){
            temp -> right = createnewnode(value);
            return root;
         }
         else{
            q.push(temp -> right);
         }

    }
}
void inorder(node* root){
    if(root == NULL)
        return ;
    inorder(root -> left);
    cout<<root -> data<<" ";
    inorder(root -> right);
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    node *root = NULL;
    root = insert(root , 10);
    root = insert(root , 15);
    root = insert(root , 5);
    root = insert(root , 13);
    root = insert(root , 7);
    root = insert(root , 2);
    root = insert(root , 17);
    inorder(root);
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
