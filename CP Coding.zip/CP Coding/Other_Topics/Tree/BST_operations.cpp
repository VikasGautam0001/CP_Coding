#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
struct node{
    int data;
    node* left , *right;
};
node* create_new_node(int value){
    node* temp = new node();
    temp -> data = value;
    temp -> left = NULL;
    temp -> right = NULL;
    return temp;
}
node* insert(node* root , int data , int &count){
    if(!root){
        cout<<count<<endl;
        root = create_new_node(data);
        return root;
    }
    if(data < root -> data){
        count = 2*count;
        root -> left = insert(root -> left , data , count);
    }
    else if(data > root -> data){
        count = 2*count + 1;
        root -> right = insert(root -> right , data , count);
    }
    return root;
}
node* findmin(node* root){
    while(root -> left != NULL){
        root = root -> left;
    }
    return root;
}
node* Delete(node* root , int data , int &count , int l){
    if(!root){
        return root;
    }
    if(data < root -> data){
        count = 2*count;
        root -> left = Delete(root -> left , data , count , l);
    }
    else if(data > root -> data){
        count = 2*count + 1;
        root -> right = Delete(root -> right , data , count , l);
    }
    else{
        if(root -> left == NULL && root -> right == NULL){
            if(l == 0)
                cout<<count<<endl;
            delete root;
            root = NULL;
            return root;
        }
        else if(root -> left == NULL){
            if(l == 0)
                cout<<count<<endl;
            node* temp = root -> right;
            delete root;
            root = NULL;
            return temp;
        }
        else if(root -> right = NULL){
            if(l == 0)
                cout<<count<<endl;
            node* temp = root -> left;
            delete root;
            root = NULL;
            return temp;
        }
        else{
            cout<<count<<endl;
            node* temp = findmin(root -> right);
            root -> data = temp -> data;
            root -> right = Delete(root -> right , temp -> data , count , -1);
            return root;
        }
    }
    return root;
}
void inorder(node* root){
    if(!root)
        return ;
    inorder(root -> left);
    cout<<root -> data<<" ";
    inorder(root -> right);
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    node* root = NULL;
    test{
        char c;
        cin>>c;
        int value;
        cin>>value;
        if(c == 'i'){
            int count = 1;
            root = insert(root , value , count);
        }
        else if(c == 'd'){
            int count = 1;
            root = Delete(root , value , count , 0);
        }
        inorder(root);
         cout<<endl;
    }

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
