#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
struct node{
    int data;
    node* right;
    node* left;
};
node* createnewnode(int value){
    node* temp = new node();
    temp -> data = value;
    temp -> right = NULL;
    temp -> left = NULL;
}
node* insert(node* root , int value){
    if(root == NULL){
        root = createnewnode(value);
        return root;
    }
    if(value <= root -> data)
        root -> left = insert(root->left , value);
    else
        root -> right = insert(root -> right , value);

}
void BFT(node* root){
    queue<node*> q;
    q.push(root);
    while(!q.empty()){
        if(root -> left != NULL){
            q.push(root -> left);
        }
        if(root -> right != NULL){
            q.push(root -> right);
        }
        cout<<root->data<<" ";
        q.pop();
        root = q.front();
    }
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    node* root = NULL;
    root = insert(root , 10);
    root = insert(root , 15);
    root = insert(root , 5);
    root = insert(root , 13);
    root = insert(root , 7);
    root = insert(root , 2);
    root = insert(root , 17);
    BFT(root);
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
