#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
char Tree[10];
void root(char c){
    if(Tree[0])
        cout<<"Already a root present"<<endl;
    else
        Tree[0] = c;
}
set_left(int parent , char c){
    if(Tree[parent])
        cout<<"\n Can't set child at "<<(parent * 2)+1<<" no parent found"<<endl;
    else
        Tree[(parent*2)+1] = c;
}
set_right(int parent , char c){
    if(Tree[parent])
        cout<<"\n Can't set child at "<<(parent * 2)+2<<" no parent found"<<endl;
    else
        Tree[(parent*2)+2] = c;
}
void print(){
    loop(10){
        if(!Tree[i])
            cout<<"-";
        else
            cout<<Tree[i];
    }
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    root('A');
    set_left(0 , 'B');
    set_right(0 , 'C');
    set_left(1 , 'D');
    set_right(1 , 'E');
    print();
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
