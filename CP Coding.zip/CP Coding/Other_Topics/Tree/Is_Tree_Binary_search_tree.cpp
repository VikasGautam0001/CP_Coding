#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
struct node{
    int data;
    node* left;
    node* right;
};
node* createnewnode(int value){
    node* temp = new node();
    temp -> data = value;
    temp -> right = NULL;
    temp -> left = NULL;
    return temp;
}
node* insert(node* root ,  int value){
    if(root == NULL){
        root = createnewnode(value);
        return root;
    }
    if(value <= root -> data){
        root -> left = insert(root -> left , value);
    }
    else
        root -> right = insert(root -> right , value);
}
int min(node *root){
    if(root == NULL){
        cout<<"Tree is empty";
        return NULL;
    }
    if(root->left == NULL){
        return root -> data;
    }
    min(root -> left);
}
int max(node *root){
    if(root == NULL){
        cout<<"Tree is empty";
        return NULL;
    }
    if(root->left == NULL){
        return root -> data;
    }
    max(root -> left);
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    node *root = NULL;
    root = insert(root , 10);
    root = insert(root , 15);
    root = insert(root , 5);
    root = insert(root , 13);
    root = insert(root , 7);
    root = insert(root , 2);
    root = insert(root , 17);
    int m = max(root -> left);
    int n = min(root -> right);
    if(m <= root -> data && n > root -> data)
        cout<<"This Tree is BST";
    else
        cout<<"Not BST";
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
