#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
struct node{
    int data;
    node* left;
    node* right;
};
node* create_new_node(int value){
    node* temp = new node();
    temp -> data = value;
    temp -> right = NULL;
    temp -> left = NULL;
    return temp;
}
node* insert(node* root , int value){
    if(!root){
        root = create_new_node(value);
        return root;
    }
    if(value <= root->data){
        root -> left = insert(root -> left , value);
    }
    else
        root -> right = insert(root -> right , value);
    return root;
}
node* findvaluefunc(node* root , int value){
    if(!root)
        return root;
    if(value == root -> data)
        return root;
    else if(value < root -> data)
        return findvaluefunc(root -> left , value);
    else
        return findvaluefunc(root -> right , value);
}
node* inroder_successor(node* root , int value){
    node* findvalue = findvaluefunc(root , value);
    if(!findvalue)
        return NULL;
    if(findvalue -> right != NULL){
        node* temp = findvalue -> right;
        while(temp -> left){
            temp = temp -> left;
        }
        return temp;
    }
    else{
        node* successor = NULL;
        node* ansestor = root;
        while(ansestor != findvalue){
            if(findvalue -> data < ansestor -> data){
                successor = ansestor;
                ansestor = ansestor -> left;
            }
            else{
                ansestor = ansestor -> right;
            }
        }
        return successor;
    }
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    node* root = NULL;
    root = insert(root , 10);
    root = insert(root , 15);
    root = insert(root , 5);
    root = insert(root , 7);
    root = insert(root , 17);
    root = insert(root , 13);
    node* final = inroder_successor(root , 15);
    if(!final)
        cout<<"Sorry";
    else
    cout<<"Lowest ancestor is "<<final -> data;
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
