#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
class graph{
    int V;
    list<int> *adj;
public:
    graph(int V);
    void BFS(int start);
    void addEdge(int u , int v);
};
graph::graph(int V){
    this->V = V;
    adj = new list<int>[V];
}
void graph::addEdge(int u , int v){
    adj[u].pb(v);
}
void graph::BFS(int start){
    bool *visited = new bool[V];
    loop(V){
        visited[i] = false;
    }
    list<int> q;
    visited[start] = true;
    q.eb(start);
    list<int>::iterator it;
    while(!q.empty()){
        start = q.front();
        cout<<start<<" ";
        q.pop_front();
        for(it = adj[start].begin(); it != adj[start].end(); it++){
            if(!visited[*it]){
                visited[*it] = true;
                q.eb(*it);
            }
        }
    }

}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    graph g(4);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 2);
    g.addEdge(2, 0);
    g.addEdge(2, 3);
    g.addEdge(3, 3);

    g.BFS(2);
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
