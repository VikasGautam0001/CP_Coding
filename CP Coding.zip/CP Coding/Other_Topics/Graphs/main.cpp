#include<bits/stdc++.h>
using namespace std;
//#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
class graph{
    int V;
    list<int> *adj;
public:
    graph(int V);
    void DFS(void);
    void addedge(int u , int v);
    void DFStill(int i , bool visited[]);
};
graph::graph(int V){
    this->V = V;
    adj = new list<int>[V];
}
void graph::addedge(int u , int v){
    adj[u].pb(v);
}
void graph::DFStill(int i , bool visited[]){
    visited[i] = true;
    cout<<i<<" ";
    list<int>::iterator it;
    for(it = adj[i].begin(); it != adj[i].end(); it++){
        if(!visited[*it]){
            DFStill(*it , visited);
        }
    }
}
void graph::DFS(void){
    bool *visited = new bool[V];
    loop(V){
        visited[i] = false;
    }
    loop(V){
        if(!visited[i]){
            DFStill(i , visited);
            cout<<endl;
        }
    }
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    graph g(4);
    g.addedge(3 , 1);
    g.addedge(0 , 2);
    g.addedge(1 , 3);
    g.addedge(2 , 0);

    g.DFS();
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
