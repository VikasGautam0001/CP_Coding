#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n , f;
    cin>>n>>f;

    int a[n][n];



    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            cin>>a[i][j];
        }
    }

    int k;
    cin>>k;

    vi pos;
    for(int i = 0; i < n; i++){
        int sm = 0;
        for(int j = 0; j < n; j++){
            sm += a[i][j];
            if(sm > f){

                pos.pb(i+1);
                j--;
                sm = 0;
            }
        }
        if(sm <= f and sm != 0){
            pos.pb(i+1);
        }
    }

    cout<<pos.size()<<endl;
    for(int no: pos){
        cout<<"L"<<" "<<no<<endl;
    }


    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
