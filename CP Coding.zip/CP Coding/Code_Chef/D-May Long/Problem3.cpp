#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{

        int n , k;
        cin>>n>>k;

        vi a(n+1);

        set<int> store;

        unordered_map<int , int> pos;

        int incorrect = 0;
        for(int i = 1; i <= n; i++){
            cin>>a[i];

            if(a[i] != i){
                incorrect++;
                store.insert(i);
            }

            pos[a[i]] = i;
        }



        if(incorrect == 0){
            cout<<0<<endl;
            continue;
        }

        if(incorrect < 3){
            cout<<-1<<endl;
            continue;
        }

        vi ans;

        for(int i = 1; i <= n; i++){


            if(a[i] != i){

                if(pos[i] != a[i]){
                    int p1 , p2 , p3;

                    p1 = i;
                    p2 = a[i];
                    p3 = pos[i];

                ans.pb(p1);
                ans.pb(p2);
                ans.pb(p3);

                // Swapping
                int temp = a[p1];
                a[p1] = a[p3];
                a[p3] = a[p2];
                a[p2] = temp;

                // Position swapping
                pos[a[p1]] = p1;
                pos[a[p2]] = p2;
                pos[a[p3]] = p3;


                if(a[i] == i){
                    incorrect--;
                    store.erase(i);
                }

                if(a[p2] == p2){
                    incorrect--;
                    store.erase(p2);
                }

                if(a[p3] == p3){
                    incorrect--;
                    store.erase(p3);
                }


                k--;


                }
            }
            if(incorrect < 3)   break;


            if(k == 0)  break;
        }

        int i = 1;


        while(k and (incorrect >= 3)){

            if(i > n)   break;


            if(a[i] != i){

                int p1 , p2 , p3;

                p1 = i;
                p2 = a[i];

                if(pos[i] != p1 and pos[i] != p2){
                    p3 = pos[i];
                }
                else{

                    auto it = store.begin();

                    while( ( (*it) == a[p1]) or ((*it) == a[p2])){
                        it++;
                    }
                    p3 = *it;
                }


                ans.pb(p1);
                ans.pb(p2);
                ans.pb(p3);

                // Swapping
                int temp = a[p1];
                a[p1] = a[p3];
                a[p3] = a[p2];
                a[p2] = temp;

                // Position swapping
                pos[a[p1]] = p1;
                pos[a[p2]] = p2;
                pos[a[p3]] = p3;


                if(a[i] == i){
                    incorrect--;
                    store.erase(i);
                }

                if(a[p2] == p2){
                    incorrect--;
                    store.erase(p2);
                }

                if(a[p3] == p3){
                    incorrect--;
                    store.erase(p3);
                }



                k--;


            }
            else{
                i++;
            }

            if(incorrect < 3)   break;




        }


        bool f = true;

        for(int i = 1; i <= n; i++){
            if(a[i] != i){
                f = false;
                break;
            }
        }

        if(f){

            cout<<ans.size()/3<<endl;
            for(int i = 0; i < ans.size(); i += 3){
                cout<<ans[i]<<" "<<ans[i+1]<<" "<<ans[i+2]<<endl;
            }

        }
        else{
            cout<<-1<<endl;
        }

    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
