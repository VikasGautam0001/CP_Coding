#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int ans;

void Recur(vi &a , int i , int n , unordered_map<int , int> &pos , unordered_map<int , vi> &store , int res){

    // Base Case
    if(i == n){
        ans = min(ans , res);
        return ;
    }

    // Recursive Case
    if(a[i] != i){

        for(int no: store[i]){

            if(a[no] == i){

                swap(pos[a[i]] , pos[i]);
                swap(a[i] , a[no]);

                Recur(a , i+1 , n , pos , store, res);

                swap(a[i] , a[no]);
                swap(pos[a[i]] , pos[i]);



                break;
            }
        }

        int temp = a[i];
        swap(a[pos[i]] , a[i]);
        swap(pos[i] , pos[temp]);


        Recur(a , i+1 , n , pos, store, res+1);


        swap(pos[i] , pos[temp]);
        swap(a[pos[i]] , a[i]);


    }
    else{
        Recur(a , i+1 , n , pos , store, res);
    }
}

int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        ans = LONG_MAX;

        int n , m;
        cin>>n>>m;

        vi a(n+1);

        unordered_map<int , int> pos;

        for(int i = 1; i <= n; i++){
            cin>>a[i];
            pos[a[i]] = i;
        }


        unordered_map<int , vi> store;

        while(m--){
            int x , y;
            cin>>x>>y;

            store[x].pb(y);
            store[y].pb(x);
        }


        Recur(a , 1 , n+1 , pos , store , 0);

        cout<<ans<<endl;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
