#include<bits/stdc++.h>
using namespace std;
int coun = 0;
bool isSafe(int board[][15] , int i , int j , int n){
	// Check for column
	for(int row = 0; row < i; row++){
		if(board[row][j])
			return false;
	}
	// Check for left diagonal.
	int x = i;
	int y = j;
	while(x >= 0 && y >= 0){
		if(board[x][y])
			return false;
		x--;
		y--;
	}
	// Check for right diagonal.
	x = i ;
	y = j;
	while(x >= 0 && y <= n-1){
		if(board[x][y])
			return false;
		x--;
		y++;
	}

	 return true;
}
bool SolveNQueen(int board[][15] , int i , int n ){
	// Base case
	if(i == n){
		coun++;
		return false;
	}
	// Recursive Case
	for(int j = 0; j < n; j++){
		if(isSafe(board , i , j , n)){
			board[i][j] = 1;
			bool NextQueen = SolveNQueen(board , i+1 , n);
			if(NextQueen)
				return true;
            board[i][j] = 0;

		}
	}
	return false;
}
int main(){
	int board[15][15] = {0};
	int n;
	cin>>n;
	SolveNQueen(board , 0 , n);
	cout<<coun<<endl;
	return 0;
}
