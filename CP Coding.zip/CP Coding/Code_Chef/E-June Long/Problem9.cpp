#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){


    int n;
    cin>>n;

    int low1 = 1 , high1 = n;
    int low2 = 1 , high2 = n;

    int mid1 , mid2;

    char ch = 'Z';
    int t = 0;
    while(ch != 'E'){

        t++;

        if(t & 1){
            mid1 = low1+(high1-low1)/2;
            cout<<mid1;
            fflush(stdout);
        }
        else{
            mid2 = low2+(high2-low2)/2;
            cout<<mid2;
            fflush(stdout);
        }

        char c;
        cin>>c;

        if(t & 1){
            if(c == 'E'){
                return 0;
            }
            else if(c == 'G'){
                low1 = mid1+1;
            }
            else{
                high1 = mid1-1;
            }

            ch = c;
        }
        else{
            if(c == 'E'){
                return 0;
            }
            else if(c == 'G'){
                low2 = mid2+1;
            }
            else{
                high2 = mid2-1;
            }

            ch = c;
        }
    }


    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
