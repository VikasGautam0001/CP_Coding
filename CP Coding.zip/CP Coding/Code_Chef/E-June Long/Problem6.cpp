#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    /*std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);*/

    test{
        int n , p;
        cin>>n>>p;

        int a[n][n];

        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                cout<<1<<" "<<i+1<<" "<<j+1<<" "<<i+1<<" "<<j+1;
                int x;
                cin>>x;

                a[i][j] = x;

            }
        }
        cout<<2<<endl;
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                cout<<a[i][j]<<" ";
            }
            cout<<endl;
        }

        int x;
        cin>>x;
        if(x == 1)
            continue;
        else return 0;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
