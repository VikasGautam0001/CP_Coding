#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n;
        cin>>n;
        vi a(n);
        for(int i = 0; i < n; i++) cin>>a[i];

        int note =  -1;
        bool f = true;

        for(int i = 0; i < n; i++){
            if(a[i] == 1){
                if(note != -1 and i-note < 6){
                    cout<<"NO"<<endl;
                    f = false;
                    break;
                }
                note = i;
            }
        }

        if(f) cout<<"YES"<<endl;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
