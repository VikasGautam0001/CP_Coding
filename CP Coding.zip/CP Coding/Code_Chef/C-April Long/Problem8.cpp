#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);

class graph{
    map<int , list<int> > adjlist;

public:
    void addEdge(int u , int v ){
        adjlist[u].pb(v);
        adjlist[v].pb(u);

    }

    vi bfs(int src , int dest){

        vi ans;

        if(src == dest){
            ans.pb(src);
            return ans;
        }

        map<int , bool > visited;
        map<int , int> parent;


        queue<int> q;
        q.push(src);
        visited[src] = true;
        parent[src] = -1;

        while(!q.empty()){
            bool f = false;
            int node = q.front();
            q.pop();
            for(int neighbour : adjlist[node]){

                if(!visited[neighbour]){
                    q.push(neighbour);
                    parent[neighbour] = node;
                    visited[neighbour] = true;

                    if(neighbour == dest){
                        f = true;
                        break;
                    }
                }
            }

            if(f) break;
        }



        int temp = dest;
        while(temp != -1){
            ans.pb(temp);
            temp = parent[temp];
        }

        return ans;
    }
};

void seive(vi &primes){
    vector<bool> isprime(1005 , 1);

    isprime[0] = isprime[1] = 0;

    for(int i = 2; i*i <= 1000; i++){
        if(isprime[i]){
            for(int j = i*i; j <= 1000; j += i)
                isprime[j] = false;
        }
    }

    for(int i = 2; i <= 1000; i++){
        if(isprime[i])
            primes.pb(i);
    }


    primes.pb(1009);
}

void factor(int idx , int num , vii &store , vi &primes){

    int i = 0;
    int p = primes[i];

    while(p*p <= num){

        while(num%p == 0){
            store[idx][p]++;
            num /= p;
        }

        i++;
        p = primes[i];
    }

    if(num > 1){
        if(num > 1000){
            store[idx][1001] = num;
        }
        else{
            store[idx][num]++;
        }

    }

}


int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    vi primes;

    seive(primes);

    test{
        int n;
        cin>>n;

        graph g;

        for(int i = 0; i < n-1; i++){
            int u , v;
            cin>>u>>v;

            g.addEdge(u , v);
        }

        vi a(n+5);
        vii store(n+5 , vi(1010));

        for(int i = 1; i <= n; i++){
            cin>>a[i];

            if(a[i] == 1)
                continue;

            factor(i , a[i] , store , primes);

        }

        int q;
        cin>>q;

        while(q--){
            int l , r;
            cin>>l>>r;

            vi temp = g.bfs(l , r);


            int ans = 1;


            for(int i : primes){
                int ct =  0;

                for(int no: temp){
                    ct += store[no][i];
                }

                ans = ( (ans%MOD)*((ct+1)%MOD) )%MOD;
            }



           map<int , int> mapi;

            for(int no: temp){
                if(store[no][1001])
                    mapi[store[no][1001]]++;
            }

            for(auto i : mapi){
                ans = ( (ans%MOD) * ((i.second)+1) )%MOD;
            }

            cout<<ans<<endl;


        }

    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
