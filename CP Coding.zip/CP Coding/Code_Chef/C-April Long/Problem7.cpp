#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);


int m = 998244353;

string to_postfix(string s ,int &ct){
    stack<char> st;
    string newS;

    st.push('V');

    for(int i = 0; i < s.length(); i++){
        if(s[i] == '#'){
            newS += '#';
            ct++;
        }
        else if(s[i] == '('){
            st.push('(');
        }
        else if(s[i] == ')'){
            while( (st.top() != '(') and (st.top() != 'V') ){

                newS += st.top();
                st.pop();
            }

            if(st.top() == '('){
                st.pop();
            }
        }
        else{
            st.push(s[i]);
        }
    }


    return newS;
}

void fastModuloExp(int a , int b , int &c){


    while(b){
        if(b & 1)
            c = (c*a)%m;
        a = (a*a)%m;
        b >>= 1;
    }

}
void and_operator(vi &x , vi &y , vi &res){

    int sm = y[0]+y[1]+y[2]+y[3];

    res[0] += (x[0]*sm);
    res[0] += (x[1]*y[0]);
    res[0] += (x[2]*y[0]);
    res[0] += (x[3]*y[0]);
    res[0] += (x[2]*y[3]);
    res[0] += (x[3]*y[2]);

    res[1] = (x[1]*y[1]);

    res[2] += (x[1]*y[2]);
    res[2] += (x[2]*y[1]);
    res[2] += (x[2]*y[2]);

    res[3] += (x[1]*y[3]);
    res[3] += (x[3]*y[1]);
    res[3] += (x[3]*y[3]);

    res[0] %= m;
    res[1] %= m;
    res[2] %= m;
    res[3] %= m;

}

void or_operator(vi &x , vi &y , vi &res){


    int sm = (y[0]+y[1]+y[2]+y[3]);

    res[0] = (x[0]*y[0]);

    res[1] += (x[1]*sm);
    res[1] += (x[0]*y[1]);
    res[1] += (x[2]*y[1]);
    res[1] += (x[3]*y[1]);
    res[1] += (x[2]*y[3]);
    res[1] += (x[3]*y[2]);

    res[2] += (x[0]*y[2]);
    res[2] += (x[2]*y[0]);
    res[2] += (x[2]*y[2]);

    res[3] += (x[0]*y[3]);
    res[3] += (x[3]*y[0]);
    res[3] += (x[3]*y[3]);

    res[0] %= m;
    res[1] %= m;
    res[2] %= m;
    res[3] %= m;

}

void xor_operator(vi &x , vi &y , vi &res){


    res[0] += (y[0] * x[0]);
    res[0] += (y[1] * x[1]);
    res[0] += (y[2] * x[2]);
    res[0] += (y[3] * x[3]);

    res[1] += (y[0] * x[1]);
    res[1] += (y[1] * x[0]);
    res[1] += (y[2] * x[3]);
    res[1] += (y[3] * x[2]);

    res[2] += (y[0] * x[2]);
    res[2] += (y[1] * x[3]);
    res[2] += (y[2] * x[0]);
    res[2] += (y[3] * x[1]);

    res[3] += (y[0] * x[3]);
    res[3] += (y[1] * x[2]);
    res[3] += (y[2] * x[1]);
    res[3] += (y[3] * x[0]);

    res[0] %= m;
    res[1] %= m;
    res[2] %= m;
    res[3] %= m;

}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);


    test{
        string s;
        cin>>s;

        int ct = 0;

        string newS = to_postfix(s , ct);

        vi temp(4 , 1);
        stack<vi> st;



        for(int i = 0; i < newS.length(); i++){

            if(newS[i] == '&'){
                vi x , y , res(4 , 0);

                x = st.top();
                st.pop();
                y = st.top();
                st.pop();

                and_operator(x , y , res);

                st.push(res);
            }
            else if(newS[i] == '|'){
                vi x , y , res(4 , 0);

                x = st.top();
                st.pop();
                y = st.top();
                st.pop();

                or_operator(x , y , res);

                st.push(res);
            }
            else if(newS[i] == '^'){
                vi x , y , res(4 , 0);

                x = st.top();
                st.pop();
                y = st.top();
                st.pop();

                xor_operator(x , y , res);

                st.push(res);
            }
            else if(newS[i] == '#'){
                st.push(temp);
            }
        }

        int cmn = 1;
        fastModuloExp(4 , m-ct-1 , cmn);

        vi ans = st.top();



        int ans1 = ( (ans[0]%m) * (cmn%m) )%m;
        int ans2 = ( (ans[1]%m) * (cmn%m) )%m;
        int ans3 = ( (ans[2]%m) * (cmn%m) )%m;
        int ans4 = ( (ans[3]%m) * (cmn%m) )%m;

        cout<<ans1<<" "<<ans2<<" "<<ans3<<" "<<ans4<<endl;


    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
