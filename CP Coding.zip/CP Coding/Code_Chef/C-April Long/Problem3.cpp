#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);

vector<bool> isprime(34001 , 1);


void seive(vi &primes){
    isprime[0] , isprime[1] = false;

    for(int i = 2; i*i <= 34000; i++){
        if(isprime[i]){
            for(int j = i*i; j <= 34000; j += i)
                isprime[j] = false;
        }
    }


    for(int i = 2; i <= 34000; i++){
        if(isprime[i])
            primes.pb(i);
    }

    primes.pb(1287821);
}


bool factorize(int x , vi &primes , int k){
    int i = 0;
    int p = primes[0];
    int ans = 0;

    while(p*p <= x){
        while(x%p == 0){
            x /= p;
            ans++;
        }

        i++;
        p = primes[i];
    }

    if(x > 1) ans++;

    if(ans >= k) return true;
    return false;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    vi primes;
    seive(primes);


    test{
        int x , k;
        cin>>x>>k;

        if(k == 1){

            if(x > 1)
                cout<<1<<endl;
            else
                cout<<0<<endl;

            continue;
        }

        if(factorize(x , primes , k) )
            cout<<1<<endl;
        else
            cout<<0<<endl;



    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
