#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);

int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n;
        cin>>n;
        vi a(n) , div2(n) , odd(n) , div4(n);

        loop(n){
           cin>>a[i];
           a[i] = abs(a[i]);
        }

        bool f = false;

        for(int i = n-1; i >= 0; i--){
            if(a[i]%2 == 0){
                div2[i] = i;
                f = true;
            }
            else{


                if(f)
                    div2[i] = div2[i+1];
                else{
                    div2[i] = -1;
                }
            }
        }

        int oddcount = 0;

        for(int i = n-1; i >= 0; i--){
            if(a[i] & 1){
                oddcount++;
                odd[i] = oddcount;
            }
            else{
                oddcount = 0;
                odd[i] = 0;
            }
        }

        int x = -1 , y = -1;
        for(int i = n-1; i >= 0; i--){
            if(a[i] % 4 == 0){
                x = i;
                y = i;
            }
            else if(a[i] % 2 == 0){
                y = x;
                x = i;
            }

            div4[i] = y;
        }



        int ans = 0;


        loop(n){

            if(a[i] & 1){
                ans += odd[i];

                if(div4[i] != -1)
                    ans += n-div4[i];

            }
            else{
                if(a[i]%4 == 0){
                    ans += n-i;
                }
                else if( (i+1 < n) and (div2[i+1] != -1 ) ){
                    ans += n-div2[i+1];
                }
            }
        }


        cout<<ans<<endl;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
