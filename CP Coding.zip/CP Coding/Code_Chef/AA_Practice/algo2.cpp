#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);

/*void Spread(vii &arr , int l , int r , int k){
    if(l < 0 || l >= n || r < 0 || r >= m){
        return ;
    }
    Spread(arr , l-1 , r , k);
    Spread(arr , l+1 , r , k);
    Spread(arr , l , r-1 , k);
    Spread(arr , l , r+1 , k);

}*/
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int  n , m , q;
        cin>>n>>m>>q;
        vii arr(n , vi(m));

        bool f = false;
        set<int> s;
        loop(n) for(int j = 0; j < m; j++){  cin>>arr[i][j]; s.insert(arr[i][j]);}

        if(s.size() == 1) f = true;

        while(q--){
            int x , y , k;
            cin>>x>>y>>k;
            x--;
            y--;

            if(f){
               if(arr[x][y] >= k)
                    cout<<0<<endl;
                else
                    cout<<n*m<<endl;
                continue;
            }
            int right = 0 , left = 0;
            if(arr[x][y] >= k){
                cout<<0<<endl;
                continue;
            }
            for(int i = y; i < m; i++){
                if(arr[0][i] < k)
                    right++;
                else
                    break;
            }

            for(int i = y-1; i >= 0; i--){
                if(arr[0][i] < k)
                    left++;
                else
                    break;
            }
            cout<<(n*m)-(right+left)<<endl;
        }
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
