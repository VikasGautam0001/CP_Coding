#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
long double dist(int x1 , int x2 , int y1 , int y2){
    int a = abs(x1-x2);
    int b = abs(y1-y2);
    return sqrt((a*a)+(b*b));
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    test{
        int x,y;
        cin>>x>>y;
        int n,m,k;
        cin>>n>>m>>k;
        vector<pair<int,int>> a(n),b(m),c(k);
        loop(n){
            cin>>a[i].first>>a[i].second;
        }
        loop(m){
            cin>>b[i].first>>b[i].second;
        }
        loop(k){
            cin>>c[i].first>>c[i].second;
        }
        long double temp1 ,temp2 , temp3 = 10000000000;
        int t1 , t2;
        long double path3 ,path1 , path2 ,  shortest1 = 1e+18, shortest2 = 1e+18;
        int flag = 0;
        vector<long double> tempA(n);
        for(int j = 0; j < n; j++){
            temp1 = 1e+18;
            for(int l = 0; l < k; l++){
                temp1 = min(temp1 , dist(a[j].first , c[l].first , a[j].second , c[l].second));
            }
            tempA[j] = temp1;
        }
        vector<long double> tempB(m);
        for(int j = 0; j < m; j++){
            temp2 = 1e+18;
            for(int l = 0; l < k; l++){
                temp2 = min(temp2 , dist(b[j].first , c[l].first , b[j].second , c[l].second));
            }
            tempB[j] = temp2;
        }


        for(int i = 0; i < n; i++){
            path1 = dist(a[i].first , x , a[i].second , y);
            for(int j = 0; j < m; j++){
                path2 = dist(a[i].first , b[j].first , a[i].second , b[j].second);
                shortest1 = min(shortest1 , (path1 + path2 + tempB[j]) );
            }
        }

        for(int i = 0; i < m; i++){
            path1 = dist(b[i].first , x , b[i].second , y);
            for(int j = 0; j < n; j++){
                path2 = dist(a[j].first , b[i].first , a[j].second , b[i].second);
                shortest2 = min(shortest2 , (path1 + path2 + tempA[j]));
            }
        }

        floatdigit(10);
        cout<<min(shortest1 , shortest2)<<endl;

    }
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//

