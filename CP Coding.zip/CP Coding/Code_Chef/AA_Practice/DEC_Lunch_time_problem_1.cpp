#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        string s;
        cin>>s;
        int l1 = s.length();
        if(l1 == 1){
            cout<<"NO"<<endl;
            continue;
        }
        int final = 0 , count = 0;
        for(int i = 0; i < l1-1; i++){
            if(s[i] == s[i+1]){
                count++;
            }
            else{
                if(count == 0){
                    final += 2;
                }
                else{
                    count++;
                    string temp = "";
                    temp += to_string(count);
                    final += 1+temp.length();
                }
                count = 0;
            }
        }
        if(count){
            count++;
            string temp = "";
            temp += to_string(count);
            final += 1+temp.length();
        }
        else{
            final += 2;
        }
        //cout<<final<<" ";
        if(final < l1)
            cout<<"YES"<<endl;
        else
            cout<<"NO"<<endl;
    }

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
