#include<bits/stdc++.h>
using namespace std;
#define int long long int
int32_t main(){
    int t;
    cin>>t;
    while(t--){
    int n;
    cin>>n;
    set<int> used;
    for(int i = 2; i*i <= n; i++){
        if(n % i == 0 && !used.count(i)){
            used.insert(i);
            n /= i;
            break;
        }
    }
    for(int i = 2; i*i <= n; i++){
        if(n % i == 0 && !used.count(i)){
            used.insert(i);
            n /= i;
            break;
        }
    }
    if(n == 1 || used.size() < 2 || used.count(n))
        cout<<"NO"<<endl;
    else{
        cout<<"YES"<<" ";
        used.insert(n);
        for(auto it = used.begin(); it != used.end(); it++) cout<<*it<<" ";
        cout<<endl;
    }
    }
    //for(auto x : a) cout<<x<<" ";
    return 0;
}
