#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n;
        cin>>n;
        string s,s1;
        cin>>s;
        int sum = 0;
        loop(n) sum += (s[i]-'0');
        bool odd;
        (s[n-1]-'0')%2!=0?odd = true:odd = false;
        if(sum % 2 == 0 && odd){
            cout<<s<<endl;
            continue;
        }
        int pos = -1;
        int flag = 0;
        if(sum%2==0 && !(odd)){
            for(int i = n-1; i >= 0; i--){
                if((s[i]-'0') & 1){
                    flag = 1;
                    break;}
                else
                    s.erase(i);
            }
        }
        else if(sum%2!=0 && odd){
            for(int i = n-2; i >= 0; i--){
                if((s[i]-'0') & 1){
                    flag  = 1;
                    s.erase(s.begin()+i);
                    break;}
            }
        }
        else{
            for(int i = n-1; i >= 0; i--){
                if((s[i]-'0') & 1){
                    pos = i;
                    break;}
                else{
                    s.erase(s.begin()+i);
                }
            }
            int pos2 = -1;
            for(int i = pos-1; i >= 0; i--){
                if((s[i]-'0') & 1){
                    flag = 1;
                    s.erase(s.begin()+i);
                    break;}
            }
        }
        if(flag){
            int temp = 1;
            for(int i = 0; i < s.length(); i++){
                if(temp){
                    if(s[i] == '0')
                        continue;
                    else{
                        temp = 0;
                        s1 += s[i];
                    }
                }
                else{
                    temp = 0;
                    s1 += s[i];
                }

            }
            if(s1.length()){
                cout<<s1<<endl;
            }
            else{
                cout<<-1<<endl;
            }
        }
        else{
            cout<<-1<<endl;
        }
    }

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
