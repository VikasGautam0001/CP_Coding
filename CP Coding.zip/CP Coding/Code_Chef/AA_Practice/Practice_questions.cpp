#include<bits/stdc++.h>
using namespace std;
#define int long long int
int32_t main(){

    int n;
    cin>>n;
    int arr[n];
    int store[n];
    for(int i = 0; i < n; i++) cin>>arr[i];
    int k;
    cin>>k;
    k = k%n;
    for(int i = n-1; i >= 0; i--){
        int j = i-k;
        if(j < 0)
            j = n+j;
        store[j] = arr[i];
    }
    for(int i = 0; i < n; i++) cout<<store[i]<<" ";
    return 0;
}
