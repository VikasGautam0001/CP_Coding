#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pr pair<int,int>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    test{
       /* int n,k;
        cin>>n>>k;
        string s;
        cin>>s;
        int index;
        loop(n){
            if(s[i] == '1'){
                index = i;
                break;
            }
        }
        for(int i = ; i < n; i++){
            if(s[i] == '0')
        }*/
        int n;
        cin>>n;
        vi a(n);
        loop(n) cin>>a[i];
        vi v;
        if(a.size() == 1){
            cout<<a[0]<<endl;
            continue;
        }
        int notice;
        for(int j = 1; j < n; j++){
           int diff = 0 , flag = 0;
           for(int i = 0; i <a.size()-1; i++){
                int flag2 = 0;
                for(int x = 0; x < v.size(); x++){
                     if(i == notice){
                        flag2 = 1;
                        break;
                     }
                }
                if(flag2)
                    continue;
               if(diff < (a[i] - a[i+1])){
                    diff = (a[i]-a[i+1]);
                    notice = i;
                    flag = -1;
               }
            }
            if(flag == 0)
                break;
            v.pb(notice);
            swap(a[notice],a[notice-1]);
        }
        loop(n) cout<<a[i]<<" ";
        cout<<endl;
    }
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
