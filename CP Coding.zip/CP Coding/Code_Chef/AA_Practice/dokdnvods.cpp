#include<bits/stdc++.h>
using namespace std;
#define ll unsigned long long int
int main(){

    int t;
    cin>>t;
    while(t--){

        int n;
        cin>>n;

        if(n == 1){
            cout<<0<<endl;
            continue;
        }
        ll ans = 0;
        for(int i = 1; i <= n/2; i++){
            ans += (1LL*8*i*i*1LL);
        }

        cout<<ans<<endl;

    }
    return 0;
}
