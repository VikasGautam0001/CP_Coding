#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 10000000
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n,q;
    cin>>n>>q;
    vi a(n);
    loop(n) cin>>a[i];
    vector<ii> sample(n);
    vi s1(n),s2(n);
    bool flag = false , flag2 = false , silent = true;
    int m = 0;
    for(int i = 0; i < n-1; i++){
            m++;
            if(a[i] < a[i+1]){
                if(silent)
                    flag = true;
                else
                    flag = false;
                silent = false;
                flag2 = false;
                if(!flag)
                    s1[i] = 1;
            }
            else{
                if(m == 1)
                    silent = false;
                if(!silent)
                    flag2 = true;
                else
                    flag2 = false;
                silent = true;
                flag = false;
                if(!flag2)
                    s2[i] = 1;
            }
            sample[i+1].first = sample[i].first;
            sample[i+1].second = sample[i].second;
            if(flag)
                sample[i+1].first += 1;
            if(flag2)
                sample[i+1].second += 1;
    }
    while(q--){
        int l,r;
        cin>>l>>r;
        l -= 1;
        r -= 1;
        bool z1 = false,z2 = false;
        if(s1[l]){
            sample[l].first -= 1;
            z1 = true;
        }
        if(s2[l]){
            sample[l].second -= 1;
            z2 = true;
        }
        if(r-l == 1)
            cout<<"NO"<<endl;
        else if((sample[r].first-sample[l].first) == (sample[r].second-sample[l].second))
            cout<<"YES"<<endl;
        else
            cout<<"NO"<<endl;
        if(z1)
            sample[l].first += 1;
        if(z2)
            sample[l].second += 1;


    }

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
