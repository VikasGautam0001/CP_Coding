#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define eb emplace_back
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int fact(int number){
        int res = 1;
        for(int i = 2; i <= number; i++)
            res *= i;
        return res;
    }
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n;
        cin>>n;
        vi all(2*n);
        int Tsum = 0;
        map<int,int> mp;
        int max = -1000000000;
        loop(2*n){
            cin>>all[i];
            Tsum += all[i];
            mp[all[i]] += 1;
            if(max < all[i])
                max = all[i];
        }
        if(Tsum%(n+1) != 0){
            cout<<0<<endl;
            continue;
        }
        mp[max] -= 2;
        int res = fact(n-1);
        int flag = 1;
        loop(2*n){
            if(all[i] == max/2 && mp[all[i]]){
                if(mp[all[i]] & 1){
                    flag = 0;
                    break;
                }
                else{
                    res = res/fact(mp[all[i]]/2);
                }
            }
            else if(mp[all[i]]){
                if(mp[max-all[i]] != mp[all[i]]){
                    flag = 0;
                    break;
                }
                else{
                    if(mp[all[i]] == 1)
                        res *= 2;
                    else{
                        res *= pow(2,mp[all[i]]);
                        res /= fact(mp[all[i]]);
                    }
                    mp[max-all[i]] = 0;
                }
            }
        }
        if(!flag){
            cout<<0<<endl;
            continue;
        }
        cout<<res%MOD<<endl;


    }

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
