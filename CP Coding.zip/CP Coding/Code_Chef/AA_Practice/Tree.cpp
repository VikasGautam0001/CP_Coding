#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string>
#include <string.h>

using namespace std;



int main()
{
    char ch1[500] , ch2[500];
	fstream file1 , file2;

	file1.open("f1.txt" , ios::in | ios::out);

	if(!file1){
        cout<<"File1 not open successfully"<<endl;
        return 0;
	}
	cout<<"File1 open successfully"<<endl;


	file2.open("f2.txt" , ios::in | ios::out);

    if(!file2){
        cout<<"File2 not open successfully"<<endl;
        return 0;
	}
	cout<<"File2 open successfully"<<endl;

	cout<<"Enter text for file1"<<endl;
	cin.getline(ch1 , sizeof(ch1));
	file1<<ch1<<endl;

	cout<<"Enter text for file2"<<endl;
	cin.getline(ch2 , sizeof(ch2));
	file2<<ch2<<endl;

	file1.close();
	file2.close();

	cout<<"Program runs successfully"<<endl;
	return 0;
}
