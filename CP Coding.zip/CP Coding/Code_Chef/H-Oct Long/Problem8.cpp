#include<bits/stdc++.h>
using namespace std;
#define int long long
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 998244353
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);

int high(int num){
    if(num == 0) return -1;

    return log2(num);
}
int permute(vi &val){

    int res = LONG_MAX;

    do{
        int curr = val[0];

        for(int i = 1; i < val.size(); i++){
            curr = curr^val[i];

            int now = high(curr);
            if(now == -1) curr = 0;
            else curr = 1<<now;

        }

        res = min(curr , res);
    }while(next_permutation(val.begin() , val.end()));

    return res%MOD;
}
int solve(int sz , vi &a , int n){

    int ans = 0;

    for(int i = 0; i < n-sz+1; i++){
        vi val;
        for(int j = i; j < i+sz; j++){
            val.pb(a[j]);
        }

        ans += permute(val);
    }

    return ans%MOD;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n;
    cin>>n;

    vector<int> a(n);

    for(int i = 0; i < n; i++) cin>>a[i];

    int ans = 0;

    for(int i = 1; i <= n; i++){
        ans += solve(i , a , n);
        ans %= MOD;
    }


    cout<<ans<<endl;

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
