#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 200005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int dsu[MAX];
int get(int num){
    if(dsu[num] == num) return num;
    else return dsu[num] = get(dsu[num]);
}
void unite(int u , int v){
    dsu[get(u)] = get(v);
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n , d;
    cin>>n>>d;

    vii store(n , vi(d));

    for(int i = 0; i < n; i++) for(int j = 0; j < d; j++) cin>>store[i][j];


    vector<pair<int ,ii> > edges;

    auto addEdge = [&](int u , int v){
        int w = 0;
        for(int i = 0; i < d; i++){
            w += abs(store[u][i]-store[v][i]);
        }
        edges.pb(mp(w , mp(u , v)));
    };

    for(int mask = 0; mask < (1<<d); mask++){
        vector<ii> e;
        for(int i = 0; i < n; i++){
            int sum = 0;
            for(int j = 0; j < d; j++){
                if((mask>>j) & 1){
                    sum += store[i][j];
                }
                else{
                    sum -= store[i][j];
                }
            }
            e.pb(mp(sum , i));
        }
        int s = min_element(e.begin() , e.end())->second;
        int m = max_element(e.begin() , e.end())->second;

        for(int i = 0; i < n; i++){
            addEdge(s , i);
            addEdge(m , i);
        }
    }


    sort(edges.rbegin() , edges.rend());

    int ans = 0;

    for(int i = 0; i < n; i++) dsu[i] = i;
    for(auto all : edges){
        int u = all.second.first;
        int v = all.second.second;

        if(get(u) != get(v)){
            ans += all.first;
            unite(u , v);
        }
    }

    cout<<ans<<endl;


    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
