#include<bits/stdc++.h>
using namespace std;
#define int long long int

int32_t main(){

    int t;
    cin>>t;

    while(t--){
        int n;
        cin>>n;

        if(n == 1){
            cout<<1<<endl;
            continue;
        }

        double l = log2(n);
        int ii = log2(n);
        if(ii*1.0 == l){
            cout<<-1<<endl;
        }
        else{
            cout<<2<<" "<<3<<" "<<1<<" ";
            for(int i = 4; i <= n; i++){
                l = log2(i);
                ii = log2(i);
                if(ii*1.0 == l){
                    cout<<i+1<<" "<<i<<" ";
                    i++;
                }
                else{
                    cout<<i<<" ";
                }
            }
            cout<<endl;
        }
    }
    return 0;
}
