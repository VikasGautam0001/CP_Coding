#include<bits/stdc++.h>
using namespace std;
#define int long long int
int32_t main(){

    int t;
    cin>>t;

    while(t--){
            int n , k , x , y;
            cin>>n>>k>>x>>y;

            if(k == 0){
                if(x == y){
                    cout<<"YES"<<endl;
                }
                else{
                    cout<<"NO"<<endl;
                }
                continue;
            }

            bool f = false;
            for(int i = 0; i <= n*n; i++){
                if(x == y){
                    f = true;
                    break;
                }
                else{
                    x = (x+k)%n;
                }
            }

            if(f){
                cout<<"YES"<<endl;
            }
            else{
                cout<<"NO"<<endl;
            }

    }
    return 0;
}
