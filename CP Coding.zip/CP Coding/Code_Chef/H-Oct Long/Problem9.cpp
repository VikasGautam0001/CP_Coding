#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
vector<vector<int> > dp(40 , vector<int>(40 , -1));
int recur(int x1 , int y1 , int x2 , int y2 , int moves , int f){

    if(x1 == x2 and y1 == y2){
        return moves;
    }

    if(x1 == 0 or x1 <= -10 or x1 >= 10 or y1 <= 0 or y1 >= 10){

        return INT_MAX;
    }


    int a1 = INT_MAX, a2 = INT_MAX;
    if(f != 2)
        a1 = recur(x1+2*y1 , y1 , x2 , y2 , moves+1 , 1);

    if(f != 1)
        a2 = recur(x1-2*y1 , y1 , x2 , y2 , moves+1 , 2);


    int a3 = INT_MAX , a4 = INT_MAX;

    if(f != 4){
    if(y1+2*x1 > 0){
        a3 = recur(x1 , y1+2*x1 , x2 , y2 , moves+1 , 3);
    }
    else{
        a3 = recur(-x1 , -(y1+2*x1) , x2 , y2 , moves+1 , 3);
    }
    }

    if(f != 3){
    if(y1-2*x1 > 0){
        a4 = recur(x1 , y1-2*x1 , x2 , y2 , moves+1 , 4);
    }
    else{
        a4 = recur(-x1 , -(y1-2*x1) , x2 , y2 , moves+1 , 4);
    }
    }
    return min({a1 , a2 , a3 , a4});


}

int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int x1 , y1 , x2 , y2;
        cin>>x1>>y1>>x2>>y2;

        int a1 = recur(x1 , y1 , x2 , y2 , 0 , 0);
        cout<<a1<<endl;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
