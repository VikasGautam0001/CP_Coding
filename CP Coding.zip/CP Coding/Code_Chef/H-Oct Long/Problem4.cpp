#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
bool cmp(int a , int b){
    return (a == b);
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n , x , p , k;
        cin>>n>>x>>p>>k;

        vector<int> a(n);
        loop(n) cin>>a[i];

        k--;
        p--;

        sort(all(a));

        if(a[p] == x){
            cout<<0<<endl;
            continue;
        }



        int pre = -1 , pos = -1;

        bool f = true;
        for(int i = 0; i < n; i++){
            if(a[i] == x){
                if(f){
                    pre = i;
                    f = false;
                }
                pos = i;
            }
        }

        if(k < p){
            if(a[p] > x){
                cout<<-1<<endl;
                continue;
            }

            auto it = lower_bound(all(a) , x);
            int idx = it-a.begin();
            if(it != a.end()){
                cout<<idx-p<<endl;
            }
            else{
                cout<<n-p<<endl;
            }
        }
        else if(k == p){
            if(pre == -1){
                auto it = lower_bound(all(a) , x);
                int idx = it-a.begin();
                if(it != a.end()){
                    if(p < idx){
                        cout<<idx-p<<endl;
                    }
                    else{
                        cout<<p-idx+1<<endl;
                    }
                }
                else{
                    cout<<n-p<<endl;
                }
            }
            else{
                if(pre < p){
                    cout<<p-pos<<endl;
                }
                else{
                    cout<<pre-p<<endl;
                }
            }
        }
        else{
            if(pre == -1){
                auto it = lower_bound(all(a) , x);
                int idx = it-a.begin();
                if(it != a.end()){
                    if(idx > p){
                        cout<<-1<<endl;
                    }
                    else{
                        cout<<p-idx+1<<endl;
                    }
                }
                else{
                    cout<<-1<<endl;
                }
            }
            else{
                if(pre < p){
                    cout<<p-pos<<endl;
                }
                else{
                    cout<<-1<<endl;
                }
            }
        }

    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
