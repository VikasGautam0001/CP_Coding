#include<bits/stdc++.h>
using namespace std;
//#define int long long int
int32_t main(){

    while(1){

        int n;
        cin>>n;
        if(n == 42) break;
        cout<<n<<endl;
    }
    return 0;
}
