#include<bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin>>t;
    while(t--){
        int acti;
        string indian;
        cin>>acti;
        cin>>indian;

        int laddu = 0;


        while(acti--){
            string s;
            cin>>s;

            if(s == "TOP_CONTRIBUTOR"){
                laddu += 300;
            }
            else if(s == "CONTEST_HOSTED"){
                laddu += 50;
            }
            else if(s == "CONTEST_WON"){

                laddu += 300;

                int r;
                cin>>r;
                if(r < 20){
                    laddu += 20-r;
                }
            }
            else{
                int x;
                cin>>x;
                laddu += x;
            }
        }

        if(indian == "INDIAN"){
            cout<<laddu/200<<endl;
        }
        else{
            cout<<laddu/400<<endl;
        }
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
