#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n , m;
    cin>>n>>m;

    vector<string> a(n);

    unordered_map<string , int> name , country;
    unordered_map<string , string> mapi;

    loop(n){
        string x , y;
        cin>>x>>y;
        a[i] = x;
        mapi[x] = y;
    }



    while(m--){
        string temp;
        cin>>temp;
        name[temp]++;
        country[mapi[temp]]++;
    }

    int ans1 = 0 , ans2 = 0;
    loop(n){
        ans1 = max(ans1 , name[a[i]]);
        ans2 = max(ans2 , country[mapi[a[i]]]);
    }

    vector<string> temp1 , temp2;

    loop(n){
        if(ans1 == name[a[i]]){
            temp1.pb(a[i]);
        }
        if(ans2 == country[mapi[a[i]]]){
            temp2.pb(mapi[a[i]]);
        }
    }


    sort(all(temp1));
    sort(all(temp2));

    cout<<temp2[0]<<endl<<temp1[0]<<endl;

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
