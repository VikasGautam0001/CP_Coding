#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n , k;
        cin>>n>>k;
        vi a(n);
        loop(n) cin>>a[i];

        int left  , right , max_length;
        left = right = max_length = 0;

        unordered_map<int , int> store;
        set<int> s;


        loop(n){

            store[a[i]]++;
            s.insert(a[i]);

            if(s.size() >= k){


                while(1){
                    store[a[left]]--;

                    if(store[a[left]] == 0){
                        s.erase(a[left]);
                        left++;
                        break;
                    }

                    left++;
                }

            }

            max_length = max(max_length , right-left+1);

            right++;
        }

        cout<<max_length<<endl;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //

