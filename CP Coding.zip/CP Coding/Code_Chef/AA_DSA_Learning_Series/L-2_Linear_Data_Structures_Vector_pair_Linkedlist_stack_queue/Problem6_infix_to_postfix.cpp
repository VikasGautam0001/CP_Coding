#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);


int prec(char ch){
    if(ch == '^')
        return 3;
    else if(ch == '*' or ch == '/')
        return 2;
    else if(ch == '+' or ch == '-')
        return 1;
    else
        return -1;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n;
        cin>>n;
        string s;
        cin>>s;


        stack<char> st;
        st.push('v');

        string newS;

        for(int i = 0; i < n; i++){
            if(s[i] == '('){
                st.push(s[i]);
            }
            else if(s[i] >= 'A' and s[i] <= 'Z'){
                newS += s[i];
            }
            else if(s[i] == ')'){
                while(  (st.top() != 'v') and (st.top() != '(') ){
                    char c = st.top();
                    st.pop();
                    newS += c;
                }

                if(st.top() == '(' ){
                    st.pop();
                }
            }
            else{
                while(st.top() != 'v' && prec(s[i]) <= prec(st.top())){
                    newS += st.top();
                    st.pop();
                }

                st.push(s[i]);
            }
        }

        while(st.top() != 'v'){
            newS += st.top();
            st.pop();
        }


        cout<<newS<<endl;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
