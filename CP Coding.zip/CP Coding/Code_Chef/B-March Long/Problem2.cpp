#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
bool CountSet(int num){
    int ans = 0;
    while(num){
        if(num & 1)
            ans++;
        num >>= 1;
    }
    if(ans % 2 == 0) return true;
    else    return false;
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n , q;
        cin>>n>>q;

        vi a(n);

        int odd = 0 , even = 0;

        loop(n){
            cin>>a[i];
            if(CountSet(a[i]))
                even++;
            else
                odd++;
        }

        while(q--){
            int p;
            cin>>p;
            if(CountSet(p)){
                cout<<even<<" "<<odd<<endl;
            }
            else{
                cout<<odd<<" "<<even<<endl;
            }
        }
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
