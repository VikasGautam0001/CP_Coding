#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        string s , s1 , s2;
        cin>>s;
        int n = s.length();
        for(int i = 0; i < n/2; i++)
            s1 += s[i];
        int j;
        if(n & 1)
            j = n/2+1;
        else
            j = n/2;
        for(; j < n; j++)
            s2 += s[j];
        sort(s1.begin() , s1.end());
        sort(s2.begin() , s2.end());
        //cout<<s1<<" "<<s2;
        int flag = 0;
        for(int i = 0; i < n/2; i++){
            if(s1[i] != s2[i]){
                flag = 1;
                break;
            }
        }
        if(flag)
            cout<<"NO"<<endl;
        else
            cout<<"YES"<<endl;

    }

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
