#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n , m;
        int x , y , s;
        cin>>x>>y>>s;

        vi RivX(x+1) , RivY(y+1);

        loop(x) cin>>RivX[i];
        loop(y) cin>>RivY[i];

        if(x == 0 and y == 0){
            if(min(m , n) >= s){
                    cout<<(n/s)*(m/s)<<endl;
            }
            else{
                cout<<0<<endl;
            }
            continue;
        }

        RivX[x] = INT_MAX;
        RivY[y] = INT_MAX;

        sort(all(RivX));
        sort(all(RivY));


        RivX[x] = n;
        RivY[y] = m;

        int ans = 0;
        int initX = 1;
        int initY = 1;

        for(int i = 0; i < x+1; i++){
            if(i == x and x != 0 and RivX[x-1] == n)
                break;

            initY = 1;

            for(int j = 0; j < y+1; j++){
                if(j == y and y != 0 and RivY[y-1] == m ){
                    break;
                }
                if(y == 0){
                    if(i == x and RivX[x-1] != n){
                        if(min(RivX[i]-initX+1 , m) >= s)
                        ans +=  ((RivX[i]-initX+1)/s)*((m)/s);
                    }
                    else if(min(RivX[i]-initX , m) >= s)
                        ans +=  ((RivX[i]-initX)/s)*((m)/s);
                }
                else if(x == 0){
                    if(j == y and RivY[y-1] != m){
                            if(min(n, RivY[j]-initY+1) >= s)
                                ans +=  ((n)/s)*((RivY[j]-initY+1)/s);
                    }
                    else{if(min(n , RivY[j]-initY) >= s)
                        ans +=  ((n)/s)*((RivY[j]-initY)/s);
                    }
                }
                else{
                    if(j == y and RivY[y-1] != m){
                            if(min(RivX[i]-initX , RivY[j]-initY+1) >= s)
                                ans +=  ((RivX[i]-initX)/s)*((RivY[j]-initY+1)/s);
                    }
                    else if(i == x and RivX[x-1] != n){
                        if(min(RivX[i]-initX+1 , RivY[j]-initY) >= s)
                        ans +=  ((RivX[i]-initX+1)/s)*((RivY[j]-initY)/s);
                    }
                    else{
                        if(min(RivX[i]-initX , RivY[j]-initY) >= s)
                        ans +=  ((RivX[i]-initX)/s)*((RivY[j]-initY)/s);
                    }
                }

                initY = RivY[j]+1;

            }

            initX = RivX[i]+1;


        }

        cout<<ans<<endl;


    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
