#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n , k;
        cin >> n >> k;

        vi a(n);
        loop(n) cin>>a[i];

        unordered_map<int , int> hsh;


        int cost = k;
        int ct = k;
        int rc = k;
        for(int i = 0; i < n; i++){
            hsh[a[i]]++;
            if(hsh[a[i]] == 2){
                ct += 2;
                if(rc+k < ct){
                    i--;
                    hsh.clear();
                    ct = k;
                    rc = k;
                    cost += k;
                }
                else{
                    rc += 2;
                }
            }
            else if(hsh[a[i]] > 2){
                ct++;
                if(rc+k < ct){
                    i--;
                    hsh.clear();
                    ct = k;
                    rc = k;
                    cost += k;
                }
                else{
                    rc++;
                }
            }

        }
        if(ct != k){
            cost += ct-k;
        }

        int temp1 = cost;

        cost = k;
        for(int i = 0; i < n; i++){
            hsh[a[i]]++;
            if(hsh[a[i]] > 1){
                int val = 0;
                for(auto all : hsh){
                    if(all.second > 1){
                        val += all.second;
                    }
                }

                int val2 = 0;
                hsh[a[i]]--;
                for(auto all : hsh){
                    if(all.second > 1)
                        val2 += all.second;
                }


                hsh[a[i]]++;

                if(val2 +k + k < val + k){
                    cost += k+val2;
                    hsh.clear();
                    i--;
                }
            }
        }

        for(auto all : hsh){
            if(all.second > 1){
                cost += all.second;
            }
        }


        int temp = cost;
        cost = k;

        hsh.clear();

        for(int i = 0; i < n; i++){
            hsh[a[i]]++;
            if(hsh[a[i]] > 1){
                int val = 0;
                for(auto all : hsh){
                    if(all.second > 1){
                        val += all.second;
                    }
                }

                int val2 = 0;
                hsh[a[i]]--;
                for(auto all : hsh){
                    if(all.second > 1)
                        val2 += all.second;
                }


                hsh[a[i]]++;

                if(val2 +k + k <= val + k){
                    cost += k+val2;
                    hsh.clear();
                    i--;
                }
            }
        }

        for(auto all : hsh){
            if(all.second > 1){
                cost += all.second;
            }
        }

        cout<<min(cost , min(temp , temp1))<<endl;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
