#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    string a = "zza" , b = "zaz";
    cout<<min(a , b);
    /*
    test{
        string s , p;
        cin>>s>>p;

        unordered_map<char , int> hsh;
        for(int i = 0; i < s.length(); i++){
            hsh[s[i]]++;
        }
        for(int i = 0; i < p.length(); i++){
            hsh[p[i]]--;
        }



        string ans  , res;
        bool f = true;
        bool flag = true;

        for(char ch = 'a'; ch <= 'z'; ch++){
            if(ch == p[0] and flag){
                res += p;
                ch--;
                flag = false;
                continue;
            }
            if(ch > p[0] and f){
                ans += p;
                ch--;
                f = false;
                continue;
            }
            while(hsh[ch]){
                res += ch;
                ans += ch;
                hsh[ch]--;
            }
        }

        if(f){
            ans += p;
        }
        if(flag){
            res += p;
        }


        cout<<min(res , ans)<<endl;
    }*/

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
