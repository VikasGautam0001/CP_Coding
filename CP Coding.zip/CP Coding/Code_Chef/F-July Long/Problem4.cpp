
#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n;
        cin>>n;

        int x[4*n-1] , y[4*n-1];
        map<int , int> hash1 , hash2;


        for(int i = 0; i < (4*n-1); i++){
            cin>>x[i]>>y[i];
            hash1[x[i]]++;
            hash2[y[i]]++;
        }
        int a  , b;
        for(int i = 0; i < (4*n-1); i++){
            if(hash1[x[i]] & 1) a = x[i];
            if(hash2[y[i]] & 1) b = y[i];
        }

        cout<<a<<" "<<b<<endl;

    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
