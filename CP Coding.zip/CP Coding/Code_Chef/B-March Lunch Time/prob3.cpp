#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
void seive(vi &primes){
    vector<bool> isprime(10005 , 1);

    isprime[0] = isprime[1] = false;

    for(int i = 2; i*i <= 10000; i++){
        if(isprime[i]){
            for(int j = i*i; j <= 10000; j += i)
                isprime[j] = false;
        }
    }


    for(int i = 2; i <= 10000; i++){
        if(isprime[i])
            primes.pb(i);
    }
}
void factorize(int num , vi &factor , vi &primes){
    int i = 0;
    int p = primes[0];

    while(p*p <= num){
        int power = 0;
        while(num%p == 0){
            power++;
            num /= p;
        }

        if(power > factor[p]){
            factor[p] = power;
        }
        i++;
        p = primes[i];
    }

    if(num > 1){
        if(factor[num] == 0)
            factor[num]++;
    }

}

int factorizeAns(int num , vi &factor , vi &primes){

    int i = 0;
    int p = primes[0];
    int ans = 1;

    while(p*p <= num){
        int power = 0;
        while(num%p == 0){
            power++;
            num /= p;
        }
        if(power > factor[p]){
            ans *= pow(p , power-factor[p]);
        }

        i++;
        p = primes[i];
    }

    if(num > 1){
      if(factor[num] == 0)
        ans *= num;
    }

    return ans;
}
int32_t main(){
    //std::ios_base::sync_with_stdio(false);
    //cin.tie(NULL);
    //cout.tie(NULL);

    vi primes;
    seive(primes);

    test{

        int n , m;
        cin>>n>>m;

        vi a(n) , factor(10005);
        loop(n){
          cin>>a[i];

          if(a[i] != 1){
            factorize(a[i] , factor , primes);
          }
        }


        int increement = 1 , ans = 1;
        for(int i = m; i >= 1; i--){
            int temp = factorizeAns(i , factor , primes);
            if(temp >= increement){
                increement = temp;
                ans = i;
            }

        }

        cout<<ans<<endl;
    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
