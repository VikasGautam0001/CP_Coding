#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define all(array) array.begin(),array.end()
#define MOD 1000000007
#define MAX 100005
#define endl "\n"
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n;
        cin>>n;
        string s;
        cin>>s;
        vector<bool> visited(n , 0);

        int swaps = 0;
        for(int i = 0; i <= n/2; i++){

            if(s[i] != s[n-i-1]){
                if(s[i+1] == s[n-i-1] and !visited[i] and !visited[i+1] and s[i] != s[i+1]){
                    swap(s[i] , s[i+1]);
                    visited[i] = true;
                    visited[i+1] = true;
                    swaps++;
                }
                else if(s[n-i-2] == s[i] and !visited[n-i-1] and !visited[n-i-2] and s[n-i-1] != s[n-i-2]){
                    swap(s[n-i-1] , s[n-i-2]);
                    visited[n-i-1] = true;
                    visited[n-i-2] = true;
                    swaps++;
                }
            }

        }

        bool f = true;
        for(int i = 0; i < n/2; i++){
            if(s[i] != s[n-i-1]){
                f = false;
                break;
            }
        }

        if(f)   cout<<"YES"<<endl<<swaps<<endl;
        else    cout<<"NO"<<endl;

    }

    return 0;
}
//  << Compile and Test >>  //
//  << Think,Code,Learn >>  //
//  <<        AC        >>  //
