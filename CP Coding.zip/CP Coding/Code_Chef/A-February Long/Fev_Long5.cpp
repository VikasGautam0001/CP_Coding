#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);


    vi store(400,0);
    vi a1(28,0) , a2(28,0) , a3(28,0) , a4(28,0);
    a1[3] = 1;
    a1[9] = 1;
    a1[14] = 1;
    a1[15] = 1;
    a1[20] = 1;
    a1[25] = 1;
    a1[26] = 1;

    a2[5] = 1;
    a2[10] = 1;
    a2[11] = 1;
    a2[16] = 1;
    a2[21] = 1;
    a2[22] = 1;
    a2[27] = 1;

    a3[1] = 1;
    a3[6] = 1;
    a3[7] = 1;
    a3[12] = 1;
    a3[17] = 1;
    a3[18] = 1;
    a3[23] = 1;

    a4[2] = 1;
    a4[3] = 1;
    a4[8] = 1;
    a4[13] = 1;
    a4[14] = 1;
    a4[19] = 1;
    a4[25] = 1;

    store[0] = 0;
    for(int i = 1; i <= 99; i++){
        store[i] = a1[i%28];
    }
    store[100] = 0;

    for(int i = 101; i <= 199; i++){
        store[i] = a2[(i-100)%28];
    }
    store[200] = 1;

    for(int i = 201; i <= 299; i++){
        store[i] = a3[(i-200)%28];
    }
    store[300] = 0;

    for(int i = 301; i <= 399; i++){
        store[i] = a4[(i-300)%28];
    }

    vi acc(400);
    acc[0] = 0;
    for(int i = 1; i < 400; i++){
        acc[i] += store[i]+acc[i-1];
    }
    test{
        int mm1 , yy1 , mm2 , yy2;
        cin>>mm1>>yy1;
        cin>>mm2>>yy2;
        if(mm1 > 2)
            yy1++;
        if(mm2 < 2)
            yy2--;

        int mod1 = yy1%400;
        int mod2 = yy2%400;

        int Q1 = yy1/400;
        int Q2 = yy2/400;

        if(mod1 == 0)
           mod1 = 0;
        else
            mod1--;

        int a1 = (Q1*101)+acc[mod1];
        int a2 = (Q2*101)+acc[mod2];
        if((a2-a1)  <  0)
            cout<<0<<endl;
        else
            cout<<a2-a1<<endl;


    }

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
