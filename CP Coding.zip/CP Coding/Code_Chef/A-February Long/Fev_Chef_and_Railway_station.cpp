#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
#define endl "\n"
#define MAX 100005
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
vi  primeno ;
vii bestprime(MAX+1) ,finalfac(MAX+1);
void sieve(){

    vi isprime(MAX , 1) ;
    isprime[0] = 0;
    isprime[1] = 0;
    for(int i = 2; i*i <= MAX; i++){
        if(isprime[i]){
            for(int j = i*i; j <= MAX; j += i)
                isprime[j] = 0;
        }
    }
    for(int i = 2; i <= MAX; i++){
        if(isprime[i]){
            primeno.pb(i);
        }
    }
    //for(int i = 0; i < 10; i++) cout<<primeno[i]<<endl;

}
void factor(){
    for(int i = 1; i < 100001; i++){
        int sqr = i*i;
        finalfac[i].pb(1);
        for(auto &x : bestprime[i]){
            int ct = 0;
            while(sqr%x == 0){
                ct++;
                sqr /= x;
            }

            int sz = finalfac[i].size();
            for(int j = 1; j <= ct; j++){
                int q = (int)pow(x , j);
                for(int k = 0; k < sz; k++){
                    finalfac[i].pb(q*finalfac[i][k]);
                }
            }
        }
    }
}
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    sieve();
    // Calculating factors of each upto 10e5;
    for(int x : primeno){
        for(int i = x; i <= 100000; i += x)
            bestprime[i].pb(x);
    }
    factor();


    test{
        int n , m;
        cin>>n>>m;
        vi xaxis , yaxis;
        vector<bool> xPos(MAX ,0) , xNeg(MAX ,0) , yPos(MAX , 0) , yNeg(MAX , 0);
        int countx = 0 , county = 0;
        bool flag = false;
        loop(n){
            int x;
            cin>>x;
            xaxis.pb(x);
            if(x == 0){ countx++; flag = true;}
            else if(x < 0) xNeg[abs(x)] = true;
            else   xPos[abs(x)] = true;
        }

        loop(m){
            int y;
            cin>>y;
            yaxis.pb(y);
            if(y == 0){ county++; flag = true;}
            else if(y < 0) yNeg[abs(y)] = true;
            else   yPos[abs(y)] = true;
        }

        int ans = 0;
        for(int x : xaxis){
            int xx = x*x;
            for(auto &f1 : finalfac[abs(x)]){
                int f2 = xx/f1;
                if(f1 <= MAX and f2 <= MAX){
                    if(yPos[f1] and yNeg[f2])
                        ans++;
                }
            }

        }

        for(int y: yaxis){
            int yy = y*y;
            for(auto &f1 : finalfac[abs(y)]){
                int f2 = yy/f1;
                if(f1 <= MAX and f2 <= MAX){
                    if(xPos[f1] and xNeg[f2])
                        ans++;
                }
            }

        }
        if(flag)
            ans += (n-countx)*(m-county);
        cout<<ans<<endl;


    }

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
