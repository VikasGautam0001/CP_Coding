#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int store[24][5];
int t = -1;
void Go(int arr[] , int pos){
    // Base Case
    if(pos == 4){
        t++;
        for(int i = 0; i < 4; i++){
            store[t][i] = arr[i];
            //cout<<store[t][i];
        }
        //cout<<endl;
        return;
    }
    // Recursive Case
    for(int j = pos; j < 4; j++){
        swap(arr[j] , arr[pos]);
        Go(arr , pos+1);
        swap(arr[j] , arr[pos]);
    }
}
int32_t main(){
    //std::ios_base::sync_with_stdio(false);
    //cin.tie(NULL);
    //cout.tie(NULL);
    map<int ,int> m;
    m[12] = 0;
    m[3] = 1;
    m[6] = 2;
    m[9] = 3;
    int arr[4] = {0,1,2,3};
    Go(arr , 0);
    int total = 0;
    test{
        int n;
        cin>>n;
        if(n == 0){
            cout<<(-1*400)<<endl;
            total -= 400;
            continue;
        }
        vii a(4 , vi(4));
        while(n--){
            char ch;
            int time;
            cin>>ch>>time;
            if(ch == 'A')
                a[0][m[time]]++;
            else if(ch == 'B')
                a[1][m[time]]++;
            else if(ch == 'C')
                a[2][m[time]]++;
            else
                a[3][m[time]]++;
        }
        //loop(4) cout<<a[i][0]<<endl;
        vi final;
        loop(24){
            vi temp;
            for(int j = 0; j < 4; j++){
                temp.pb(a[j][store[i][j]]);
            }
            sort(temp.rbegin() , temp.rend());
            int x = 100;
            int profit = 0;
            for(int no : temp){
                if(no != 0){
                    profit += (no*x);
                    x -= 25;
                }
                else
                    profit -= 100;
            }
            //cout<<profit<<endl;
            final.pb(profit);
        }
        sort(final.rbegin() , final.rend());
        cout<<final[0]<<endl;
        total += final[0];
    }
    cout<<total<<endl;
    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
