#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n , p;
        cin>>n>>p;
        vi a(n) , accum(n) , temp(n);
        int sum  = 0;
        int coun = 0;
        loop(n){
            cin>>a[i];
            temp[i] = a[i];
            if(p % a[i] == 0){
                coun++;
                temp[i] = 0;
            }
            sum += a[i];
            accum[i] = sum;
        }
        vi final(n,0);
        if(coun == n){
            int c = 0;
            int mark = 0 , mark2;
            for(int j = 0; j < n-1; j++){
                for(int i = j+1; i < n; i++){
                    if(a[i] % a[j] == 0)
                        c++;
                    else{
                        mark = i;
                        mark2 = j;
                        break;
                    }
                }
                if(mark)
                    break;
            }
            if(!mark){
                cout<<"NO"<<endl;
                continue;
            }
            cout<<"YES"<<" ";
            p = p-a[mark];
            final[mark2] = (p/a[mark2])+1;
            final[mark] = 1;
            loop(n) cout<<final[i]<<" ";
        }
        else{
            loop(n){
                if(temp[i]){
                    final[i] = (p/temp[i])+1;
                    break;
                }
            }
            cout<<"YES"<<" ";
            loop(n) cout<<final[i]<<" ";
        }
        cout<<endl;
    }

    return 0;
}
//* CHECK FOR CORNER CASES LIKE 0,1 *//
        //***  CODE HARD  ***//
        //***  PRACTICE   ***//
        //** TRY AND LEARN **//
        //***   THE END   ***//
