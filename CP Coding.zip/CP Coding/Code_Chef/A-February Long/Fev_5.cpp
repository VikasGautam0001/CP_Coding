#include<bits/stdc++.h>
using namespace std;
#define int long long int
#define vi vector<int>
#define vii vector<vector<int>>
#define pb push_back
#define mp make_pair
#define ii pair<int,int>
#define loop(n) for(int i=0; i<(int)n; i++)
#define ld long double
#define um unordered_map
#define test int t; cin>>t; while(t--)
#define floatdigit(n) cout<<fixed; cout<<setprecision(n);
#define MOD 1000000007
//USE getline(cin,string_name) for string input.
//USE transform(s.begin(),s.end(),s.begin(),::tolower);
int32_t main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    test{
        int n , m;
        cin>>n>>m;
        if(n+m < 3){
            cout<<0<<endl;
            continue;
        }
        vi x(n) , y(m) , posX , posY , negX , negY;
        loop(n){
            cin>>x[i];
            if(x[i] > 0 )
                posX.pb(x[i]);
            else
                negX.pb(x[i]);
        }
        loop(m){
            cin>>y[i];
            if(y[i] > 0)
                posY.pb(y[i]);
            else
                negY.pb(y[i]);
        }
        sort(x.begin() , x.end());
        sort(y.begin() , y.end());

        sort(posX.rbegin() , posX.rend());
        sort(posY.rbegin() , posY.rend());

        sort(negX.begin() , negX.end());
        sort(negY.begin() , negY.end());

        int count = 0;
        for(int n1 : negX){
            for(int n2 : posX){
                for(int k = 0; k < m; k++){
                    int a = (n1-n2)*(n1-n2);
                    int b = (n1*n1+y[k]*y[k]);
                    int c = (n2*n2+y[k]*y[k]);
                    vi temp;
                    temp.pb(a);
                    temp.pb(b);
                    temp.pb(c);
                    sort(temp.begin() ,temp.end());
                    if((temp[0]+temp[1]) == temp[2])
                        count++;

                }
            }
        }

        for(int n1 : negY){
            for(int n2 : posY){
                for(int k = 0; k < n; k++){
                    int a = (n1-n2)*(n1-n2);
                    int b = (n1*n1)+(x[k]*x[k]);
                    int c = (n2*n2)+(x[k]*x[k]);
                    vi temp;
                    temp.pb(a);
                    temp.pb(b);
                    temp.pb(c);
                    sort(temp.begin() ,temp.end());
                    if((temp[0]+temp[1]) == temp[2])
                        count++;

                }
            }
        }
        cout<<count<<endl;


    }

    return 0;
}
